package com.abc.project;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.list.*;
import com.abc.ds.stack.*;
import com.abc.ds.tree.binary.*;
import com.programix.util.*;

public class ProjectDSBinarySearchTree<K, V> implements DSBinarySearchTree<K, V> {
    private final Class<K> keyType;
    private final Class<V> valueType;
    private final DSComparator<K> keyComparator;

    private final Class<DSKeyValuePair<K, V>> pairType;
    private final Class<BasicNode<K, V>> basicNodeType;
    private final DSKeyValuePair<K, V>[] pairZeroLenArray;
    private final DSIterator<DSKeyValuePair<K, V>> pairEmptyIterator;

    private BasicNode<K, V> rootNode;
    private int count;
    private int levelCount;

    private DSKeyValuePair<K, V> lastReplacedPair;
    private DSKeyValuePair<K, V> lastDeletedPair;

    @SuppressWarnings("unchecked")
    public ProjectDSBinarySearchTree(Class<K> keyType,
                                     Class<V> valueType,
                                     DSComparator<K> keyComparator) {

        ObjectTools.paramNullCheck(keyType, "keyType");
        ObjectTools.paramNullCheck(valueType, "valueType");
        ObjectTools.paramNullCheck(keyComparator, "keyComparator");

        this.keyType = keyType;
        this.valueType = valueType;
        this.keyComparator = keyComparator;

        pairType = (Class<DSKeyValuePair<K, V>>) DSTools.coerceClassType(DSKeyValuePair.class);
        basicNodeType = (Class<BasicNode<K, V>>) DSTools.coerceClassType(BasicNode.class);

        pairZeroLenArray = DSTools.createArrayFromType(pairType, 0);
        pairEmptyIterator = EmptyDSIterator.createForType();

        rootNode = null;
        count = 0;
        levelCount = 0;

        lastReplacedPair = null;
        lastDeletedPair = null;
    }

    @Override
    public DSComparator<K> getKeyComparator() {
        return keyComparator;
    }

    @Override
    public Class<K> getKeyType() {
        return keyType;
    }

    @Override
    public Class<V> getValueType() {
        return valueType;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return rootNode == null;
    }

    @Override
    public void clear() {
        rootNode = null;
        count = 0;
        levelCount = 0;

        lastReplacedPair = null;
        lastDeletedPair = null;

    }

    @Override
    public int getLevelCount() {
        return levelCount;
    }

    @Override
    public Node<K, V> getRootNode() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        return rootNode;
    }

    @Override
    public DSKeyValuePair<K, V> insert(K key, V value) {
        DSKeyValuePair<K, V>[] rPair = DSTools.createArrayFromType(pairType, 1);
        rootNode = insertNode(rootNode, key, value, rPair);
        return rPair[0];
    }

    private BasicNode<K, V> insertNode(BasicNode<K, V> node, K key, V value, Object[] rPair) {
        if (node == null) {
            node = new BasicNode<>(createPair(key, value));
            count++;
            rPair[0] = null;
            return node;
        }
        if (keyComparator.compare(node.getKey(), key) == DSCompareResult.EQUAL_TO) {
            rPair[0] = node.pair;
            node.pair = createPair(key, value);
            return node;
        }
        if (keyComparator.compare(key, node.getKey()) == DSCompareResult.LESS_THAN)
            node.left = insertNode(node.left, key, value, rPair);
        else
            node.right = insertNode(node.right, key, value, rPair);
        return node;
    }


    @Override
    public DSKeyValuePair<K, V> peek(K key) {
        BasicNode<K, V> node = findNode(rootNode, key);
        return node == null ? null : findNode(rootNode, key).getPair();
    }

    private BasicNode<K, V> findNode(BasicNode<K, V> node, K key) {
        if (node == null)
            return null;
        if (keyComparator.compare(node.getKey(), key) == DSCompareResult.EQUAL_TO)
            return node;
        if (keyComparator.compare(key, node.getKey()) == DSCompareResult.LESS_THAN)
            return findNode(node.left, key);
        else
            return findNode(node.right, key);

    }

    @Override
    public DSKeyValuePair<K, V> peekMin() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        BasicNode<K, V> node = rootNode;
        while (node.left != null)
            node = node.left;
        return node.pair;

    }

    @Override
    public DSKeyValuePair<K, V> peekMax() throws NoSuchElementException {
        if (isEmpty())
            throw new NoSuchElementException();
        BasicNode<K, V> node = rootNode;
        while (node.right != null)
            node = node.right;
        return node.pair;
    }

    @Override
    public DSKeyValuePair<K, V>[] peekKeyMatches(DSFilter<K> keyFilter) {
        List<DSKeyValuePair<K, V>> list = new ArrayList<>();
        DSIterator<DSKeyValuePair<K, V>> iterator = createIterator();
        DSKeyValuePair<K, V> item;
        while (iterator.hasNext()) {
            item = iterator.next();
            if (keyFilter.matches(item.getKey()))
                list.add(item);
        }
        DSKeyValuePair<K, V>[] results = DSTools.createArrayFromType(pairType, list.size());
        return list.toArray(results);
    }

    @Override
    public DSKeyValuePair<K, V>[] peekAll() {
        return DSTools.iteratorToArray(pairType, createIterator());
    }

    @Override
    public DSKeyValuePair<K, V> delete(K keyToMatch) {
        DSKeyValuePair<K, V>[] rPair = DSTools.createArrayFromType(pairType, 1);
        rootNode = deleteNode(rootNode, keyToMatch, rPair);
        return rPair[0];
    }

    private BasicNode<K, V> deleteNode(BasicNode<K, V> node, K keyToMatch, DSKeyValuePair<K, V>[] rPair) {
        if (node == null) {
            return null;
        }
        if (keyComparator.compare(keyToMatch, node.getKey()) == DSCompareResult.LESS_THAN) {
            node.left = deleteNode(node.left, keyToMatch, rPair);
        } else if (keyComparator.compare(keyToMatch, node.getKey()) == DSCompareResult.GREATER_THAN) {
            node.right = deleteNode(node.right, keyToMatch, rPair);
        } else {
            if (rPair[0] == null) {
                count--;
                rPair[0] = node.getPair();
            }
            if (node.right == null) {
                node = node.left;

            } else {
                K key = min(node.right);
                node.pair = createPair(key, peek(key).getValue());
                node.right = deleteNode(node.right, key, rPair);
            }
        }
        return node;
    }

    private K min(BasicNode<K, V> node) {
        if (node.left == null)
            return node.getKey();
        else
            return min(node.left);
    }

    @Override
    public DSKeyValuePair<K, V> deleteMin() throws NoSuchElementException {
        DSKeyValuePair<K, V>[] min = DSTools.createArrayFromType(pairType, 1);
        rootNode = deleteNode(rootNode, peekMin().getKey(), min);
        return min[0];
    }

    @Override
    public DSKeyValuePair<K, V> deleteMax() throws NoSuchElementException {
        DSKeyValuePair<K, V>[] min = DSTools.createArrayFromType(pairType, 1);
        rootNode = deleteNode(rootNode, peekMax().getKey(), min);
        return min[0];
    }

    @Override
    public DSKeyValuePair<K, V>[] deleteKeyMatches(DSFilter<K> keyFilter) {
        ArrayList<DSKeyValuePair<K, V>> list = new ArrayList<>();
        DSIterator<DSKeyValuePair<K, V>> iterator = createIterator();
        while (iterator.hasNext()) {
            DSKeyValuePair<K, V> pair = iterator.next();
            if (keyFilter.matches(pair.getKey()))
                list.add(pair);
        }
        for (DSKeyValuePair<K, V> pair : list)
            delete(pair.getKey());
        return list.toArray(DSTools.createArrayFromType(pairType, 0));
    }

    @Override
    public DSKeyValuePair<K, V>[] deleteAll() {
        DSKeyValuePair<K, V>[] pairs = peekAll();
        clear();
        return pairs;
    }

    @Override
    public DSIterator<DSKeyValuePair<K, V>> createIterator() {
        return new DSIterator<DSKeyValuePair<K, V>>() {
            ArrayDSUnboundedStack<BasicNode<K, V>> stack;

            {
                stack = new ArrayDSUnboundedStack<>(basicNodeType);
                BasicNode<K, V> node = rootNode;
                while (node != null) {
                    stack.push(node);
                    node = node.left;
                }
            }

            @Override
            public boolean hasNext() {
                return !stack.isEmpty();
            }

            @Override
            public DSKeyValuePair<K, V> next() throws NoSuchElementException {
                if (!hasNext())
                    throw new NoSuchElementException();
                BasicNode<K, V> node = stack.pop();
                DSKeyValuePair<K, V> pair = node.getPair();
                if (node.hasRightChild()) {
                    node = node.right;
                    stack.push(node);
                    while (node.left != null) {
                        stack.push(node.left);
                        node = node.left;
                    }
                }
                return pair;
            }
        };
    }

    @Override
    public DSIterator<DSKeyValuePair<K, V>> createReverseIterator() {
        return new DSIterator<DSKeyValuePair<K, V>>() {
            ArrayDSUnboundedStack<BasicNode<K, V>> stack;

            {
                stack = new ArrayDSUnboundedStack<>(basicNodeType);
                BasicNode<K, V> node = rootNode;
                while (node != null) {
                    stack.push(node);
                    node = node.right;
                }
            }

            @Override
            public boolean hasNext() {
                return !stack.isEmpty();
            }

            @Override
            public DSKeyValuePair<K, V> next() throws NoSuchElementException {
                if (!hasNext())
                    throw new NoSuchElementException();
                BasicNode<K, V> node = stack.pop();
                DSKeyValuePair<K, V> pair = node.getPair();
                if (node.hasLeftChild()) {
                    node = node.left;
                    stack.push(node);
                    while (node.right != null) {
                        stack.push(node.right);
                        node = node.right;
                    }
                }
                return pair;
            }
        };
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if (isEmpty()) {
            throw new NoSuchElementException("tree is empty, " +
                    "use isEmpty() to avoid this exception");
        }
    }

    private DSKeyValuePair<K, V> createPair(K key, V value) {
        return new BasicDSKeyValuePair<>(key, value);
    }

    private DSList<DSKeyValuePair<K, V>> createInOrderListOfPairs(DSFilter<K> keyFilter) {
        if (keyFilter == null) return new ArrayDSList<>(pairType);

        DSList<DSKeyValuePair<K, V>> list = new ArrayDSList<>(pairType, count, 5);
        fillInOrderListOfPairs(rootNode, list, keyFilter);
        return list;
    }

    private void fillInOrderListOfPairs(BasicNode<K, V> subTreeRoot, DSList<DSKeyValuePair<K, V>> list, DSFilter<K> keyFilter) {
        if (subTreeRoot == null) return;

        fillInOrderListOfPairs(subTreeRoot.left, list, keyFilter);
        if (keyFilter.matches(subTreeRoot.getKey())) {
            list.add(subTreeRoot.pair);
        }
        fillInOrderListOfPairs(subTreeRoot.right, list, keyFilter);
    }

    private static class BasicNode<K, V> implements Node<K, V> {
        public DSKeyValuePair<K, V> pair;
        public BasicNode<K, V> left;
        public BasicNode<K, V> right;

        public BasicNode(DSKeyValuePair<K, V> pair) {
            this.pair = pair;
            left = null;
            right = null;
        }

        @Override
        public K getKey() {
            return pair.getKey();
        }

        @Override
        public V getValue() {
            return pair.getValue();
        }

        @Override
        public DSKeyValuePair<K, V> getPair() {
            return pair;
        }

        @Override
        public boolean hasLeftChild() {
            return left != null;
        }

        @Override
        public boolean hasRightChild() {
            return right != null;
        }

        @Override
        public BasicNode<K, V> getLeftChildOrNull() {
            return left;
        }

        @Override
        public BasicNode<K, V> getRightChildOrNull() {
            return right;
        }

        @Override
        public BasicNode<K, V> findMin() {
            BasicNode<K, V> currNode = this;
            while (currNode.left != null) {
                currNode = currNode.left;
            }
            return currNode;
        }

        @Override
        public BasicNode<K, V> findMax() {
            BasicNode<K, V> currNode = this;
            while (currNode.right != null) {
                currNode = currNode.right;
            }
            return currNode;
        }
    } // type BasicNode
}
