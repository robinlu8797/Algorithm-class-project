package com.abc.project;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.set.*;
import com.abc.ds.sortedset.*;
import com.abc.ds.tree.binary.*;
import com.programix.util.*;

public class ProjectTreeDSSortedSet<T> implements DSSortedSet<T> {
    private final DSBinarySearchTree<T, Object> tree;


    public ProjectTreeDSSortedSet(Class<T> itemType, DSComparator<T> comparator) {
        ObjectTools.paramNullCheck(itemType, "itemType");
        ObjectTools.paramNullCheck(comparator, "comparator");
        tree = new ProjectDSBinarySearchTree<>(itemType, Object.class, comparator);

    }

    @Override
    public Class<T> getItemType() {
        return tree.getKeyType();
    }

    @Override
    public int getCount() {
        return tree.getCount();
    }

    @Override
    public boolean isEmpty() {
        return tree.isEmpty();
    }

    @Override
    public void clear() {
        tree.clear();
    }

    @Override
    public boolean add(T item) {
        if (tree.peek(item) != null)
            return false;
        tree.insert(item, null);
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public int addAll(T... items) {
        int counter = 0;
        if (items != null)
            for (T item : items)
                if (add(item))
                    counter++;
        return counter;
    }

    @Override
    public int addAll(DSIterable<T> iterableItems) {
        int counter = 0;
        if (iterableItems != null) {
            DSIterator<T> iterator = iterableItems.createIterator();
            while (iterator.hasNext())
                if (add(iterator.next()))
                    counter++;
        }
        return counter;

    }

    @Override
    public boolean remove(T item) {
        DSKeyValuePair<T, Object> pair = tree.delete(item);
        return pair != null;
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        DSKeyValuePair<T, Object>[] pairs = tree.deleteKeyMatches(filter);
        T[] array = DSTools.createArrayFromType(getItemType(), pairs.length);
        for (int i = 0; i < pairs.length; i++)
            array[i] = pairs[i].getKey();
        return array;
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        return removeAndReturnMatches(filter).length;
    }

    @Override
    public T[] removeAll() {
        return removeAndReturnMatches(new DSFilter<T>() {
            @Override
            public boolean matches(T item) {
                return true;
            }
        });
    }

    @Override
    public boolean contains(T item) {
        return tree.peek(item) != null;
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        DSKeyValuePair<T, Object>[] pairs = tree.peekKeyMatches(filter);
        T[] array = DSTools.createArrayFromType(getItemType(), pairs.length);
        for (int i = 0; i < pairs.length; i++)
            array[i] = pairs[i].getKey();
        return array;
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        return peekMatches(filter).length;
    }

    @Override
    public T[] peekAll() {
        DSKeyValuePair<T, Object>[] pairs = tree.peekAll();
        T[] array = DSTools.createArrayFromType(getItemType(), pairs.length);
        for (int i = 0; i < pairs.length; i++)
            array[i] = pairs[i].getKey();
        return array;
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        T[] matches = peekAll();
        for (T item : matches)
            action.perform(item);
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        T[] matches = peekMatches(filter);
        for (T item : matches)
            action.perform(item);
        return matches.length;
    }

    @Override
    public int union(DSSet<T> otherSet) {
        int oldSize = getCount();
        addAll(otherSet);
        return getCount() - oldSize;
    }

    @Override
    public void intersection(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.getCount() == 0) {
            clear();
        } else {
            removeAndReturnMatches(new DSFilter<T>() {
                @Override
                public boolean matches(T item) {
                    return !otherSet.contains(item);
                }
            });
        }
    }

    @Override
    public void subtract(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.getCount() == 0) {
            clear();
        } else {
            removeAndReturnMatches(new DSFilter<T>() {
                @Override
                public boolean matches(T item) {
                    return otherSet.contains(item);
                }
            });
        }
    }

    @Override
    public DSComparator<T> getComparator() {
        return tree.getKeyComparator();
    }

    @Override
    public T removeFirst() throws NoSuchElementException {
        DSKeyValuePair<T, Object> pair = tree.deleteMin();
        return pair.getKey();
    }

    @Override
    public T removeLast() throws NoSuchElementException {
        DSKeyValuePair<T, Object> pair = tree.deleteMax();
        return pair.getKey();
    }

    @Override
    public T peekFirst() throws NoSuchElementException {
        return tree.peekMin().getKey();
    }

    @Override
    public T peekLast() throws NoSuchElementException {
        return tree.peekMax().getKey();
    }

    @Override
    public DSIterator<T> createIterator() {
        DSIterator<T> iterator = new DSIterator<T>() {
            DSIterator<DSKeyValuePair<T, Object>> iterator = tree.createIterator();

            @Override
            public boolean hasNext() {
                return iterator.hasNext();
            }

            @Override
            public T next() throws NoSuchElementException {
                return iterator.next().getKey();
            }
        };

        return iterator;

    }

    @Override
    public DSIterator<T> createReverseIterator() {
        DSIterator<T> iterator = new DSIterator<T>() {
            DSIterator<DSKeyValuePair<T, Object>> iterator = tree.createReverseIterator();

            @Override
            public boolean hasNext() {
                return iterator.hasNext();
            }

            @Override
            public T next() throws NoSuchElementException {
                return iterator.next().getKey();
            }
        };

        return iterator;
    }
}
