package com.abc.project;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.sortedset.*;
import com.abc.ds.sortedset.tests.*;
import com.abc.ds.tree.binary.*;
import com.abc.ds.tree.binary.tests.*;
import com.programix.gui.*;
import com.programix.testing.*;

public class DemoProject {
    public DemoProject() {
    }

    public static void createFramedInstance() {
        if ( SwingUtilities.isEventDispatchThread() == false ) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    createFramedInstance();
                }
            });
            return;
        }

        DemoProject demoProject = new DemoProject();

        ParallelTestingPane treeTestPane = demoProject.createTreeTestPane();
        ParallelTestingPane sortedSetTestPane = demoProject.createSortedSetTestPane();

        JPanel contentPane = new JPanel(new GridLayout(0, 1, 5, 5));
        contentPane.add(treeTestPane.getVisualComponent());
        contentPane.add(sortedSetTestPane.getVisualComponent());

        JFrame f = new JFrame("BinarySearchTree and DSSortedSet Combined Tests");
        f.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        f.setContentPane(contentPane);

        //f.setSize(1500, 800);
        GuiTools.setSizeAndCenterOnScreen(f, 2000, 1200);
        f.setVisible(true);

        f.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

    }

    public ParallelTestingPane createTreeTestPane() {
        final String title = "BasicDSBinarySearchTree [worth 92/100 points]";
        final DSBinarySearchTreeFactory factory = new DSBinarySearchTreeFactory() {
            @Override
            public <K> DSOrdering<K> getOrdering(DSBinarySearchTree<K, ?> tree) {
                return DSOrdering.createOrderedByComparator(tree.getKeyComparator());
            }

            @Override
            public <K, V> DSBinarySearchTree<K, V> create(Class<K> keyType,
                                                          Class<V> valueType,
                                                          DSComparator<K> comparator) {
                return new ProjectDSBinarySearchTree<>(keyType, valueType, comparator);
            }
        };

        return new ParallelTestingPane(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSBinarySearchTree.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }

    public ParallelTestingPane createSortedSetTestPane() {
        final String title = "TreeDSSortedSet [worth 8/100 points]";
        final DSSortedSetFactory factory = new DSSortedSetFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSortedSet<T> sortedSet) {
                return DSOrdering.createOrderedByComparator(sortedSet.getComparator());
            }

            @Override
            public <T> DSSortedSet<T> create(Class<T> itemType,
                                             DSComparator<T> comparator) {
                return new ProjectTreeDSSortedSet<>(itemType, comparator);
            }
        };

        return new ParallelTestingPane(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSSortedSet.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }

    public static void main(String[] args) {
        createFramedInstance();
    }
}
