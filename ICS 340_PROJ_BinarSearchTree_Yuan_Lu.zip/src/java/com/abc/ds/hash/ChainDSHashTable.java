package com.abc.ds.hash;

import com.abc.ds.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.linkedlist.*;
import com.abc.ds.sack.*;
import com.programix.util.*;

public class ChainDSHashTable<K, V> implements DSHashTable<K, V> {
    private final Class<K> keyType;
    private final Class<V> valueType;
    private int count;

    private Bucket<K, V>[] buckets;
    private final Bucket<K, V> sharedEmptyBucket;
    private final DSIterator<DSKeyValuePair<K, V>> sharedEmptyPairIterator;

    private final K[] keyZeroLenArray;
    private final V[] valueZeroLenArray;
    private final DSKeyValuePair<K, V>[] keyValuePairZeroLenArray;
    private final Class<DSKeyValuePair<K, V>> keyValuePairType;

    @SuppressWarnings("unchecked")
    public ChainDSHashTable(Class<K> keyType,
                            Class<V> valueType,
                            int bucketCount) {

        this.keyType = keyType;
        this.valueType = valueType;

        count = 0;

        sharedEmptyPairIterator = EmptyDSIterator.createForType();
        sharedEmptyBucket = new EmptyBucket<K, V>(this);
        buckets = createBucketArray(bucketCount);
        for ( int i = 0; i < buckets.length; i++ ) {
            buckets[i] = sharedEmptyBucket;
        }

        keyZeroLenArray = createKeyArray(0);
        valueZeroLenArray = createValueArray(0);
        keyValuePairZeroLenArray = createPairArray(0);
        keyValuePairType = (Class<DSKeyValuePair<K, V>>) keyValuePairZeroLenArray.getClass().getComponentType();
    }

    @SuppressWarnings("unchecked")
    private Bucket<K, V>[] createBucketArray(int length) {
        return DSTools.createArrayFromType(Bucket.class, length);
    }

    private K[] createKeyArray(int length) {
        return DSTools.createArrayFromType(keyType, length);
    }

    private V[] createValueArray(int length) {
        return DSTools.createArrayFromType(valueType, length);
    }

    @SuppressWarnings("unchecked")
    private DSKeyValuePair<K, V>[] createPairArray(int length) {
        return DSTools.createArrayFromType(DSKeyValuePair.class, length);
    }

    private Bucket<K, V> findBucket(K key) {
        return buckets[findBucketIndex(key)];
    }

    private int findBucketIndex(K key) {
        int hashCode = key.hashCode();
        return Math.abs(hashCode) % buckets.length;
    }

    @Override
    public Class<K> getKeyType() {
        return keyType;
    }

    @Override
    public Class<V> getValueType() {
        return valueType;
    }

    @Override
    public int count() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public void clear() {
        for ( int i = 0; i < buckets.length; i++ ) {
            // this lets the non-empty buckets just be garbage collected
            buckets[i] = sharedEmptyBucket;
        }
        count = 0;
    }

    @Override
    public V insert(K key, V value) {
        int bucketIndex = findBucketIndex(key);
//System.out.println("key=" + key + ", bucketIndex=" + bucketIndex);
        Bucket<K, V> bucket = buckets[bucketIndex];
        if ( bucket == sharedEmptyBucket ) {
            buckets[bucketIndex] = new ListBucket<K, V>(this);
            bucket = buckets[bucketIndex];
        }
        int oldBucketCount = bucket.count();
        V oldValue = bucket.insert(key, value);
        count += (bucket.count() - oldBucketCount);
        return oldValue;
    }

    @Override
    public boolean containsKey(K key) {
        return findBucket(key).containsKey(key);
    }

    @Override
    public DSKeyValuePair<K, V>[] peekAll() {
        if ( count == 0 ) {
            return keyValuePairZeroLenArray;
        }

        DSKeyValuePair<K, V>[] pairs = createPairArray(count);
        int ptr = 0;
        for ( Bucket<K, V> bucket : buckets ) {
            DSKeyValuePair<K, V>[] bucketPairs = bucket.peekAll();
            System.arraycopy(bucketPairs, 0, pairs, ptr, bucketPairs.length);
            ptr += bucketPairs.length;
        }
        return pairs;
    }

    @Override
    public DSKeyValuePair<K, V>[] peekKeyMatches(DSFilter<K> keyFilter) {
        DSSack<DSKeyValuePair<K, V>> matchedPairs =
            new ArrayDSSack<>(keyValuePairType);

        for ( Bucket<K, V> bucket : buckets ) {
            matchedPairs.addAll(bucket.peekKeyMatches(keyFilter));
        }

        return matchedPairs.peekAll();
    }

    @Override
    public V peekValue(K key) {
        return findBucket(key).peekValue(key);
    }

    @Override
    public V delete(K key) {
        int bucketIndex = findBucketIndex(key);
        Bucket<K, V> bucket = buckets[bucketIndex];
        if ( bucket.isEmpty() ) {
            return null;
        }

        int bucketCountBefore = bucket.count();
        V deletedValue = bucket.delete(key);
        boolean foundAndDeleted = bucket.count() < bucketCountBefore;
        if ( bucket.isEmpty() ) {
            // Just deleted the last one out of this bucket, allow garbage
            // collection and go back to using the shared empty bucket instance.
            buckets[bucketIndex] = sharedEmptyBucket;
        }
        if ( foundAndDeleted ) {
            count--;
        }
        return deletedValue;
    }

    @Override
    public int deleteKeyMatches(DSFilter<K> keyFilter) {
        int deleteCount = 0;
        for ( int i = 0; i < buckets.length; i++ ) {
            Bucket<K, V> bucket = buckets[i];
            if ( bucket.isEmpty() ) {
                continue;
            }

            int bucketDeleteCount = bucket.deleteKeyMatches(keyFilter);
            deleteCount += bucketDeleteCount;
            count -= bucketDeleteCount;
            if ( bucket.isEmpty() ) {
                // Just deleted the last one out of this bucket, allow garbage
                // collection and go back to using the shared empty bucket.
                buckets[i] = sharedEmptyBucket;
            }
        }
        return deleteCount;
    }

    @Override
    public DSIterator<DSKeyValuePair<K, V>> createIterator() {
        if ( isEmpty() ) {
            return sharedEmptyPairIterator;
        }

        CompositeDSIterator.Builder<DSKeyValuePair<K, V>> builder =
            new CompositeDSIterator.Builder<>();
        for ( Bucket<K, V> bucket : buckets ) {
            if ( !bucket.isEmpty() ) {
                builder.append(bucket.createIterator());
            }
        }
        return builder.create();
    }

    @Override
    public K[] extractKeys(DSKeyValuePair<K, V>[] pairs) {
        if ( ObjectTools.isEmpty(pairs) ) {
            return keyZeroLenArray;
        }
        K[] keys = DSTools.createArrayFromType(keyType, pairs.length);
        for ( int i = 0; i < keys.length; i++ ) {
            DSKeyValuePair<K, V> pair = pairs[i];
            keys[i] = pair == null ? null : pair.getKey();
        }
        return keys;
    }

    @Override
    public V[] extractValues(DSKeyValuePair<K, V>[] pairs) {
        if ( ObjectTools.isEmpty(pairs) ) {
            return valueZeroLenArray;
        }
        V[] values = DSTools.createArrayFromType(valueType, pairs.length);
        for ( int i = 0; i < values.length; i++ ) {
            DSKeyValuePair<K, V> pair = pairs[i];
            values[i] = pair == null ? null : pair.getValue();
        }
        return values;
    }

    private static interface Bucket<K, V> {
        int count();
        boolean isEmpty();
        V insert(K key, V value);

        boolean containsKey(K key);

        DSKeyValuePair<K, V>[] peekAll();
        DSKeyValuePair<K, V>[] peekKeyMatches(DSFilter<K> keyFilter);
        V peekValue(K key);

        V delete(K key);
        int deleteKeyMatches(DSFilter<K> keyFilter);

        DSIterator<DSKeyValuePair<K, V>> createIterator();
    } // type Bucket

    private static class EmptyBucket<K, V> implements Bucket<K, V> {
        private final ChainDSHashTable<K, V> owner;

        public EmptyBucket(ChainDSHashTable<K, V> owner) {
            this.owner = owner;
        }

        @Override
        public int count() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return true;
        }

        @Override
        public V insert(K key, V value) {
            throw new RuntimeException("insert not supported");
        }

        @Override
        public boolean containsKey(K key) {
            return false;
        }

        @Override
        public DSKeyValuePair<K, V>[] peekAll() {
            return owner.keyValuePairZeroLenArray;
        }

        @Override
        public DSKeyValuePair<K, V>[] peekKeyMatches(DSFilter<K> keyFilter) {
            return owner.keyValuePairZeroLenArray;
        }

        @Override
        public V peekValue(K key) {
            return null;
        }

        @Override
        public V delete(K key) {
            return null;
        }

        @Override
        public int deleteKeyMatches(DSFilter<K> keyFilter) {
            return 0;
        }

        @Override
        public DSIterator<DSKeyValuePair<K, V>> createIterator() {
            return owner.sharedEmptyPairIterator;
        }
    } // type EmptyBucket

    private static class ListBucket<K, V> implements Bucket<K, V> {
        private final ChainDSHashTable<K, V> owner;
        private DSLinkedList<DSKeyValuePair<K, V>> linkedList;

        public ListBucket(ChainDSHashTable<K, V> pOwner) {
            this.owner = pOwner;
            linkedList = new DoublyDSLinkedList<DSKeyValuePair<K, V>>(
                owner.keyValuePairType);
        }

        @Override
        public int count() {
            return linkedList.getCount();
        }

        @Override
        public boolean isEmpty() {
            return count() == 0;
        }

        @Override
        public V insert(final K key, V value) {
            ObjectTools.paramNullCheck(key, "key");

            DSLinkedList.Node<DSKeyValuePair<K, V>>[] nodes =
                peekNodesMatching(new EqualToDSFilter<K>(key));

            BasicDSKeyValuePair<K, V> newPair =
                new BasicDSKeyValuePair<K, V>(key, value);

            if ( nodes.length == 0 ) {
                // insert a new one
                linkedList.insertLast(newPair);
                return null;
            } else {
                DSKeyValuePair<K, V> oldPair = nodes[0].getPayload();
                nodes[0].setPayload(newPair);
                return oldPair.getValue();
            }
        }

        @Override
        public boolean containsKey(K key) {
            for ( DSKeyValuePair<K, V> pair :
                    DSTools.asJavaIterable(linkedList) ) {

                if ( ObjectTools.isSame(key, pair.getKey()) ) {
                    return true;
                }
            }
            return false;
        }

        private DSLinkedList.Node<DSKeyValuePair<K, V>>[] peekNodesMatching(
                DSFilter<K> keyFilter) {

            return linkedList.peekMatches(
                new KeyFilterToPairFilterAdapter<K, V>(keyFilter));
        }

        private DSKeyValuePair<K, V>[] peekPairsMatching(
                DSFilter<K> keyFilter) {

            return nodesToPairs(peekNodesMatching(keyFilter));
        }

        private DSKeyValuePair<K, V>[] nodesToPairs(
                DSLinkedList.Node<DSKeyValuePair<K, V>>[] nodes) {

            return linkedList.extractPayloads(nodes);
        }

        @Override
        public DSKeyValuePair<K, V>[] peekAll() {
            return nodesToPairs(linkedList.peekAll());
        }

        @Override
        public DSKeyValuePair<K, V>[] peekKeyMatches(final DSFilter<K> keyFilter) {
            return peekPairsMatching(keyFilter);
        }

        @Override
        public V peekValue(K key) {
            DSKeyValuePair<K, V>[] pairs =
                peekPairsMatching(new EqualToDSFilter<K>(key));
            return pairs.length == 0 ? null : pairs[0].getValue();
        }

        @Override
        public V delete(K key) {
System.out.println("key=" + key);
            DSLinkedList.Node<DSKeyValuePair<K, V>>[] nodes =
                peekNodesMatching(new EqualToDSFilter<K>(key));
if ( nodes == null ) {
    System.out.println("nodes=null");
} else {
    System.out.println("nodes.length=" + nodes.length);
    for ( int i = 0; i < nodes.length; i++ ) {
        System.out.println("  nodes[" + i + "]=" + nodes[i]);
    }
}
            if ( nodes.length == 0 ) {
                return null;
            }

            V value = nodesToPairs(nodes)[0].getValue();
            nodes[0].delete();
            return value;
        }

        @Override
        public int deleteKeyMatches(DSFilter<K> keyFilter) {
            DSLinkedList.Node<DSKeyValuePair<K, V>>[] nodes =
                peekNodesMatching(keyFilter);

            for ( DSLinkedList.Node<DSKeyValuePair<K, V>> node : nodes ) {
                node.delete();
            }
            return nodes.length;
        }

        @Override
        public DSIterator<DSKeyValuePair<K, V>> createIterator() {
            return linkedList.createIterator();
        }

        private static class KeyFilterToPairFilterAdapter<K, V>
                implements DSFilter<DSKeyValuePair<K, V>> {

            private final DSFilter<K> keyFilter;

            public KeyFilterToPairFilterAdapter(DSFilter<K> keyFilter) {
                this.keyFilter = keyFilter;
            }

            @Override
            public boolean matches(DSKeyValuePair<K, V> item) {
                return keyFilter.matches(item.getKey());
            }
        } // type KeyFilterToPairFilterAdapter
    } // type ListBucket
}
