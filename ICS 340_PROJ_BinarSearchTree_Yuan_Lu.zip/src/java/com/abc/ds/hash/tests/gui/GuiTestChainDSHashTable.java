package com.abc.ds.hash.tests.gui;

import com.abc.ds.hash.*;
import com.abc.ds.hash.tests.*;

public class GuiTestChainDSHashTable {
    public static void main(String[] args) {
        GuiTestDSHashTable.runTests("ChainDSHashTable", new DSHashTableFactory() {
            @Override
            public <K, V> DSHashTable<K, V> create(Class<K> keyType,
                                                   Class<V> valueType,
                                                   int capacity,
                                                   double loadFactor) {

                return new ChainDSHashTable<>(keyType, valueType, capacity);
            }
        });
    }
}
