package com.abc.ds.hash.tests.gui;

import com.abc.ds.hash.tests.*;
import com.programix.testing.*;

public class GuiTestDSHashTable {
    public static void runTests(final String title,
                                final DSHashTableFactory factory) {

        ParallelTestingPane.createFramedInstance(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSHashTable.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }
}
