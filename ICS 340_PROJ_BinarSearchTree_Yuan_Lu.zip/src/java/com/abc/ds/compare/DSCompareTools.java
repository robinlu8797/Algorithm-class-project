package com.abc.ds.compare;


public class DSCompareTools {
	// private, no instances
	private DSCompareTools() {
	}

	public static <T> DSCompareResult compare(T a,
	                                          T b,
	                                          DSComparator<T> comparator,
	                                          DSNullOrdering nullOrdering) {
	    if ( a == b ) {
	        // both pointing to same object, OR both are null
	        return DSCompareResult.EQUAL_TO;
	    } else if ( a == null || b == null ) {
	        // one is null and the other is NOT null

	        // make sure that we have a default null ordering:
	        nullOrdering = nullOrdering != null ? nullOrdering : DSNullOrdering.NULL_FIRST;

	        if (a == null) {
	            // a is null, b is not null
	            return nullOrdering == DSNullOrdering.NULL_FIRST ? DSCompareResult.LESS_THAN : DSCompareResult.GREATER_THAN;
	        }
	        // b is null, a is not null
	        return nullOrdering == DSNullOrdering.NULL_FIRST ? DSCompareResult.GREATER_THAN : DSCompareResult.LESS_THAN;
	    } else {
	        // neither a nor b is null
	        return comparator.compare(a, b);
	    }
	}

	public static <T> DSCompareResult compare(T a,
	                                          T b,
	                                          DSComparator<T> comparator) {

	    return compare(a, b, comparator, DSNullOrdering.NULL_FIRST);
    }

	public static <T extends DSComparable<T>> DSCompareResult compare(T a,
	                                                                  T b,
	                                                                  DSNullOrdering nullOrdering) {

	    DSComparator<T> comparator = DSComparableComparator.createForType(nullOrdering);
	    return compare(a, b, comparator, nullOrdering);
	}

	public static <T extends DSComparable<T>> DSCompareResult compare(T a, T b) {
	    return compare(a, b, DSNullOrdering.NULL_FIRST);
	}


//	public static <T> boolean is(DSComparator<T> comparator,
//							 	 DSNullOrdering nullTreatment,
//							 	 DSCompareResult atLeastOneResultType,
//							 	 DSCompareResult... optionalOtherResultTypes) {
//
//		return false;
//	}
}
