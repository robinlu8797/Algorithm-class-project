package com.abc.ds.compare;

public final class DSComparableComparator<T extends DSComparable<T>> implements DSComparator<T> {
    private static final DSComparableComparator<?> SHARED_NULL_FIRST_INSTANCE = new DSComparableComparator<>(DSNullOrdering.NULL_FIRST);
    private static final DSComparableComparator<?> SHARED_NULL_LAST_INSTANCE = new DSComparableComparator<>(DSNullOrdering.NULL_LAST);

    private final DSNullOrdering nullOrdering;

    /** private, create instances using createForTypeXYZ methods */
    private DSComparableComparator(DSNullOrdering nullOrdering) {
        this.nullOrdering = nullOrdering;
    }

    /**
     * Returns a shared singleton coerced into the correct type.
     */
    @SuppressWarnings("unchecked")
    public static <T extends DSComparable<T>> DSComparator<T> createForType(DSNullOrdering nullOrdering) {
        return (DSComparator<T>) (nullOrdering == DSNullOrdering.NULL_FIRST ? SHARED_NULL_FIRST_INSTANCE : SHARED_NULL_LAST_INSTANCE);
    }

    public static <T extends DSComparable<T>> DSComparator<T> createForTypeNullFirst() {
        return createForType(DSNullOrdering.NULL_FIRST);
    }

    public static <T extends DSComparable<T>> DSComparator<T> createForTypeNullLast() {
        return createForType(DSNullOrdering.NULL_LAST);
    }


    /**
     * This implementation of the
     * {@link DSComparator#compare(Object, Object) compare} method on
     * {@link DSComparator} will quickly check
     * if both references are the same using <tt>==</tt> (which
     * evaluates to <tt>true</tt> if both references are pointing
     * to the same object or both are <tt>null</tt>).
     * If the references are the same, then this will quickly return
     * {@link DSCompareResult#EQUAL_TO}.
     * <p>
     * If the are not the same,
     * then the references are cast into {@link DSComparable} to
     * complete the comparison.
     *
     * @throws NullPointerException if the first reference is null, and the
     * second reference is not null. To deal with this possibility,
     * check out {@link NullDSComparator}.
     */

    @Override
    public DSCompareResult compare(T a, T b) {
        if ( a == b ) {
            // both pointing to same object, OR both are null
            return DSCompareResult.EQUAL_TO;
        } else if ( a == null || b == null ) {
            // one is null and the other is NOT null
            if ( a == null ) {
                // a is null, b is NOT null
                return (nullOrdering == DSNullOrdering.NULL_FIRST) ?
                    DSCompareResult.LESS_THAN :
                    DSCompareResult.GREATER_THAN;
            } else {
                // a is NOT null, b is null
                return (nullOrdering == DSNullOrdering.NULL_FIRST) ?
                    DSCompareResult.GREATER_THAN :
                    DSCompareResult.LESS_THAN;

            }
        } else {
            // neither is null
            return a.compareTo(b);
        }
    }
}
