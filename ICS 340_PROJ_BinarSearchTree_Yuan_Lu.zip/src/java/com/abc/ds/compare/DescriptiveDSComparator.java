package com.abc.ds.compare;

import com.programix.util.*;

public class DescriptiveDSComparator<T> implements DSComparator<T> {
    private final String description;
    private final DSComparator<T> rawComparator;

    public DescriptiveDSComparator(String description,
                                   DSComparator<T> rawComparator) {
        ObjectTools.paramNullCheck(description, "description");
        ObjectTools.paramNullCheck(rawComparator, "rawComparator");

        this.description = description;
        this.rawComparator = rawComparator;
    }

    @Override
    public DSCompareResult compare(T a, T b) {
        return rawComparator.compare(a, b);
    }

    @Override
    public String toString() {
        return description;
    }
}
