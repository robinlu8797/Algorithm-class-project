package com.abc.ds.compare;

public class CompositeDSComparator<T> implements DSComparator<T> {
    private final DSComparator<T>[] comparators;

    @SafeVarargs
    public CompositeDSComparator(DSComparator<T>... comparators) {
        this.comparators = comparators;
    }

    @Override
    public DSCompareResult compare(T a, T b) {
        for ( DSComparator<T> comparator : comparators ) {
            DSCompareResult compareResult = comparator.compare(a, b);
            if (compareResult == DSCompareResult.EQUAL_TO) {
                // this comparator found them to be equal, go to the next one
                continue;
            } else {
                // not equal, no need to look any deeper
                return compareResult;
            }
        }

        // all comparators found them to be equal, so:
        return DSCompareResult.EQUAL_TO;
    }
}
