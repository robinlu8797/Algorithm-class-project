package com.abc.ds.compare;

public interface DSComparable<T> {
	DSCompareResult compareTo(T other);
}
