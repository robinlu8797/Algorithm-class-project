package com.abc.ds.set;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.programix.util.*;

public class ArrayDSSet<T> implements DSSet<T>, DSCountable {
    private static final int NOT_FOUND_INDEX = -1; // note private, just for us

    private T[] slots;
    private int count;
    private final Class<T> itemType;
    private final T[] itemTypeZeroLenArray; // shared, immutable
    private final DSIterator<T> emptyIterator; // shared, immutable
    private final int percentToGrowCapacity;

    public ArrayDSSet(Class<T> itemType,
                      int initialCapacity,
                      int percentToGrowCapacity) {

        ObjectTools.paramNullCheck(itemType, "itemType");
        if ( percentToGrowCapacity < 1 ) {
            throw new IllegalArgumentException("percentToGrowCapacity=" +
                percentToGrowCapacity + ", but must be at least 1");
        }
        this.itemType = itemType;
        this.percentToGrowCapacity = percentToGrowCapacity;

        itemTypeZeroLenArray = DSTools.createArrayFromType(itemType, 0);
        slots = DSTools.createArrayFromType(itemType, initialCapacity);
        emptyIterator = EmptyDSIterator.createForType();
        count = 0;
    }

    public ArrayDSSet(Class<T> itemType) {
        this(itemType, 100, 20);
    }

    private void growSlotsIfNeeded(int additionalCount) {
        if ( count + additionalCount > slots.length ) {
            int newCapacity = Math.max(
                count + additionalCount,
                (slots.length * (100 + percentToGrowCapacity)) / 100);
            T[] newSlots = DSTools.createArrayFromType(itemType, newCapacity);
            System.arraycopy(slots, 0, newSlots, 0, count);
            slots = newSlots;
        }
    }

    @Override
    public Class<T> getItemType() {
        return itemType;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public void clear() {
        if (count > 0) {
            Arrays.fill(slots, null);
            count = 0;
        }
    }

    @Override
    public boolean add(T item) {
        if (contains(item)) return false; // item already in this set

        growSlotsIfNeeded(1);
        slots[count] = item;
        count++;
        return true; // because we added this item
    }

    @Override
    public int addAll(@SuppressWarnings("unchecked") T... items) {
        if ( ObjectTools.isEmpty(items) ) {
            return 0;
        }
        int addCount = 0;
        for ( T item : items ) {
            if (add(item)) addCount++;
        }
        return addCount;
    }

    @Override
    public int addAll(DSIterable<T> items) {
        if (items == null) return 0; // nothing to add

        int addCount = 0;
        for ( T item : DSTools.asJavaIterable(items) ) {
            if (add(item)) addCount++;
        }
        return addCount;
    }

    // private helper method used internally.
    // Concept of index has no meaning outside of this set, but internally,
    // it tells us which slot to use
    private int indexOf(T item) {
        for ( int i = 0; i < count; i++ ) {
            if (ObjectTools.isSame(item, slots[i])) {
                return i;
            }
        }
        return NOT_FOUND_INDEX;
    }

    // private helper method used internally.
    // Concept of index has no meaning outside of this set, but internally,
    // it tells us which slot to use
    private T removeAtIndex(int index) {
        T item = slots[index];
        for ( int i = index; i < count - 1; i++ ) {
            slots[i] = slots[i + 1];
        }
        slots[count - 1] = null; // don't inhibit garbage collection
        count--;
        return item;
    }

    @Override
    public boolean remove(T item) {
        int idx = indexOf(item);
        if ( idx == NOT_FOUND_INDEX ) {
            return false; // not found
        }
        removeAtIndex(idx);
        return true; // found and removed
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return removeMatchesCommon(filter,
            DSMatchHelper.createMatchAndCount(itemType, count / 4, 50))
                .getMatches();
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return removeMatchesCommon(
            filter, DSMatchHelper.createCountOnly(itemType)).getMatchCount();
    }

    private DSMatchHelper<T> removeMatchesCommon(DSFilter<T> filter,
                                                 DSMatchHelper<T> matchHelper) {
        int dstIdx = 0;
        for ( int srcIdx = 0; srcIdx < count; srcIdx++ ) {
            T item = slots[srcIdx];
            if ( filter.matches(item) ) {
                matchHelper.append(item);
            } else {
                if ( dstIdx < srcIdx ) {
                    slots[dstIdx] = item;
                }
                dstIdx++;
            }
        }

        for ( ; dstIdx < count; dstIdx++ ) {
            slots[dstIdx] = null; // don't inhibit garbage collection
        }

        count -= matchHelper.getMatchCount();
        return matchHelper;
    }

    @Override
    public T[] removeAll() {
        if (isEmpty()) return itemTypeZeroLenArray;

        T[] results = peekAll();
        clear();
        return results;
    }

    @Override
    public boolean contains(T item) {
        return indexOf(item) != NOT_FOUND_INDEX;
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return DSMatchHelper.createMatchAndCount(itemType, count / 4, 50)
            .append(this, filter)
            .getMatches();
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return DSMatchHelper.createCountOnly(itemType)
            .append(this, filter)
            .getMatchCount();
    }

    @Override
    public T[] peekAll() {
        if ( isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        T[] results = DSTools.createArrayFromType(itemType, count);
        System.arraycopy(slots, 0, results, 0, count);
        return results;
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        // do this via peekAll() since we don't know if the action will
        // add or remove anything from this sack.
        for ( T item : peekAll() ) {
            action.perform(item);
        }
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        // do this via peekMatches() since we don't know if the action will
        // add or remove anything from this sack.
        T[] matches = peekMatches(filter);
        for ( T item : matches ) {
            action.perform(item);
        }
        return matches.length;
    }

    @Override
    public DSIterator<T> createIterator() {
        return isEmpty() ? emptyIterator : new ForwardIterator(0);
    }

    @Override
    public int union(DSSet<T> otherSet) {
        return addAll(otherSet);
    }

    @Override
    public void intersection(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.isEmpty()) {
            // nothing to find in both, so clear us out
            clear();
        }

        removeAndCountMatches(new DSFilter<T>() {
            @Override
            public boolean matches(T item) {
                return !otherSet.contains(item);
            }
        });
    }

    @Override
    public void subtract(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.isEmpty()) return; // nothing to subtract

        removeAndCountMatches(new DSFilter<T>() {
            @Override
            public boolean matches(T item) {
                return otherSet.contains(item);
            }
        });
    }

    private class ForwardIterator implements DSIterator<T> {
        private int currentIndex;

        public ForwardIterator(int startingIndex) {
            currentIndex = Math.max(startingIndex, 0) - 1;
        }

        @Override
        public boolean hasNext() {
            return (currentIndex + 1) < count;
        }

        @Override
        public T next() throws NoSuchElementException {
            if (!hasNext()) throw new NoSuchElementException();
            currentIndex++;
            return slots[currentIndex];
        }
    } // type ForwardIterator
}
