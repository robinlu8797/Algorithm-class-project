package com.abc.ds.set.tests.gui;

import com.abc.ds.*;
import com.abc.ds.set.*;
import com.abc.ds.set.tests.*;

public class GuiTestArrayDSSet {
    public static void main(String[] args) {
        GuiTestDSSet.runTests("ArrayDSSet", new DSSetFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSet<T> set) {
                return DSOrdering.createUnordered();
            }

            @Override
            public <T> DSSet<T> create(Class<T> itemType,
                                       int initialCapacity,
                                       int percentToGrowCapacity) {
                return new ArrayDSSet<>(itemType, initialCapacity, percentToGrowCapacity);
            }

            @Override
            public <T> DSSet<T> create(Class<T> itemType) {
                return new ArrayDSSet<>(itemType);
            }
        });
    }
}
