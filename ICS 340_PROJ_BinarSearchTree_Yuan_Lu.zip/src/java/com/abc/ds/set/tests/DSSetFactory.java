package com.abc.ds.set.tests;

import com.abc.ds.*;
import com.abc.ds.set.*;

public interface DSSetFactory {

    <T> DSOrdering<T> getOrdering(DSSet<T> set);

    <T> DSSet<T> create(Class<T> itemType);

    <T> DSSet<T> create(Class<T> itemType,
                         int initialCapacity,
                         int percentToGrowCapacity);
}
