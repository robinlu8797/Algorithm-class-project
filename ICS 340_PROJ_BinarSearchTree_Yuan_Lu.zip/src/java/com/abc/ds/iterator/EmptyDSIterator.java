package com.abc.ds.iterator;

import java.util.*;

/**
 * An empty iterator which meets the contract, but iterates over zero items.
 * Typically, internal implementations will use this when they are known
 * to be empty.
 * Keep in mind that since instances are immutable, there's no need for more
 * than one of each generic type.
 * Instances are immutable.
 */
public final class EmptyDSIterator<T> implements DSIterator<T> {
    private static final EmptyDSIterator<?> SHARED_INSTANCE = new EmptyDSIterator<>();

    /** private, use {@link #createForType()} instead */
    private EmptyDSIterator() {
    }

    /**
     * Returns a shared singleton coerced into the correct type. This is
     * only because instances are immutable and the type T doesn't matter since
     * we can never actually call next() to get it.
     */
    @SuppressWarnings("unchecked")
    public static <T> DSIterator<T> createForType() {
        return (DSIterator<T>) SHARED_INSTANCE;
    }

    @Override
    public boolean hasNext() {
        return false;
    }

    @Override
    public T next() throws NoSuchElementException {
        throw new NoSuchElementException("empty, cannot call next()");
    }
}
