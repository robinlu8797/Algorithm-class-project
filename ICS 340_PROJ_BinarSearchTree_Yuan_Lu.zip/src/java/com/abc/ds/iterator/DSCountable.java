package com.abc.ds.iterator;

/**
 * Implemented by data structures who easily know their item count.
 */
public interface DSCountable {
    /** Returns the number of items currently in the data structure. */
    int getCount();

    /** Returns true if there are no items currently in the data structure. */
    boolean isEmpty();
}
