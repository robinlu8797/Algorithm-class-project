package com.abc.ds.linkedlist.tests.gui;

import com.abc.ds.linkedlist.*;
import com.abc.ds.linkedlist.tests.*;

public class GuiTestDoublyDSLinkedList {
    public static void main(String[] args) {
        GuiTestDSLinkedList.runTests("DoublyDSLinkedList", new DSLinkedListFactory() {
            @Override
            public <T> DSLinkedList<T> create(Class<T> itemType) {
                return new DoublyDSLinkedList<>(itemType);
            }
        });
    }
}
