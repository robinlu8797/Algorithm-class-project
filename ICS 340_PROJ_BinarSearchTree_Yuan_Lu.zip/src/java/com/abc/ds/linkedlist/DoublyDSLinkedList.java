package com.abc.ds.linkedlist;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.programix.util.*;

public class DoublyDSLinkedList<T> implements DSLinkedList<T> {
    private final DllNode<T> sentinel;
    private int count;

    private final Class<T> itemType;
    private final Class<DSLinkedList.Node<T>> nodeType;
    private final T[] itemTypeZeroLengthArray; // shared, immutable
    private final DSLinkedList.Node<T>[] nodeTypeZeroLengthArray; // shared, immutable
    private final DSIterator<T> emptyItemIterator; // shared, immutable
    private final DSIterator<DSLinkedList.Node<T>> emptyNodeIterator; // shared, immutable

    public DoublyDSLinkedList(Class<T> itemType) {
        ObjectTools.paramNullCheck(itemType, "itemType");

        this.itemType = itemType;
        nodeType = createNodeType();
        itemTypeZeroLengthArray = DSTools.createArrayFromType(itemType, 0);
        nodeTypeZeroLengthArray = DSTools.createArrayFromType(nodeType, 0);
        emptyItemIterator = EmptyDSIterator.createForType();
        emptyNodeIterator = EmptyDSIterator.createForType();

        sentinel = new DllNode<T>(this, null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        count = 0;
    }

    @SuppressWarnings("unchecked")
    private Class<DSLinkedList.Node<T>> createNodeType() {
        return (Class<DSLinkedList.Node<T>>)
            DSTools.coerceClassType(DSLinkedList.Node.class);
    }

    private void confirmValidIndex(int index) throws IndexOutOfBoundsException {
        if ( isEmpty() ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", list is empty, no index values are valid");
        } else if ( index < 0 || index >= count ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", must be in the range [0.." +
                (count - 1) + "]");
        }
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if ( isEmpty() ) {
            throw new NoSuchElementException("list is empty");
        }
    }

    @Override
    public Class<T> getItemType() {
        return itemType;
    }

    @Override
    public Class<DSLinkedList.Node<T>> getNodeType() {
        return nodeType;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public void clear() {
        for ( DllNode<T> node = sentinel.next; node != sentinel; node = node.next ) {
            node.owner = null;
        }

        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        count = 0;
    }

    @Override
    public DSIterator<T> createIterator() {
        return isEmpty() ? emptyItemIterator : new NextIterator<>(sentinel.next);
    }

    @Override
    public DSIterator<T> createReverseIterator() {
        return isEmpty() ? emptyItemIterator : new PrevIterator<>(sentinel.prev);
    }

    @Override
    public DSIterator<DSLinkedList.Node<T>> createNodeIterator() {
        return isEmpty() ? emptyNodeIterator : new NextNodeIterator<>(sentinel.next);
    }

    @Override
    public DSIterator<DSLinkedList.Node<T>> createNodeReverseIterator() {
        return isEmpty() ? emptyNodeIterator : new PrevNodeIterator<>(sentinel.prev);
    }

    @Override
    public DSLinkedList.Node<T> insertFirst(T newPayload) {
        return sentinel.insertAfter(newPayload);
    }

    @Override
    public DSLinkedList.Node<T> insertLast(T newPayload) {
        return sentinel.insertBefore(newPayload);
    }

    @Override
    public DSLinkedList.Node<T> peekAtIndex(int index)
            throws IndexOutOfBoundsException {

        confirmValidIndex(index);
        // if we get here, there is at least one item in the list

        if (index < count / 2) {
            // closer to the beginning
            DllNode<T> currNode = sentinel.next;
            int numberOfLinksToFollow = index;
            for ( int i = 0; i < numberOfLinksToFollow; i++ ) {
                currNode = currNode.next;
            }
            return currNode;
        } else {
            // closer to the end, start at the end and count backwards
            DllNode<T> currNode = sentinel.prev;
            int numberOfLinksToFollow = count - index - 1;
            for ( int i = 0; i < numberOfLinksToFollow; i++ ) {
                currNode = currNode.prev;
            }
            return currNode;
        }
    }

    @Override
    public DSLinkedList.Node<T> peekFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return sentinel.next;
    }

    @Override
    public DSLinkedList.Node<T> peekLast() throws NoSuchElementException {
        confirmNotEmpty();
        return sentinel.prev;
    }

    @Override
    public DSLinkedList.Node<T>[] peekMatches(DSFilter<T> filter) {
        if (isEmpty() || filter == null) return nodeTypeZeroLengthArray;

        DSMatchHelper<DSLinkedList.Node<T>> matchHelper = null; // lazy init
        for ( DllNode<T> node = sentinel.next; node != sentinel; node = node.next ) {
            if (filter.matches(node.payload)) {
                if (matchHelper == null) {
                    matchHelper = DSMatchHelper.createMatchAndCount(nodeType, 8, 50);
                }
                matchHelper.append(node);
            }
        }
        return matchHelper != null ? matchHelper.getMatches() : nodeTypeZeroLengthArray;
    }

    @Override
    public DSLinkedList.Node<T>[] peekMatches(T itemToMatch) {
        if (isEmpty()) return nodeTypeZeroLengthArray;

        DSMatchHelper<DSLinkedList.Node<T>> matchHelper = null; // lazy init
        for ( DllNode<T> node = sentinel.next; node != sentinel; node = node.next ) {
            if (ObjectTools.isSame(itemToMatch, node.payload)) {
                if (matchHelper == null) {
                    matchHelper = DSMatchHelper.createMatchAndCount(nodeType, 5, 50);
                }
                matchHelper.append(node);
            }
        }
        return matchHelper != null ? matchHelper.getMatches() : nodeTypeZeroLengthArray;
    }

    @Override
    public DSLinkedList.Node<T>[] peekAll() {
        //return peekMatches(new MatchEverythingDSFilter<T>());

        if (isEmpty()) return nodeTypeZeroLengthArray;

        DSLinkedList.Node<T>[] items = DSTools.createArrayFromType(nodeType, count);
        DllNode<T> node = sentinel.next;
        for (int i = 0; i < items.length; i++, node = node.next) {
            items[i] = node;
        }
        return items;
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        if (isEmpty() || filter == null) return 0;

        int matchCount = 0;
        for ( DllNode<T> node = sentinel.next; node != sentinel; node = node.next ) {
            if (filter.matches(node.payload)) matchCount++;
        }
        return matchCount;
    }

    @Override
    public int countMatches(T itemToMatch) {
        if (isEmpty()) return 0;

        int matchCount = 0;
        for ( DllNode<T> node = sentinel.next; node != sentinel; node = node.next ) {
            if (ObjectTools.isSame(itemToMatch, node.payload)) matchCount++;
        }
        return matchCount;
    }

    @Override
    public T[] extractPayloads(DSLinkedList.Node<T>[] nodes) {
        if (nodes == null || nodes.length == 0) return itemTypeZeroLengthArray;

        T[] payloads = DSTools.createArrayFromType(itemType, nodes.length);
        for ( int i = 0; i < payloads.length; i++ ) {
            payloads[i] = nodes[i].getPayload();
        }
        return payloads;
    }

    public DSFilter<DSLinkedList.Node<T>> createNodeFilter(final DSFilter<T> itemFilter) {
        if (itemFilter == null) return new MatchNothingDSFilter<>();

        return new DSFilter<DSLinkedList.Node<T>>() {
            @Override
            public boolean matches(DSLinkedList.Node<T> node) {
                return node != null && itemFilter.matches(node.getPayload());
            }
        };
    }

    private static class DllNode<T> implements DSLinkedList.Node<T> {
        public DoublyDSLinkedList<T> owner;
        public DllNode<T> next;
        public DllNode<T> prev;
        private T payload;

        public DllNode(DoublyDSLinkedList<T> owner, T payload) {
            ObjectTools.paramNullCheck(owner, "owner");
            this.owner = owner;
            this.payload = payload;
        }

        private void confirmStillInList() throws IllegalStateException {
            if ( owner == null ) {
                throw new IllegalStateException(
                    "operations cannot be done; node is no longer in a list");
            }
        }

        @Override
        public T getPayload() {
            return payload;
        }

        @Override
        public void setPayload(T newPayload) {
            this.payload = newPayload;
        }

        @Override
        public T delete() {
            confirmStillInList();
            prev.next = next;
            next.prev = prev;
            owner.count--;
            owner = null; // no longer in this list
            return payload;
        }

        @Override
        public DSLinkedList.Node<T> insertBefore(T newPayload) {
            confirmStillInList();
            DllNode<T> newNode = new DllNode<T>(owner, newPayload);
            newNode.prev = prev;
            newNode.next = this;
            newNode.prev.next = newNode;
            newNode.next.prev = newNode;
            owner.count++;
            return newNode;
        }

        @Override
        public DSLinkedList.Node<T> insertAfter(T newPayload) {
            return next.insertBefore(newPayload);
        }

        @Override
        public DSIterator<T> createIteratorThisToEnd() {
            confirmStillInList();
            return owner.sentinel == this ? owner.emptyItemIterator : new NextIterator<T>(this);
        }

        @Override
        public DSIterator<T> createIteratorNextToEnd() {
            confirmStillInList();
            return owner.sentinel == next ? owner.emptyItemIterator : new NextIterator<T>(next);
        }

        @Override
        public DSIterator<T> createReverseIteratorThisToStart() {
            confirmStillInList();
            return owner.sentinel == this ? owner.emptyItemIterator : new PrevIterator<T>(this);
        }

        @Override
        public DSIterator<T> createReverseIteratorPrevToStart() {
            confirmStillInList();
            return owner.sentinel == prev ? owner.emptyItemIterator : new NextIterator<T>(prev);
        }

        @Override
        public DSIterator<DSLinkedList.Node<T>> createNodeIteratorThisToEnd() {
            confirmStillInList();
            return owner.sentinel == this ? owner.emptyNodeIterator : new NextNodeIterator<T>(this);
        }

        @Override
        public DSIterator<DSLinkedList.Node<T>> createNodeIteratorNextToEnd() {
            confirmStillInList();
            return owner.sentinel == next ? owner.emptyNodeIterator : new NextNodeIterator<T>(next);
        }

        @Override
        public DSIterator<DSLinkedList.Node<T>> createNodeReverseIteratorThisToStart() {
            confirmStillInList();
            return owner.sentinel == this ? owner.emptyNodeIterator : new PrevNodeIterator<T>(this);
        }

        @Override
        public DSIterator<DSLinkedList.Node<T>> createNodeReverseIteratorPrevToStart() {
            confirmStillInList();
            return owner.sentinel == prev ? owner.emptyNodeIterator : new NextNodeIterator<T>(prev);
        }
    } // type DllNode

    private static class NextIterator<T> implements DSIterator<T> {
        private final NextNodeIterator<T> nodeIterator;

        public NextIterator(DllNode<T> nodeToStartFrom) {
            nodeIterator = new NextNodeIterator<>(nodeToStartFrom);
        }

        @Override
        public boolean hasNext() {
            return nodeIterator.hasNext();
        }

        @Override
        public T next() throws NoSuchElementException {
            return nodeIterator.next().getPayload();
        }
    } // type NextIterator

    private static class PrevIterator<T> implements DSIterator<T> {
        private final PrevNodeIterator<T> nodeIterator;

        public PrevIterator(DllNode<T> nodeToStartFrom) {
            nodeIterator = new PrevNodeIterator<>(nodeToStartFrom);
        }

        @Override
        public boolean hasNext() {
            return nodeIterator.hasNext();
        }

        @Override
        public T next() throws NoSuchElementException {
            return nodeIterator.next().getPayload();
        }
    } // type PrevIterator

    private static class NextNodeIterator<T> implements DSIterator<DSLinkedList.Node<T>> {
        private DllNode<T> node;

        public NextNodeIterator(DllNode<T> nodeToStartFrom) {
            if (nodeToStartFrom == nodeToStartFrom.owner.sentinel) {
                throw new IllegalArgumentException("cannot have the sentinel be part of the iteration");
            }
            // initially positioned 'before' the next item to return
            node = nodeToStartFrom.prev; // step back to the one before
        }

        @Override
        public boolean hasNext() {
            return node.next != node.owner.sentinel;
        }

        @Override
        public DSLinkedList.Node<T> next() throws NoSuchElementException {
            if ( !hasNext() ) {
                throw new NoSuchElementException(
                    "next() cannot be called because hasNext() is false");
            }

            node = node.next;
            return node;
        }
    } // type NextNodeIterator

    private static class PrevNodeIterator<T> implements DSIterator<DSLinkedList.Node<T>> {
        private DllNode<T> node;

        public PrevNodeIterator(DllNode<T> nodeToStartFrom) {
            if (nodeToStartFrom == nodeToStartFrom.owner.sentinel) {
                throw new IllegalArgumentException("cannot have the sentinel be part of the iteration");
            }
            // initially positioned 'before' the next item to return
            node = nodeToStartFrom.next; // step forward to the one after since we're going backwards
        }

        @Override
        public boolean hasNext() {
            return node.prev != node.owner.sentinel;
        }

        @Override
        public DSLinkedList.Node<T> next() throws NoSuchElementException {
            if ( !hasNext() ) {
                throw new NoSuchElementException(
                    "next() cannot be called because hasNext() is false");
            }

            node = node.prev;
            return node;
        }
    } // type PrevNodeIterator
}
