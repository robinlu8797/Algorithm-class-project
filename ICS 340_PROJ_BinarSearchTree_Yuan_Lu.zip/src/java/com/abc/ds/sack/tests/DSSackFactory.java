package com.abc.ds.sack.tests;

import com.abc.ds.*;
import com.abc.ds.sack.*;

public interface DSSackFactory {
    /**
     * Returns true if the underlying data structure allows duplicate items.
     */
    boolean allowDuplicates();

    <T> DSOrdering<T> getOrdering(DSSack<T> sack);

    <T> DSSack<T> create(Class<T> itemType);

    <T> DSSack<T> create(Class<T> itemType,
                         int initialCapacity,
                         int percentToGrowCapacity);
}
