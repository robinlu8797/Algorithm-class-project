package com.abc.ds.filter;

/**
 * A {@link DSFilter} which matches <em>nothing</em> (always returns false).
 */
public class MatchNothingDSFilter<T> implements DSFilter<T> {
    public MatchNothingDSFilter() {
    }

    @Override
    public boolean matches(T item) {
        return false;
    }
}
