package com.abc.ds.list;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.programix.util.*;

public class ArrayDSList<T> implements DSList<T>, DSCountable {
    private T[] slots;
    private int count;
    private final Class<T> itemType;
    private final T[] itemTypeZeroLenArray; // shared, immutable
    private final DSIterator<T> emptyIterator; // shared, immutable
    private final int initialCapacity;
    private final int percentToGrowCapacity;

    public ArrayDSList(Class<T> itemType,
                       int initialCapacity,
                       int percentToGrowCapacity) {

        ObjectTools.paramNullCheck(itemType, "itemType");
        initialCapacity = initialCapacity >= 0 ? initialCapacity : 0;
        percentToGrowCapacity = percentToGrowCapacity >= 1 ? percentToGrowCapacity : 1;

        this.itemType = itemType;
        this.initialCapacity = initialCapacity;
        this.percentToGrowCapacity = percentToGrowCapacity;

        itemTypeZeroLenArray = DSTools.createArrayFromType(itemType, 0);
        slots = itemTypeZeroLenArray; // lazy creation of array with initialCapacity
        emptyIterator = EmptyDSIterator.createForType();
        count = 0;
    }

    public ArrayDSList(Class<T> itemType) {
        this(itemType, 100, 20);
    }

    private void growSlotsIfNeeded(int additionalCount) {
        if ( count + additionalCount > slots.length ) {
            int newCapacity = Math.max(
                initialCapacity, // if this is the first time, make sure we jump all the way up to initial capacity
                Math.max(
                    count + additionalCount,
                    (slots.length * (100 + percentToGrowCapacity)) / 100
                )
            );

            T[] newSlots = DSTools.createArrayFromType(itemType, newCapacity);
            System.arraycopy(slots, 0, newSlots, 0, count);
            slots = newSlots;
        }
    }

    private void confirmValidIndex(int index) throws IndexOutOfBoundsException {
        if ( isEmpty() ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", list is empty, no index values are valid");
        } else if ( index < 0 || index >= count ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", must be in the range [0.." +
                (count - 1) + "]");
        }
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if ( isEmpty() ) {
            throw new NoSuchElementException("list is empty");
        }
    }

    @Override
    public Class<T> getItemType() {
        return itemType;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public void clear() {
        if (count > 0) {
            Arrays.fill(slots, null);
            count = 0;
        }
    }

    @Override
    public boolean add(T item) {
        growSlotsIfNeeded(1);
        slots[count] = item;
        count++;
        return true; // always return true for lists
    }

    @Override
    public int addAll(@SuppressWarnings("unchecked") T... items) {
        if ( ObjectTools.isEmpty(items) ) {
            return 0;
        }
        growSlotsIfNeeded(items.length);
        for ( T item : items ) {
            slots[count] = item;
            count++;
        }
        return items.length;
    }

    @Override
    public int addAll(DSIterable<T> items) {
        if (items == null) return 0; // nothing to add

        if (items instanceof DSCountable) {
            DSCountable countable = (DSCountable) items;
            if (countable.isEmpty()) return 0; // nothing to add

            growSlotsIfNeeded(countable.getCount());
            for ( T item : DSTools.asJavaIterable(items) ) {
                slots[count] = item;
                count++;
            }
            return ((DSCountable) items).getCount();
        }

        int addCount = 0;
        for ( T item : DSTools.asJavaIterable(items) ) {
            if (add(item)) addCount++;
        }
        return addCount;
    }

    @Override
    public void insertBefore(int index, T item)
            throws IndexOutOfBoundsException {

        if ( index == count ) {
            add(item);
        } else {
            confirmValidIndex(index);
            growSlotsIfNeeded(1);
            for ( int i = count; i > index ; i-- ) {
                slots[i] = slots[i - 1];
            }
            slots[index] = item;
            count++;
        }
    }

    @Override
    public void insertFirst(T item) {
        insertBefore(0, item);
    }

    @Override
    public int firstIndexOf(T item, int fromIndex) {
        if (fromIndex >= count) return NOT_FOUND_INDEX;
        fromIndex = fromIndex >= 0 ? fromIndex : 0;
        for ( int i = fromIndex; i < count; i++ ) {
            if (ObjectTools.isSame(item, slots[i])) {
                return i;
            }
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int firstIndexOf(T item) {
        return firstIndexOf(item, 0);
    }

    @Override
    public int lastIndexOf(T item, int fromIndex) {
        if (fromIndex < 0) return NOT_FOUND_INDEX;
        fromIndex = fromIndex < count ? fromIndex : count - 1;
        for (int i = fromIndex; i >= 0; i--) {
            if (ObjectTools.isSame(item, slots[i])) {
                return i;
            }
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int lastIndexOf(T item) {
        return lastIndexOf(item, count -1);
    }

    @Override
    public boolean remove(T item) {
        int idx = firstIndexOf(item);
        if ( idx == NOT_FOUND_INDEX ) {
            return false;
        }
        removeAtIndex(idx);
        return true;
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return removeMatchesCommon(filter,
            DSMatchHelper.createMatchAndCount(itemType, count / 4, 50))
                .getMatches();
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return removeMatchesCommon(
            filter, DSMatchHelper.createCountOnly(itemType)).getMatchCount();
    }

    private DSMatchHelper<T> removeMatchesCommon(DSFilter<T> filter,
                                                 DSMatchHelper<T> matchHelper) {
        int dstIdx = 0;
        for ( int srcIdx = 0; srcIdx < count; srcIdx++ ) {
            T item = slots[srcIdx];
            if ( filter.matches(item) ) {
                matchHelper.append(item);
            } else {
                if ( dstIdx < srcIdx ) {
                    slots[dstIdx] = item;
                }
                dstIdx++;
            }
        }

        for ( ; dstIdx < count; dstIdx++ ) {
            slots[dstIdx] = null; // don't inhibit garbage collection
        }

        count -= matchHelper.getMatchCount();
        return matchHelper;
    }

    @Override
    public T[] removeAll() {
        if (isEmpty()) return itemTypeZeroLenArray;

        T[] results = peekAll();
        clear();
        return results;
    }

    @Override
    public T removeAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);
        T item = slots[index];
        for ( int i = index; i < count - 1; i++ ) {
            slots[i] = slots[i + 1];
        }
        slots[count - 1] = null; // don't inhibit garbage collection
        count--;
        return item;
    }

    @Override
    public T removeFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return removeAtIndex(0);
    }

    @Override
    public T removeLast() throws NoSuchElementException {
        confirmNotEmpty();
        return removeAtIndex(count - 1);
    }

    @Override
    public boolean contains(T item) {
        return firstIndexOf(item) != NOT_FOUND_INDEX;
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return DSMatchHelper.createMatchAndCount(itemType, count / 4, 50)
            .append(this, filter)
            .getMatches();
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return DSMatchHelper.createCountOnly(itemType)
            .append(this, filter)
            .getMatchCount();
    }

    @Override
    public T[] peekAll() {
        if ( isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        T[] results = DSTools.createArrayFromType(itemType, count);
        System.arraycopy(slots, 0, results, 0, count);
        return results;
    }

    @Override
    public T peekAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);
        return slots[index];
    }

    @Override
    public T peekFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return peekAtIndex(0);
    }

    @Override
    public T peekLast() throws NoSuchElementException {
        confirmNotEmpty();
        return peekAtIndex(count - 1);
    }

    @Override
    public T replaceAtIndex(int index, T replacementItem)
            throws IndexOutOfBoundsException {

        confirmValidIndex(index);
        T oldItem = slots[index];
        slots[index] = replacementItem;
        return oldItem;
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        // do this via peekAll() since we don't know if the action will
        // add or remove anything from this sack.
        for ( T item : peekAll() ) {
            action.perform(item);
        }
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        // do this via peekMatches() since we don't know if the action will
        // add or remove anything from this sack.
        T[] matches = peekMatches(filter);
        for ( T item : matches ) {
            action.perform(item);
        }
        return matches.length;
    }

    @Override
    public DSIterator<T> createIterator() {
        return createIteratorToEnd(0);
    }

    @Override
    public DSIterator<T> createIteratorToEnd(int startingIndex) {
        return isEmpty() || startingIndex >= count
            ? emptyIterator : new ForwardIterator(startingIndex);
    }

    @Override
    public DSIterator<T> createReverseIterator() {
        return createReverseIteratorToStart(count - 1);
    }

    @Override
    public DSIterator<T> createReverseIteratorToStart(int startingIndex) {
        return isEmpty() || startingIndex < 0
            ? emptyIterator : new ReverseIterator(startingIndex);
    }

    private class ForwardIterator implements DSIterator<T> {
        private int currentIndex;

        public ForwardIterator(int startingIndex) {
            currentIndex = Math.max(startingIndex, 0) - 1;
        }

        @Override
        public boolean hasNext() {
            return (currentIndex + 1) < count;
        }

        @Override
        public T next() throws NoSuchElementException {
            if (!hasNext()) throw new NoSuchElementException();
            currentIndex++;
            return slots[currentIndex];
        }
    } // type ForwardIterator

    private class ReverseIterator implements DSIterator<T> {
        private int currentIndex;

        public ReverseIterator(int startingIndex) {
            currentIndex = Math.min(startingIndex, count - 1) + 1;
        }

        @Override
        public boolean hasNext() {
            return (currentIndex - 1) >= 0;
        }

        @Override
        public T next() throws NoSuchElementException {
            if (!hasNext()) throw new NoSuchElementException();
            currentIndex--;
            return slots[currentIndex];
        }
    } // type ReverseIterator
}
