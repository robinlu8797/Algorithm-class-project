package com.abc.ds.list.tests;

import com.abc.ds.list.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSListReplaceAtIndex extends TestDSListBase {
    public TestDSListReplaceAtIndex(DSListFactory factory) {
        super("replaceAtIndex", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testWithOne();
        testWithTwo();
        testWithSeveral();
        testConfirmStillSaneAfterException();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - testing replaceAtIndex on empty -");
        DSList<String> ds = createDS();
        replaceAtBadIndex(ds, 0, "apple");
        replaceAtBadIndex(ds, -1, "apple");
        replaceAtBadIndex(ds, 999, "apple");
    }

    private void testWithOne() {
        outlnSeparator();
        outln(" - testing replaceAtIndex on one item -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        replaceAtBadIndex(ds, -1, "banana");
        replaceAtBadIndex(ds, 1, "cherry");
        replaceAtIndex(ds, 0, "watermelon", "apple");
        checkPeekAll(ds, "watermelon");
    }

    private void testWithTwo() {
        outlnSeparator();
        outln(" - testing replaceAtIndex on two items -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        add(ds, "banana");
        replaceAtIndex(ds, 1, "grape", "banana");
        replaceAtIndex(ds, 0, "fig", "apple");
        checkPeekAll(ds, "fig", "grape");
    }

    private void testWithSeveral() {
        outlnSeparator();
        outln(" - testing replaceAtIndex on several items -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry", "fig");

        replaceAtIndex(ds, 3, "kiwi", "date");
        replaceAtIndex(ds, 1, "lemon", "banana");
        replaceAtIndex(ds, 5, "mango", "fig");
        checkPeekAll(ds, "apple", "lemon", "cherry", "kiwi", "elderberry", "mango");
    }

    private void testConfirmStillSaneAfterException() {
        outlnSeparator();
        outln(" - testing replaceAtIndex, expect exception, check sanity -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        replaceAtBadIndex(ds, -7, "orange");
        outln("confirming data structure still sane after exception...");
        checkPeekAll(ds, "apple", "banana", "cherry");
    }

    private void replaceAtIndex(DSList<String> ds,
                                final int index,
                                final String newItem,
                                final String expectedRelacedItem) {

        outln("replaceAtIndex(" + index + ", " + StringTools.quoteWrap(newItem) + ")",
            ds.replaceAtIndex(index, newItem), expectedRelacedItem);
    }

    private void replaceAtBadIndex(DSList<String> ds,
                                  final int index,
                                  final String newItem) {

        checkBadIndex(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "replaceAtIndex(" + index + ", " + StringTools.quoteWrap(newItem) + ")";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.replaceAtIndex(index, newItem);
            }
        });
    }

}
