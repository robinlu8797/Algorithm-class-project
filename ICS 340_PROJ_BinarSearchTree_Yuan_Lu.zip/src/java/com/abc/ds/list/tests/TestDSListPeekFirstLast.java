package com.abc.ds.list.tests;

import com.abc.ds.list.*;

/* deliberate package access */
class TestDSListPeekFirstLast extends TestDSListBase {
    public TestDSListPeekFirstLast(DSListFactory factory) {
        super("peekFirst, peekLast", factory);
    }

    @Override
    protected void performTests() {
        testPeekFirstJustOneWithPlenty();
        testPeekLastJustOneWithPlenty();
        testPeekFirstOnlyOne();
        testPeekLastOnlyOne();
        testPeekFirstSeveralTimes();
        testPeekLastSeveralTimes();
        testPeekFirstOnEmpty();
        testPeekLastOnEmpty();
    }

    private void testPeekFirstJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing peekFirst(), just one with plenty -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("peekFirst()", ds.peekFirst(), "apple");
    }

    private void testPeekLastJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing peekLast(), just one with plenty -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("peekLast()", ds.peekLast(), "cherry");
    }

    private void testPeekFirstOnlyOne() {
        outlnSeparator();
        outln(" - testing peekFirst(), only one available to peek -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("peekFirst()", ds.peekFirst(), "apple");
        checkCount(ds, 1);
    }

    private void testPeekLastOnlyOne() {
        outlnSeparator();
        outln(" - testing peekLast(), only one available to peek -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("peekLast()", ds.peekLast(), "apple");
        checkCount(ds, 1);
    }

    private void testPeekFirstSeveralTimes() {
        outlnSeparator();
        outln(" - testing peekFirst(), called several times -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekFirst()", ds.peekFirst(), "apple");
        checkPeekAll(ds, "apple", "banana", "cherry", "date", "elderberry");
    }

    private void testPeekLastSeveralTimes() {
        outlnSeparator();
        outln(" - testing peekLast(), called several times -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("peekLast()", ds.peekLast(), "cherry");
        outln("peekLast()", ds.peekLast(), "cherry");
        outln("peekLast()", ds.peekLast(), "cherry");
        checkPeekAll(ds, "apple", "banana", "cherry");
    }

    private void testPeekFirstOnEmpty() {
        outlnSeparator();
        outln(" - testing peekFirst() on empty, expect exception -");
        DSList<String> ds = createDS();
        peekFirstExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekLast()", ds.peekLast(), "banana");
    }

    private void testPeekLastOnEmpty() {
        outlnSeparator();
        outln(" - testing peekLast() on empty, expect exception -");
        DSList<String> ds = createDS();
        peekLastExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekLast()", ds.peekLast(), "banana");
    }

    private void peekFirstExpectException(DSList<String> ds) {
        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekFirst()";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.peekFirst();
            }
        });
    }

    private void peekLastExpectException(DSList<String> ds) {
        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekLast()";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.peekLast();
            }
        });
    }
}
