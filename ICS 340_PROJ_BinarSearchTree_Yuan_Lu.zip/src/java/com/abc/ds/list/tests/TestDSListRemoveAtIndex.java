package com.abc.ds.list.tests;

import com.abc.ds.list.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSListRemoveAtIndex extends TestDSListBase {
    public TestDSListRemoveAtIndex(DSListFactory factory) {
        super("removeAtIndex", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testWithOne();
        testWithTwo();
        testWithSeveral();
        testConfirmStillSaneAfterException();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - testing removeAtIndex on empty -");
        DSList<String> ds = createDS();
        removeAtBadIndex(ds, 0);
        removeAtBadIndex(ds, -1);
        removeAtBadIndex(ds, 999);
    }

    private void testWithOne() {
        outlnSeparator();
        outln(" - testing removeAtIndex on one item -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        removeAtBadIndex(ds, -1);
        removeAtBadIndex(ds, 1);
        removeAtIndex(ds, 0, "apple");
    }

    private void testWithTwo() {
        outlnSeparator();
        outln(" - testing removeAtIndex on two items -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        add(ds, "banana");
        removeAtBadIndex(ds, -1);
        removeAtBadIndex(ds, 2);
        removeAtIndex(ds, 1, "banana");
        outln("getCount()", ds.getCount(), 1);
        removeAtIndex(ds, 0, "apple");
        outln("isEmpty()", ds.isEmpty(), true);
    }

    private void testWithSeveral() {
        outlnSeparator();
        outln(" - testing removeAtIndex on several items -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry", "fig");

        removeAtIndex(ds, 3, "date");
        outln("getCount()", ds.getCount(), 5);
        checkPeekAll(ds, "apple", "banana", "cherry", "elderberry", "fig");

        removeAtIndex(ds, 0, "apple");
        checkPeekAll(ds, "banana", "cherry", "elderberry", "fig");

        removeAtIndex(ds, 3, "fig");
        checkPeekAll(ds, "banana", "cherry", "elderberry");

        removeAtIndex(ds, 0, "banana");
        checkPeekAll(ds, "cherry", "elderberry");

        removeAtIndex(ds, 0, "cherry");
        checkPeekAll(ds, "elderberry");

        removeAtIndex(ds, 0, "elderberry");
        checkPeekAll(ds, StringTools.ZERO_LEN_ARRAY);
    }

    private void testConfirmStillSaneAfterException() {
        outlnSeparator();
        outln(" - testing removeAtIndex, expect exception, check sanity -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        removeAtBadIndex(ds, -7);
        outln("confirming data structure still sane after exception...");
        checkPeekAll(ds, "apple", "banana", "cherry");
    }

    private void removeAtIndex(DSList<String> ds,
                               final int index,
                               final String expectedItem) {

        outln("removeAtIndex(" + index + ")", ds.removeAtIndex(index), expectedItem);
    }

    private void removeAtBadIndex(DSList<String> ds,
                                  final int index) {

        checkBadIndex(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "removeAtIndex(" + index + ")";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.removeAtIndex(index);
            }
        });
    }

}
