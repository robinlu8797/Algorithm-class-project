package com.abc.ds.list.tests.gui;

import com.abc.ds.list.*;
import com.abc.ds.list.tests.*;

public class GuiTestArrayDSList {
    public static void main(String[] args) {
        GuiTestDSList.runTests("ArrayDSList", new DSListFactory() {

            @Override
            public <T> DSList<T> create(Class<T> itemType,
                                        int initialCapacity,
                                        int percentToGrowCapacity) {
                return new ArrayDSList<>(itemType, initialCapacity, percentToGrowCapacity);
            }

            @Override
            public <T> DSList<T> create(Class<T> itemType) {
                return new ArrayDSList<>(itemType);
            }
        });
    }
}
