package com.abc.ds.list.tests;

import com.abc.ds.list.*;

/* deliberate package access */
class TestDSListInsertBefore extends TestDSListBase {
    public TestDSListInsertBefore(DSListFactory factory) {
        super("insertBefore()", factory);
    }

    @Override
    protected void performTests() {
        testInsertBeforeInTheMiddle();
        testInsertBeforeTheLastOne();
        testInsertBeforeTheFirstOne();
        testInsertBeforeAtTheEnd();
        testInsertBeforeNegativeIndex();
        testInsertBeforeBarelyTooLargeIndex();
        testInsertBeforeWayTooLargeIndex();
    }

    private void testInsertBeforeInTheMiddle() {
        outlnSeparator();
        outln(" - insertBefore() a middle item -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("insertBefore(1, \"grape\")...");
        ds.insertBefore(1, "grape");
        checkPeekAll(ds, "apple", "grape", "banana", "cherry");
    }

    private void testInsertBeforeTheLastOne() {
        outlnSeparator();
        outln(" - insertBefore() the last one -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("insertBefore(2, \"grape\")...");
        ds.insertBefore(2, "grape");
        checkPeekAll(ds, "apple", "banana", "grape", "cherry");
    }

    private void testInsertBeforeTheFirstOne() {
        outlnSeparator();
        outln(" - insertBefore() the first one -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("insertBefore(0, \"grape\")...");
        ds.insertBefore(0, "grape");
        checkPeekAll(ds, "grape", "apple", "banana", "cherry");
    }

    private void testInsertBeforeAtTheEnd() {
        outlnSeparator();
        outln(" - insertBefore() at the end (append to the end) -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("insertBefore(count(), \"grape\")...");
        ds.insertBefore(ds.getCount(), "grape");
        checkPeekAll(ds, "apple", "banana", "cherry", "grape");
    }

    private void testInsertBeforeNegativeIndex() {
        outlnSeparator();
        outln(" - insertBefore() negative index [expect exception] -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        insertBeforeBadIndex(ds, -1, "grape");
    }

    private void testInsertBeforeBarelyTooLargeIndex() {
        outlnSeparator();
        outln(" - insertBefore() barely too large index [expect exception] -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        insertBeforeBadIndex(ds, ds.getCount() + 1, "grape");
    }

    private void testInsertBeforeWayTooLargeIndex() {
        outlnSeparator();
        outln(" - insertBefore() way too large index [expect exception] -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        insertBeforeBadIndex(ds, 100, "grape");
    }
}
