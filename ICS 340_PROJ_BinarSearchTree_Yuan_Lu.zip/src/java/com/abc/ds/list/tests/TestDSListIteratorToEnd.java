package com.abc.ds.list.tests;

import com.abc.ds.list.*;
import com.abc.ds.tests.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSListIteratorToEnd extends TestDSListBase {
    public TestDSListIteratorToEnd(DSListFactory factory) {
        super("createIteratorToEnd", factory);
    }

    @Override
    protected void performTests() {
        testIteratorOnOne();
        testIteratorOnTwo();
        testIteratorOnSeveral();
        testIteratorOnEmpty();
    }

    private void testIteratorOnEmpty() {
        outlnSeparator();
        outln(" - createIteratorToEnd() on empty -");
        DSList<String> ds = createDS();
        checkIsEmpty(ds, true);
        outln("createIteratorToEnd(0)...");
        checkIterator(ds.createIteratorToEnd(0), StringTools.ZERO_LEN_ARRAY);
    }

    private void testIteratorOnOne() {
        outlnSeparator();
        outln(" - createIteratorToEnd() on one -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("createIteratorToEnd(0)...");
        checkIterator(ds.createIteratorToEnd(0), "apple");
    }

    private void testIteratorOnTwo() {
        outlnSeparator();
        outln(" - createIteratorToEnd() on two -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        add(ds, "banana");
        outln("createIteratorToEnd(1)...");
        checkIterator(ds.createIteratorToEnd(1), "banana");
    }

    private void testIteratorOnSeveral() {
        outlnSeparator();
        outln(" - createIteratorToEnd() on several -");
        DSList<String> ds = createDS();
        outln("adding some junk to be cleared before rest of test...");
        add(ds, "JUNK A");
        add(ds, "JUNK B");
        add(ds, "JUNK C");
        outln("clear()...");
        ds.clear();

        String[] fruits = new TestFruitGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        add(ds, fruits);
        int startingIndex = 8;
        String[] expectedResults = new String[fruits.length - startingIndex];
        System.arraycopy(fruits, startingIndex, expectedResults, 0, expectedResults.length);
        outln("createIteratorToEnd(" + startingIndex + ")...");
        checkIterator(ds.createIteratorToEnd(startingIndex), expectedResults);
    }
}
