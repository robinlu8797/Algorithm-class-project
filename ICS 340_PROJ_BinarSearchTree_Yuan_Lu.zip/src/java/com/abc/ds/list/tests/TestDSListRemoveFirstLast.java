package com.abc.ds.list.tests;

import com.abc.ds.list.*;

/* deliberate package access */
class TestDSListRemoveFirstLast extends TestDSListBase {
    public TestDSListRemoveFirstLast(DSListFactory factory) {
        super("removeFirst, removeLast", factory);
    }

    @Override
    protected void performTests() {
        testRemoveFirstJustOneWithPlenty();
        testRemoveLastJustOneWithPlenty();
        testRemoveFirstOnlyOne();
        testRemoveLastOnlyOne();
        testRemoveFirstSeveralTimes();
        testRemoveLastSeveralTimes();
        testRemoveFirstOnEmpty();
        testRemoveLastOnEmpty();
    }

    private void testRemoveFirstJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing removeFirst(), just one with plenty -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("removeFirst()", ds.removeFirst(), "apple");
    }

    private void testRemoveLastJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing removeLast(), just one with plenty -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        outln("removeLast()", ds.removeLast(), "cherry");
    }

    private void testRemoveFirstOnlyOne() {
        outlnSeparator();
        outln(" - testing removeFirst(), only one available to remove -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("removeFirst()", ds.removeFirst(), "apple");
        outln("isEmpty()", ds.isEmpty(), true);
    }

    private void testRemoveLastOnlyOne() {
        outlnSeparator();
        outln(" - testing removeLast(), only one available to remove -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("removeLast()", ds.removeLast(), "apple");
        outln("isEmpty()", ds.isEmpty(), true);
    }

    private void testRemoveFirstSeveralTimes() {
        outlnSeparator();
        outln(" - testing removeFirst(), called several times -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry");
        outln("removeFirst()", ds.removeFirst(), "apple");
        outln("removeFirst()", ds.removeFirst(), "banana");
        outln("removeFirst()", ds.removeFirst(), "cherry");
        checkPeekAll(ds, "date", "elderberry");
    }

    private void testRemoveLastSeveralTimes() {
        outlnSeparator();
        outln(" - testing removeLast(), called several times -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry");
        outln("removeLast()", ds.removeLast(), "elderberry");
        outln("removeLast()", ds.removeLast(), "date");
        outln("removeLast()", ds.removeLast(), "cherry");
        checkPeekAll(ds, "apple", "banana");
    }

    private void testRemoveFirstOnEmpty() {
        outlnSeparator();
        outln(" - testing removeFirst() on empty, expect exception -");
        DSList<String> ds = createDS();
        removeFirstExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("removeFirst()", ds.removeFirst(), "apple");
        outln("removeFirst()", ds.removeFirst(), "banana");
        removeFirstExpectException(ds);
    }

    private void testRemoveLastOnEmpty() {
        outlnSeparator();
        outln(" - testing removeLast() on empty, expect exception -");
        DSList<String> ds = createDS();
        removeLastExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("removeLast()", ds.removeLast(), "banana");
        outln("removeLast()", ds.removeLast(), "apple");
        removeLastExpectException(ds);
    }

    private void removeFirstExpectException(DSList<String> ds) {
        checkNoSuchElementException(ds, new TestDSListBase.MethodAccess() {
            @Override
            public String formattedMethod() {
                return "removeFirst()";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.removeFirst();
            }
        });
    }

    private void removeLastExpectException(DSList<String> ds) {
        checkNoSuchElementException(ds, new TestDSListBase.MethodAccess() {
            @Override
            public String formattedMethod() {
                return "removeLast()";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.removeLast();
            }
        });
    }
}
