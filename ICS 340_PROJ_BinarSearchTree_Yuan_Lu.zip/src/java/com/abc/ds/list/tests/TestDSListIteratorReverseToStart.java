package com.abc.ds.list.tests;

import java.util.*;

import com.abc.ds.list.*;
import com.abc.ds.tests.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSListIteratorReverseToStart extends TestDSListBase {
    public TestDSListIteratorReverseToStart(DSListFactory factory) {
        super("createReverseIteratorToStart", factory);
    }

    @Override
    protected void performTests() {
        testIteratorOnOne();
        testIteratorOnTwo();
        testIteratorOnSeveral();
        testIteratorOnEmpty();
    }

    private void testIteratorOnEmpty() {
        outlnSeparator();
        outln(" - createReverseIteratorToStart() on empty -");
        DSList<String> ds = createDS();
        checkIsEmpty(ds, true);
        outln("createReverseIteratorToStart(0)...");
        checkIterator(ds.createReverseIteratorToStart(0), StringTools.ZERO_LEN_ARRAY);
    }

    private void testIteratorOnOne() {
        outlnSeparator();
        outln(" - createReverseIteratorToStart() on one -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        outln("createReverseIteratorToStart(0)...");
        checkIterator(ds.createReverseIteratorToStart(0), "apple");
    }

    private void testIteratorOnTwo() {
        outlnSeparator();
        outln(" - createReverseIteratorToStart() on two -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        add(ds, "banana");
        outln("createReverseIteratorToStart(0)...");
        checkIterator(ds.createReverseIteratorToStart(0), "apple");
    }

    private void testIteratorOnSeveral() {
        outlnSeparator();
        outln(" - createReverseIteratorToStart() on several -");
        DSList<String> ds = createDS();
        outln("adding some junk to be cleared before rest of test...");
        add(ds, "JUNK A");
        add(ds, "JUNK B");
        add(ds, "JUNK C");
        outln("clear()...");
        ds.clear();

        String[] fruits = new TestFruitGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        add(ds, fruits);

        int startingIndex = 12;
        String[] expectedResults = new String[startingIndex + 1];
        System.arraycopy(fruits, 0, expectedResults, 0, expectedResults.length);
        Collections.reverse(Arrays.asList(expectedResults));
        outln("createReverseIteratorToStart(" + startingIndex + ")...");
        checkIterator(ds.createReverseIteratorToStart(startingIndex), expectedResults);
    }
}
