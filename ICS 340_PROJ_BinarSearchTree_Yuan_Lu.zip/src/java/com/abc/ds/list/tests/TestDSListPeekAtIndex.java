package com.abc.ds.list.tests;

import com.abc.ds.list.*;

/* deliberate package access */
class TestDSListPeekAtIndex extends TestDSListBase {
    public TestDSListPeekAtIndex(DSListFactory factory) {
        super("peekAtIndex", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testWithOne();
        testWithTwo();
        testWithSeveral();
        testConfirmStillSaneAfterException();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - testing peekAtIndex on empty -");
        DSList<String> ds = createDS();
        peekAtBadIndex(ds, 0);
        peekAtBadIndex(ds, -1);
        peekAtBadIndex(ds, 999);
    }

    private void testWithOne() {
        outlnSeparator();
        outln(" - testing peekAtIndex on one item -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        peekAtBadIndex(ds, -1);
        peekAtBadIndex(ds, 1);
        peekAtIndex(ds, 0, "apple");
    }

    private void testWithTwo() {
        outlnSeparator();
        outln(" - testing peekAtIndex on two items -");
        DSList<String> ds = createDS();
        add(ds, "apple");
        add(ds, "banana");
        peekAtBadIndex(ds, -1);
        peekAtBadIndex(ds, 2);
        peekAtIndex(ds, 1, "banana");
        checkCount(ds, 2);
        peekAtIndex(ds, 0, "apple");
        checkCount(ds, 2);
    }

    private void testWithSeveral() {
        outlnSeparator();
        outln(" - testing peekAtIndex on several items -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "date", "elderberry", "fig");

        peekAtIndex(ds, 3, "date");
        checkCount(ds, 6);

        peekAtIndex(ds, 0, "apple");
        checkCount(ds, 6);

        peekAtIndex(ds, 5, "fig");
        checkCount(ds, 6);

        peekAtIndex(ds, 2, "cherry");
        checkCount(ds, 6);
    }

    private void testConfirmStillSaneAfterException() {
        outlnSeparator();
        outln(" - testing peekAtIndex, expect exception, check sanity -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry");
        peekAtBadIndex(ds, -7);
        outln("confirming data structure still sane after exception...");
        checkPeekAll(ds, "apple", "banana", "cherry");
    }

    private void peekAtIndex(DSList<String> ds,
                               final int index,
                               final String expectedItem) {

        outln("peekAtIndex(" + index + ")", ds.peekAtIndex(index), expectedItem);
    }

    private void peekAtBadIndex(DSList<String> ds,
                                  final int index) {

        checkBadIndex(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekAtIndex(" + index + ")";
            }

            @Override
            public void execute(DSList<String> ds2) {
                ds2.peekAtIndex(index);
            }
        });
    }

}
