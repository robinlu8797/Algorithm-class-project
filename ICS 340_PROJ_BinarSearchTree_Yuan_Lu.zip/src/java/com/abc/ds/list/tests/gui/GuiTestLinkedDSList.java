package com.abc.ds.list.tests.gui;

import com.abc.ds.list.*;
import com.abc.ds.list.tests.*;

public class GuiTestLinkedDSList {
    public static void main(String[] args) {
        GuiTestDSList.runTests("LinkedDSList", new DSListFactory() {

            @Override
            public <T> DSList<T> create(Class<T> itemType,
                                        int initialCapacity,
                                        int percentToGrowCapacity) {

                // initial capacity and percent to grow mean nothing for linked lists
                return create(itemType);
            }

            @Override
            public <T> DSList<T> create(Class<T> itemType) {
                return new LinkedDSList<>(itemType);
            }
        });
    }
}
