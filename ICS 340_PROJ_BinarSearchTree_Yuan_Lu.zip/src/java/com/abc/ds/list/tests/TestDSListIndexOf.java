package com.abc.ds.list.tests;

import com.abc.ds.list.*;

/* deliberate package access */
class TestDSListIndexOf extends TestDSListBase {
    public TestDSListIndexOf(DSListFactory factory) {
        super("firstIndexOf, lastIndexOf", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testWithAppleTwice();
        testForNotFound();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - testing indexOf's on empty -");
        DSList<String> ds = createDS();
        outln("ds.firstIndexOf(\"apple\", 0)", ds.firstIndexOf("apple", 0), DSList.NOT_FOUND_INDEX);
        outln("ds.firstIndexOf(\"apple\")", ds.firstIndexOf("apple"), DSList.NOT_FOUND_INDEX);
        outln("ds.lastIndexOf(\"apple\", 0)", ds.lastIndexOf("apple", 0), DSList.NOT_FOUND_INDEX);
        outln("ds.lastIndexOf(\"apple\")", ds.lastIndexOf("apple"), DSList.NOT_FOUND_INDEX);
    }

    private void testWithAppleTwice() {
        outlnSeparator();
        outln(" - testing indexOf's on list with apple twice -");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "apple", "date");
        outln("ds.firstIndexOf(\"apple\")", ds.firstIndexOf("apple"), 0);
        outln("ds.firstIndexOf(\"apple\", 1)", ds.firstIndexOf("apple", 1), 3);
        outln("ds.lastIndexOf(\"apple\")", ds.lastIndexOf("apple"), 3);
        outln("ds.lastIndexOf(\"apple\", 2)", ds.lastIndexOf("apple", 2), 0);
    }

    private void testForNotFound() {
        outlnSeparator();
        outln(" - testing indexOf's on list that does not contain the item-");
        DSList<String> ds = createDS();
        add(ds, "apple", "banana", "cherry", "apple", "date");
        outln("ds.firstIndexOf(\"grape\", 0)", ds.firstIndexOf("grape", 0), DSList.NOT_FOUND_INDEX);
        outln("ds.firstIndexOf(\"grape\", 3)", ds.firstIndexOf("grape", 3), DSList.NOT_FOUND_INDEX);
        outln("ds.lastIndexOf(\"grape\", 0)", ds.lastIndexOf("grape", 0), DSList.NOT_FOUND_INDEX);
        outln("ds.lastIndexOf(\"grape\", 3)", ds.lastIndexOf("grape", 3), DSList.NOT_FOUND_INDEX);
    }
}
