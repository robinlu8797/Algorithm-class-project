package com.abc.ds.list;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.programix.util.*;

public class LinkedDSList<T> implements DSList<T>, DSCountable {
    private final Node<T> sentinel;
    private int count;
    private final Class<T> itemType;
    private final T[] itemTypeZeroLenArray; // shared, immutable
    private final DSIterator<T> emptyIterator; // shared, immutable

    public LinkedDSList(Class<T> itemType) {
        ObjectTools.paramNullCheck(itemType, "itemType");
        this.itemType = itemType;
        itemTypeZeroLenArray = DSTools.createArrayFromType(itemType, 0);
        emptyIterator = EmptyDSIterator.createForType();

        sentinel = new Node<>(null);
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        count = 0;
    }

    private void confirmValidIndex(int index) throws IndexOutOfBoundsException {
        if ( isEmpty() ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", list is empty, no index values are valid");
        } else if ( index < 0 || index >= count ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", must be in the range [0.." +
                (count - 1) + "]");
        }
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if ( isEmpty() ) {
            throw new NoSuchElementException("list is empty");
        }
    }

    @Override
    public Class<T> getItemType() {
        return itemType;
    }

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public boolean isEmpty() {
        return count == 0;
    }

    @Override
    public void clear() {
        sentinel.next = sentinel;
        sentinel.prev = sentinel;
        count = 0;
    }

    private void insertBefore(Node<T> nodeToInsertBefore, T item) {
        Node<T> newNode = new Node<>(item);
        newNode.next = nodeToInsertBefore;
        newNode.prev = nodeToInsertBefore.prev;
        newNode.prev.next = newNode;
        newNode.next.prev = newNode;
        count++;
    }

    private void deleteNode(Node<T> nodeToDelete) {
        if (nodeToDelete == sentinel) throw new IllegalArgumentException("sentinel cannot be deleted");
        nodeToDelete.prev.next = nodeToDelete.next;
        nodeToDelete.next.prev = nodeToDelete.prev;
        count--;
    }

    private Node<T> findNodeAtValidIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);
        // if we get here, there is at least one item in the list

        if (index < count / 2) {
            // closer to the beginning
            Node<T> currNode = sentinel.next;
            int numberOfLinksToFollow = index;
            for ( int i = 0; i < numberOfLinksToFollow; i++ ) {
                currNode = currNode.next;
            }
            return currNode;
        } else {
            // closer to the end, start at the end and count backwards
            Node<T> currNode = sentinel.prev;
            int numberOfLinksToFollow = count - index - 1;
            for ( int i = 0; i < numberOfLinksToFollow; i++ ) {
                currNode = currNode.prev;
            }
            return currNode;
        }
    }

    @Override
    public boolean add(T item) {
        insertBefore(sentinel, item);
        return true; // always return true for lists
    }

    @Override
    public int addAll(@SuppressWarnings("unchecked") T... items) {
        if ( ObjectTools.isEmpty(items) ) {
            return 0;
        }
        for ( T item : items ) {
            add(item);
        }
        return items.length; // all items are added to lists
    }

    @Override
    public int addAll(DSIterable<T> items) {
        if (items == null) return 0; // nothing to add

        if (items instanceof DSCountable) {
            if (((DSCountable) items).isEmpty()) return 0; // nothing to add
        }

        int addCount = 0;
        for ( T item : DSTools.asJavaIterable(items) ) {
            add(item);
            addCount++;
        }
        return addCount;
    }

    @Override
    public void insertBefore(int index, T item)
            throws IndexOutOfBoundsException {

        if ( index == count ) {
            add(item);
        } else {
            confirmValidIndex(index);
            // if we get here, there is at least one item in the list
            Node<T> nodeToInsertBefore = findNodeAtValidIndex(index);
            insertBefore(nodeToInsertBefore, item);
        }
    }

    @Override
    public void insertFirst(T item) {
        insertBefore(0, item);
    }

    @Override
    public int firstIndexOf(T item, int fromIndex) {
        if (isEmpty() || fromIndex >= count) return NOT_FOUND_INDEX;
        fromIndex = fromIndex >= 0 ? fromIndex : 0;
        Node<T> currNode = findNodeAtValidIndex(fromIndex);
        for ( int i = fromIndex; i < count; i++, currNode = currNode.next ) {
            if (ObjectTools.isSame(item, currNode.data)) {
                return i;
            }
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int firstIndexOf(T item) {
        return firstIndexOf(item, 0);
    }

    @Override
    public int lastIndexOf(T item, int fromIndex) {
        if (isEmpty() || fromIndex < 0) return NOT_FOUND_INDEX;
        fromIndex = fromIndex < count ? fromIndex : count - 1;
        Node<T> currNode = findNodeAtValidIndex(fromIndex);
        for (int i = fromIndex; i >= 0; i--, currNode = currNode.prev) {
            if (ObjectTools.isSame(item, currNode.data)) {
                return i;
            }
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int lastIndexOf(T item) {
        return lastIndexOf(item, count -1);
    }

    @Override
    public boolean remove(T item) {
        if (isEmpty()) return false;

        for (Node<T> currNode = sentinel.next; currNode != sentinel; currNode = currNode.next) {
            if (ObjectTools.isSame(item, currNode.data)) {
                deleteNode(currNode);
                return true;
            }
        }
        return false;
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return removeMatchesCommon(filter,
            DSMatchHelper.createMatchAndCount(itemType, count / 4, 50))
                .getMatches();
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return removeMatchesCommon(
            filter, DSMatchHelper.createCountOnly(itemType)).getMatchCount();
    }

    private DSMatchHelper<T> removeMatchesCommon(DSFilter<T> filter,
                                                 DSMatchHelper<T> matchHelper) {

        if (isEmpty() || filter == null) return matchHelper;

        for (Node<T> currNode = sentinel.next; currNode != sentinel; currNode = currNode.next) {
            if (filter.matches(currNode.data)) {
                matchHelper.append(currNode.data);
                Node<T> prevNode = currNode.prev;
                deleteNode(currNode);

                // back up to prev node since currNode is now deleted
                currNode = prevNode;
            }
        }
        return matchHelper;
    }

    @Override
    public T[] removeAll() {
        if (isEmpty()) return itemTypeZeroLenArray;

        T[] results = peekAll();
        clear();
        return results;
    }

    @Override
    public T removeAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);

        // check these two for efficiency
        if (index == 0) return removeFirst();
        if (index == count - 1) return removeLast();

        Node<T> node = findNodeAtValidIndex(index);
        deleteNode(node);
        return node.data;
    }

    @Override
    public T removeFirst() throws NoSuchElementException {
        confirmNotEmpty();
        Node<T> node = sentinel.next;
        deleteNode(node);
        return node.data;
    }

    @Override
    public T removeLast() throws NoSuchElementException {
        confirmNotEmpty();
        Node<T> node = sentinel.prev;
        deleteNode(node);
        return node.data;
    }

    @Override
    public boolean contains(T item) {
        return firstIndexOf(item) != NOT_FOUND_INDEX;
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        return DSMatchHelper.createMatchAndCount(itemType, count / 4, 50)
            .append(this, filter)
            .getMatches();
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return DSMatchHelper.createCountOnly(itemType)
            .append(this, filter)
            .getMatchCount();
    }

    @Override
    public T[] peekAll() {
        if ( isEmpty() ) {
            return itemTypeZeroLenArray;
        }
        T[] results = DSTools.createArrayFromType(itemType, count);
        int ptr = 0;
        for (Node<T> currNode = sentinel.next; currNode != sentinel; currNode = currNode.next) {
            results[ptr] = currNode.data;
            ptr++;
        }
        return results;
    }

    @Override
    public T peekAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);
        return findNodeAtValidIndex(index).data;
    }

    @Override
    public T peekFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return sentinel.next.data;
    }

    @Override
    public T peekLast() throws NoSuchElementException {
        confirmNotEmpty();
        return sentinel.prev.data;
    }

    @Override
    public T replaceAtIndex(int index, T replacementItem)
            throws IndexOutOfBoundsException {

        confirmValidIndex(index);
        Node<T> node = findNodeAtValidIndex(index);
        T oldItem = node.data;
        node.data = replacementItem;
        return oldItem;
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        // do this via peekAll() since we don't know if the action will
        // add or remove anything from this sack.
        for ( T item : peekAll() ) {
            action.perform(item);
        }
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        // do this via peekMatches() since we don't know if the action will
        // add or remove anything from this sack.
        T[] matches = peekMatches(filter);
        for ( T item : matches ) {
            action.perform(item);
        }
        return matches.length;
    }

    @Override
    public DSIterator<T> createIterator() {
        return isEmpty() ? emptyIterator : new NextIterator(sentinel.next);
    }

    @Override
    public DSIterator<T> createIteratorToEnd(int startingIndex) {
        startingIndex = Math.max(0, startingIndex);
        if (isEmpty() || startingIndex >= count) return emptyIterator;
        return new NextIterator(findNodeAtValidIndex(startingIndex));
    }

    @Override
    public DSIterator<T> createReverseIterator() {
        return isEmpty() ? emptyIterator : new PrevIterator(sentinel.prev);
    }

    @Override
    public DSIterator<T> createReverseIteratorToStart(int startingIndex) {
        startingIndex = Math.min(startingIndex, count - 1);
        if (isEmpty() || startingIndex < 0) return emptyIterator;
        return new PrevIterator(findNodeAtValidIndex(startingIndex));
    }

    private static class Node<T> {
        public T data;
        public Node<T> next;
        public Node<T> prev;

        public Node(T data) {
            this.data = data;
        }
    } // type Node

    private class NextIterator implements DSIterator<T> {
        private Node<T> node;

        public NextIterator(Node<T> nodeToStartFrom) {
            this.node = nodeToStartFrom.prev;
        }

        @Override
        public boolean hasNext() {
            return node.next != sentinel;
        }

        @Override
        public T next() throws NoSuchElementException {
            if ( !hasNext() ) {
                throw new NoSuchElementException(
                    "next() cannot be called because hasNext() is false");
            }

            node = node.next;
            return node.data;
        }
    } // type NextIterator

    private class PrevIterator implements DSIterator<T> {
        private Node<T> node;

        public PrevIterator(Node<T> nodeToStartFrom) {
            this.node = nodeToStartFrom.next;
        }

        @Override
        public boolean hasNext() {
            return node.prev != sentinel;
        }

        @Override
        public T next() throws NoSuchElementException {
            if ( !hasNext() ) {
                throw new NoSuchElementException(
                    "next() cannot be called because hasNext() is false");
            }

            node = node.prev;
            return node.data;
        }
    } // type PrevIterator
}
