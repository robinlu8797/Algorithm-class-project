package com.abc.ds.list;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.linkedlist.*;
import com.programix.util.*;

public class LinkedTooDSList<T> implements DSList<T>, DSCountable {
    private final Class<T> itemType;
    private final T[] itemTypeZeroLenArray; // shared, immutable
    private final DSIterator<T> emptyIterator; // shared, immutable

    private final DSLinkedList<T> helperList;

    public LinkedTooDSList(Class<T> itemType) {
        ObjectTools.paramNullCheck(itemType, "itemType");
        this.itemType = itemType;
        itemTypeZeroLenArray = DSTools.createArrayFromType(itemType, 0);
        emptyIterator = EmptyDSIterator.createForType();

        helperList = new DoublyDSLinkedList<>(itemType);
    }

    private void confirmValidIndex(int index) throws IndexOutOfBoundsException {
        if ( isEmpty() ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", list is empty, no index values are valid");
        } else if ( index < 0 || index >= helperList.getCount() ) {
            throw new IndexOutOfBoundsException(
                "index=" + index + ", must be in the range [0.." +
                (helperList.getCount() - 1) + "]");
        }
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if ( isEmpty() ) {
            throw new NoSuchElementException("list is empty");
        }
    }

    @Override
    public Class<T> getItemType() {
        return itemType;
    }

    @Override
    public int getCount() {
        return helperList.getCount();
    }

    @Override
    public boolean isEmpty() {
        return helperList.isEmpty();
    }

    @Override
    public void clear() {
        helperList.clear();
    }

    @Override
    public boolean add(T item) {
        helperList.insertLast(item);
        return true; // always return true for lists
    }

    @Override
    public int addAll(@SuppressWarnings("unchecked") T... items) {
        if ( ObjectTools.isEmpty(items) ) {
            return 0;
        }
        for ( T item : items ) {
            add(item);
        }
        return items.length; // all items are added to lists
    }

    @Override
    public int addAll(DSIterable<T> items) {
        if (items == null) return 0; // nothing to add

        if (items instanceof DSCountable) {
            if (((DSCountable) items).isEmpty()) return 0; // nothing to add
        }

        int addCount = 0;
        for ( T item : DSTools.asJavaIterable(items) ) {
            add(item);
            addCount++;
        }
        return addCount;
    }

    @Override
    public void insertBefore(int index, T item)
            throws IndexOutOfBoundsException {

        if ( index == getCount()) {
            helperList.insertLast(item);
        } else {
            confirmValidIndex(index);
            // if we get here, there is at least one item in the list
            helperList.peekAtIndex(index).insertBefore(item);
        }
    }

    @Override
    public void insertFirst(T item) {
        insertBefore(0, item);
    }

    @Override
    public int firstIndexOf(T itemToMatch, int fromIndex) {
        if (isEmpty() || fromIndex >= getCount()) return NOT_FOUND_INDEX;
        fromIndex = fromIndex >= 0 ? fromIndex : 0;

        int index = fromIndex;
        for (T itemInList : DSTools.asJavaIterable(
                helperList.peekAtIndex(fromIndex).createIteratorThisToEnd())) {

            if (ObjectTools.isSame(itemToMatch, itemInList)) {
                return index;
            }
            index++;
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int firstIndexOf(T item) {
        return firstIndexOf(item, 0);
    }

    @Override
    public int lastIndexOf(T itemToMatch, int fromIndex) {
        if (isEmpty() || fromIndex < 0) return NOT_FOUND_INDEX;
        fromIndex = fromIndex < getCount() ? fromIndex : getCount() - 1;

        int index = fromIndex;
        for (T itemInList : DSTools.asJavaIterable(
                helperList.peekAtIndex(fromIndex).createReverseIteratorThisToStart())) {

            if (ObjectTools.isSame(itemToMatch, itemInList)) {
                return index;
            }
            index--;
        }
        return NOT_FOUND_INDEX;
    }

    @Override
    public int lastIndexOf(T item) {
        return lastIndexOf(item, getCount() - 1);
    }

    @Override
    public boolean remove(T item) {
        if (isEmpty()) return false;

        for (DSLinkedList.Node<T> node : DSTools.asJavaIterable(helperList.createNodeIterator())) {
            if (ObjectTools.isSame(item, node.getPayload())) {
                node.delete(); // invalidates the iterator, but we're done anyway
                return true;
            }
        }
        return false;
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }

        DSLinkedList.Node<T>[] matchingNodes = helperList.peekMatches(filter);
        T[] removedItems = helperList.extractPayloads(matchingNodes);
        for ( DSLinkedList.Node<T> node : matchingNodes ) {
            node.delete();
        }
        return removedItems;
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        DSLinkedList.Node<T>[] matchingNodes = helperList.peekMatches(filter);
        for ( DSLinkedList.Node<T> node : matchingNodes ) {
            node.delete();
        }
        return matchingNodes.length;
    }

    @Override
    public T[] removeAll() {
        if (isEmpty()) return itemTypeZeroLenArray;

        T[] results = peekAll();
        clear();
        return results;
    }

    @Override
    public T removeAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);

        DSLinkedList.Node<T> nodeToRemove = helperList.peekAtIndex(index);
        T item = nodeToRemove.getPayload();
        nodeToRemove.delete();
        return item;
    }

    @Override
    public T removeFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return removeAtIndex(0);
    }

    @Override
    public T removeLast() throws NoSuchElementException {
        confirmNotEmpty();
        return removeAtIndex(getCount() - 1);
    }

    @Override
    public boolean contains(T item) {
        return isEmpty() ? false : firstIndexOf(item) != NOT_FOUND_INDEX;
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return itemTypeZeroLenArray;
        }

        return helperList.extractPayloads(helperList.peekMatches(filter));
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        if ( filter == null || isEmpty() ) {
            return 0;
        }
        return helperList.peekMatches(filter).length;
    }

    @Override
    public T[] peekAll() {
        if (isEmpty()) return itemTypeZeroLenArray;
        return helperList.extractPayloads(helperList.peekAll());
    }

    @Override
    public T peekAtIndex(int index) throws IndexOutOfBoundsException {
        confirmValidIndex(index);
        return helperList.peekAtIndex(index).getPayload();
    }

    @Override
    public T peekFirst() throws NoSuchElementException {
        confirmNotEmpty();
        return helperList.peekFirst().getPayload();
    }

    @Override
    public T peekLast() throws NoSuchElementException {
        confirmNotEmpty();
        return helperList.peekLast().getPayload();
    }

    @Override
    public T replaceAtIndex(int index, T replacementItem)
            throws IndexOutOfBoundsException {

        confirmValidIndex(index);
        DSLinkedList.Node<T> node = helperList.peekAtIndex(index);
        T oldItem = node.getPayload();
        node.setPayload(replacementItem);
        return oldItem;
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        // do this via peekAll() since we don't know if the action will
        // add or remove anything from this sack.
        for ( T item : peekAll() ) {
            action.perform(item);
        }
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        // do this via peekMatches() since we don't know if the action will
        // add or remove anything from this sack.
        T[] matches = peekMatches(filter);
        for ( T item : matches ) {
            action.perform(item);
        }
        return matches.length;
    }

    @Override
    public DSIterator<T> createIterator() {
        return isEmpty() ? emptyIterator : helperList.createIterator();
    }

    @Override
    public DSIterator<T> createIteratorToEnd(int startingIndex) {
        startingIndex = Math.max(0, startingIndex);
        if (isEmpty() || startingIndex >= getCount()) return emptyIterator;
        return helperList.peekAtIndex(startingIndex).createIteratorThisToEnd();
    }

    @Override
    public DSIterator<T> createReverseIterator() {
        return isEmpty() ? emptyIterator : helperList.createReverseIterator();
    }

    @Override
    public DSIterator<T> createReverseIteratorToStart(int startingIndex) {
        startingIndex = Math.min(startingIndex, getCount() - 1);
        if (isEmpty() || startingIndex < 0) return emptyIterator;
        return helperList.peekAtIndex(startingIndex).createReverseIteratorThisToStart();
    }
}
