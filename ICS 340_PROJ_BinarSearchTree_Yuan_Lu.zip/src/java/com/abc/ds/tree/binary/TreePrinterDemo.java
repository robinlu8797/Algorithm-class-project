package com.abc.ds.tree.binary;

public class TreePrinterDemo {
    public static void main(String[] args) {
        TreePrinter.NodeAccess<Node> nodeAccess = new TreePrinter.NodeAccess<Node>() {
            @Override
            public Node getLeftChild(Node node) {
                return node.leftChild;
            }

            @Override
            public Node getRightChild(Node node) {
                return node.rightChild;
            }

            @Override
            public String formatForDisplay(Node node) {
                return node.name;
            }
        };

        //                     A
        //                    / \
        //                   /   \
        //                  B     C
        //                 / \     \
        //                D   E     F
        //                   /     / \
        //                  G     H   I
        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");
        Node d = new Node("D");
        Node e = new Node("E");
        Node f = new Node("F");
        Node g = new Node("G");
        Node h = new Node("H");
        Node i = new Node("I");
        a.leftChild = b;
        a.rightChild = c;
        b.leftChild = d;
        b.rightChild = e;
        e.leftChild = g;
        c.rightChild = f;
        f.leftChild = h;
        f.rightChild = i;

        TreePrinter<Node> treePrinter = new TreePrinter<>(nodeAccess);
        treePrinter.printTree(a);
    }

    private static class Node {
        public String name;
        public Node leftChild;
        public Node rightChild;

        public Node(String name) {
            this.name = name;
        }
    } // type Node
}
