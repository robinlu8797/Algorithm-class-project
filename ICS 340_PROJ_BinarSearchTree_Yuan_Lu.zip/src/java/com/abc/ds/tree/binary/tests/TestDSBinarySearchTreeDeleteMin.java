package com.abc.ds.tree.binary.tests;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDeleteMin extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDeleteMin(DSBinarySearchTreeFactory factory) {
        super("deleteMin()", factory);
    }

    @Override
    protected void performTests() {
        testOne();
        testSeveralInsertOrderA();
        testSeveralInsertOrderB();
        testSeveralInsertOrderC();
        testRepeatedly();
        testEmpty();
    }

    private void testOne() {
        outlnSeparator();
        outln(" - insert one, deleteMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        outln("deleteMin()...");
        DSKeyValuePair<String, String> min = ds.deleteMin();
        outln("min != null", min != null, true);
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testSeveralInsertOrderA() {
        outlnSeparator();
        outln(" - insert several in order A, deleteMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        outln("deleteMin()...");
        DSKeyValuePair<String, String> min = ds.deleteMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testSeveralInsertOrderB() {
        outlnSeparator();
        outln(" - insert several in order B, deleteMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_BEACH);
        outln("deleteMin()...");
        DSKeyValuePair<String, String> min = ds.deleteMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testSeveralInsertOrderC() {
        outlnSeparator();
        outln(" - insert several in order C, deleteMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        outln("deleteMin()...");
        DSKeyValuePair<String, String> min = ds.deleteMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testRepeatedly() {
        outlnSeparator();
        outln(" - insert several, deleteMin() multiple times -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        outln("deleteMin()", ds.deleteMin(), PAIR_BEACH);
        outln("deleteMin()", ds.deleteMin(), PAIR_GLACIER);
        outln("deleteMin()", ds.deleteMin(), PAIR_LAKE);
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty, deleteMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("not inserting anything, leaving tree empty");

        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "deleteMin()";
            }

            @Override
            public void execute(DSBinarySearchTree<String, ?> t) {
                t.deleteMin();
            }
        });
    }
}
