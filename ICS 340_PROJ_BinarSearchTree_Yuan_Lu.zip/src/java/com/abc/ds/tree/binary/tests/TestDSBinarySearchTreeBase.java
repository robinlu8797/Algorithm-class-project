package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.keyvalue.tests.*;
import com.abc.ds.sortedset.tests.*;
import com.abc.ds.tests.*;
import com.abc.ds.tree.binary.*;
import com.programix.util.*;

/* deliberate package access */
abstract class TestDSBinarySearchTreeBase extends TestDSBase {
    @SuppressWarnings("unchecked")
    public static final Class<DSKeyValuePair<String, String>> STRING_KV_TYPE =
        (Class<DSKeyValuePair<String, String>>) DSTools.coerceClassType(DSKeyValuePair.class);

    public static final DSKeyValuePair<String, String>[] STRING_KV_ZERO_LEN_ARRAY =
        DSKeyValueTools.createArray(String.class, String.class, 0);

    public static final DSKeyValuePair<String, String> PAIR_OCEAN =
        new BasicDSKeyValuePair<String, String>("ocean", "water");
    public static final DSKeyValuePair<String, String> PAIR_GLACIER =
        new BasicDSKeyValuePair<String, String>("glacier", "ice");
    public static final DSKeyValuePair<String, String> PAIR_VOLCANO =
        new BasicDSKeyValuePair<String, String>("volcano", "magma");
    public static final DSKeyValuePair<String, String> PAIR_LAKE =
        new BasicDSKeyValuePair<String, String>("lake", "water");
    public static final DSKeyValuePair<String, String> PAIR_BEACH =
        new BasicDSKeyValuePair<String, String>("beach", "sand");
    public static final DSKeyValuePair<String, String> PAIR_SCHOOL =
        new BasicDSKeyValuePair<String, String>("school", "children");

    public static final Comparator<DSKeyValuePair<String, String>> pairJavaComparator = new Comparator<DSKeyValuePair<String,String>>() {
        @Override
        public int compare(DSKeyValuePair<String, String> p1,
                           DSKeyValuePair<String, String> p2) {
            return p1.getKey().compareTo(p2.getKey());
        }
    };

    protected final DSBinarySearchTreeFactory factory;
    protected TestDSHelper<String> stringTestHelper;
    protected final Class<DSKeyValuePair<String, String>> pairType;

    protected TestDSBinarySearchTreeBase(String subTitle,
                                         final DSBinarySearchTreeFactory rawFactory) {
        super("DSBinarySearchTree - " + subTitle);

        pairType = DSKeyValueTools.getPairType(String.class, String.class);
        this.factory = new DSBinarySearchTreeFactory() {
            @Override
            public <K> DSOrdering<K> getOrdering(DSBinarySearchTree<K, ?> tree) {
                return rawFactory.getOrdering(tree);
            }

            @Override
            public <K, V> DSBinarySearchTree<K, V> create(Class<K> keyType,
                                                          Class<V> valueType,
                                                          DSComparator<K> comparator) {

                DSBinarySearchTree<K, V> tree = rawFactory.create(keyType, valueType, comparator);
                updateTestHelper(tree);
                return tree;
            }
        };

        stringTestHelper = new TestDSHelper.Builder<String>()
            .setItemType(String.class)
            .setTestAccess(testAccess)
            .setAllowDuplicates(false)
            .setOrdering(DSOrdering.createUnordered(String.class))
            .setWrapItemsInQuotes(true)
            .create();
    }

    private void updateTestHelper(DSBinarySearchTree<?, ?> t) {
        if (!String.class.equals(t.getKeyType())) {
            // can't to anything without String-based testHelper
            return;
        }

        @SuppressWarnings("unchecked")
        DSBinarySearchTree<String, ?> tree = (DSBinarySearchTree<String, ?>) t;

        stringTestHelper = new TestDSHelper.Builder<String>()
            .setItemType(String.class)
            .setTestAccess(testAccess)
            .setAllowDuplicates(false)
            .setOrdering(factory.getOrdering(tree))
            .setWrapItemsInQuotes(true)
            .create();
    }

    protected DSBinarySearchTree<String, String> createDS(DSComparator<String> comparator) {
        outln("Creating a new DSBinarySearchTree<String, String> instance...");
        DSBinarySearchTree<String, String> ds = factory.create(
            String.class, String.class, TestSuiteDSSortedSet.STANDARD_STRING_COMPARATOR);
        outln("   ...created (comparator: " +
            (comparator instanceof DescriptiveDSComparator ? comparator.toString() : "<no description>") +
            "): " + ds.getClass().getCanonicalName());
        return ds;
    }

    protected DSBinarySearchTree<String, String> createDS() {
        return createDS(TestSuiteDSBinarySearchTree.STANDARD_STRING_COMPARATOR);
    }

    protected void insert(DSBinarySearchTree<String, String> tree, String key, String value) {
        outln("insert(" + StringTools.quoteWrap(key) + ", " +
            StringTools.quoteWrap(value) + ")");
        tree.insert(key, value);
    }

    protected void insert(DSBinarySearchTree<String, String> tree,
                          @SuppressWarnings("unchecked") DSKeyValuePair<String, String>... pairs) {

        for ( DSKeyValuePair<String, String> pair : pairs ) {
            insert(tree, pair.getKey(), pair.getValue());
        }
    }

    protected void insert(DSBinarySearchTree<String, String> tree,
                          DSKeyValuePair<String, String> pair) {

        insert(tree, pair.getKey(), pair.getValue());
    }

    protected DSKeyValuePair<String, String>[] getFruitPairs(int offset,
                                                             int count) {

        return TestFruitPairGenerator.getFruits(offset, count);
    }

    protected DSKeyValuePair<String, String>[] getFruitPairs(int count) {
        return getFruitPairs(0, count);
    }

    protected DSKeyValuePair<String, String>[] getFruitPairsShuffled(int count) {
        return shuffle(getFruitPairs(0, count), null);
    }

    /**
     * Removes duplicate keys retaining the LAST key-value pair (since the
     * value might be different for duplicate keys).
     * New array returned, passed array is not modified.
     */
    @SuppressWarnings("unchecked")
    protected DSKeyValuePair<String, String>[] removeDuplicateKeys(
            DSKeyValuePair<String, String>[] origPairs) {

        Map<String, DSKeyValuePair<String, String>> map =
            new LinkedHashMap<>();
        for ( DSKeyValuePair<String, String> origPair : origPairs ) {
            map.put(origPair.getKey(), origPair);
        }
        return map.values().toArray(
            DSTools.createArrayFromType(DSKeyValuePair.class, map.size()));
    }

    /**
     * Returns a new array contains the shuffled items from the specified
     * array.
     * If random is null, the same random seed (0x00000000feedface) is
     * used each time to guarantee consistent results from run to run.
     * New array returned, passed array is not modified.
     */
    @SuppressWarnings("unchecked")
    protected DSKeyValuePair<String, String>[] shuffle(
            DSKeyValuePair<String, String>[] origPairs,
            Random random) {

        random = random == null ? new Random(0x00000000feedface) : random;

        List<DSKeyValuePair<String, String>> list = new
            ArrayList<>(Arrays.asList(origPairs));
        Collections.shuffle(list, random);
        return list.toArray(
            DSTools.createArrayFromType(DSKeyValuePair.class, list.size()));
    }

    protected String[] pairsToStrings(DSKeyValuePair<String, String>[] pairs) {
        return StringKeyValue.toStrings(StringKeyValue.createArray(pairs));
    }

    protected void checkIterator(DSIterator<DSKeyValuePair<String, String>> iterator,
                                 @SuppressWarnings("unchecked") DSKeyValuePair<String, String>... expectedItems) {
        stringTestHelper.check("iteration results",
            pairsToStrings(DSTools.iteratorToArray(pairType, iterator)),
            pairsToStrings(expectedItems));
    }

    protected void checkIteratorWithoutSortingExpected(DSIterator<DSKeyValuePair<String, String>> iterator,
                                 @SuppressWarnings("unchecked") DSKeyValuePair<String, String>... expectedItems) {
        stringTestHelper.checkWithoutSortingExpected("iteration results",
            pairsToStrings(DSTools.iteratorToArray(pairType, iterator)),
            pairsToStrings(expectedItems));
    }

    @SuppressWarnings("unchecked")
    protected void checkPeekAll(DSBinarySearchTree<String, String> ds,
                                DSKeyValuePair<String, String>... expectedItems) {

        stringTestHelper.check("peekAll()",
            pairsToStrings(ds.peekAll()),
            pairsToStrings(expectedItems));
    }

    @SuppressWarnings("unchecked")
    protected void checkDeleteAll(DSBinarySearchTree<String, String> ds,
                                  DSKeyValuePair<String, String>... expectedItems) {

        stringTestHelper.check("deleteAll()",
            pairsToStrings(ds.deleteAll()),
            pairsToStrings(expectedItems));
    }

    protected void checkPeekAllOnEmpty(DSBinarySearchTree<String, String> ds) {
        checkPeekAll(ds, STRING_KV_ZERO_LEN_ARRAY);
    }

    protected void checkDeleteAllOnEmpty(DSBinarySearchTree<String, String> ds) {
        checkDeleteAll(ds, STRING_KV_ZERO_LEN_ARRAY);
    }

    @SuppressWarnings("unchecked")
    protected void checkPeekKeyMatches(DSBinarySearchTree<String, String> ds,
                                       DSFilter<String> keyFilter,
                                       DSKeyValuePair<String, String>... expectedItems) {

        stringTestHelper.check("peekKeyMatches(filter)",
            pairsToStrings(ds.peekKeyMatches(keyFilter)),
            pairsToStrings(expectedItems));
    }

    @SuppressWarnings("unchecked")
    protected void checkDeleteKeyMatches(DSBinarySearchTree<String, String> ds,
                                         DSFilter<String> keyFilter,
                                         DSKeyValuePair<String, String>... expectedItems) {

        stringTestHelper.check("deleteKeyMatches(filter)",
            pairsToStrings(ds.deleteKeyMatches(keyFilter)),
            pairsToStrings(expectedItems));
    }

    protected void checkCount(DSBinarySearchTree<String, String> ds,
                              int expectedResult) {
        outln("getCount()", ds.getCount(), expectedResult);
    }

    protected void checkIsEmpty(DSBinarySearchTree<String, String> ds,
                                boolean expectedResult) {
        outln("isEmpty()", ds.isEmpty(), expectedResult);
    }

    @SuppressWarnings("unchecked")
    protected void checkNoNullSlots(DSKeyValuePair<String, String>... pairs) {
        if ( ObjectTools.isNoSlotEmpty(pairs) ) return;

        if ( pairs == null ) {
            throw new NullPointerException(
                "DSKeyValuePair[] reference is null, expected an array");
        }

        for ( int i = 0; i < pairs.length; i++ ) {
            if ( pairs[i] == null ) {
                throw new NullPointerException(
                    "index " + i + " of DSKeyValuePair[] is null");
            }
        }
    }

    protected void checkNoSuchElementException(DSBinarySearchTree<String, ?> ds,
                                               MethodAccess methodAccess) {
        boolean success = false;
        String methodText = methodAccess.formattedMethod();
        try {
            outln("count() is " + ds.getCount() +
                ", trying " + methodText + "...");
            methodAccess.execute(ds);
        } catch ( NoSuchElementException x ) {
            outln("expected this exception: " + x.toString());
            success = true;
        } catch ( Exception x ) {
            failureExceptionWithStackTrace(x);
        }

        if ( success ) {
            outln(methodText + " threw NoSuchElementException", true);
        } else {
            outln(methodText + " did NOT throw NoSuchElementException", false);
        }
    }

    protected static interface MethodAccess {
        String formattedMethod();
        void execute(DSBinarySearchTree<String, ?> ds);
    } // type MethodAccess

    protected static final class StringKeyValue
            extends AbstractDSKeyValuePair<String, String> {

        public static final StringKeyValue[] ZERO_LEN_ARRAY = new StringKeyValue[0];

        private final String key;
        private final String value;

        public StringKeyValue(String key, String value) {
            this.key = key;
            this.value = value;
        }

        public StringKeyValue(DSKeyValuePair<String, String> pair) {
            this(pair.getKey(), pair.getValue());
        }

        @SuppressWarnings("unchecked")
        public static StringKeyValue[] createArray(
                DSKeyValuePair<String, String>... pairs) {

            if ( ObjectTools.isEmpty(pairs) ) return ZERO_LEN_ARRAY;

            StringKeyValue[] results = new StringKeyValue[pairs.length];
            for ( int i = 0; i < results.length; i++ ) {
                results[i] = pairs[i] == null ? null : new StringKeyValue(pairs[i]);
            }
            return results;
        }

        @Override
        public String getKey() {
            return key;
        }

        @Override
        public String getValue() {
            return value;
        }
    } // type StringKeyValue
}
