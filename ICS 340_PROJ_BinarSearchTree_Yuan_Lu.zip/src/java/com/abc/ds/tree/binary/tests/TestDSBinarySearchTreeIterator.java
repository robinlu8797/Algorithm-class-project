package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.keyvalue.tests.*;
import com.abc.ds.tests.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeIterator extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeIterator(DSBinarySearchTreeFactory factory) {
        super("createIterator()", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testOnOne();
        testOnTwo();
        testOnSeveral();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - createIterator() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);
        outln("createIterator()...");
        checkIterator(ds.createIterator(), STRING_KV_ZERO_LEN_ARRAY);
    }

    @SuppressWarnings("unchecked")
    private void testOnOne() {
        outlnSeparator();
        outln(" - createIterator() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);
        checkIterator(ds.createIterator(), PAIR_VOLCANO);
    }

    @SuppressWarnings("unchecked")
    private void testOnTwo() {
        outlnSeparator();
        outln(" - createIterator() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);
        checkIterator(ds.createIterator(), PAIR_GLACIER, PAIR_OCEAN);
    }

    private void testOnSeveral() {
        outlnSeparator();
        outln(" - createIterator() on several -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding some junk to be cleared before createIterator() test...");
        insert(ds, "JUNK A", "trash A");
        insert(ds, "JUNK B", "trash B");
        insert(ds, "JUNK C", "trash C");
        outln("clear()...");
        ds.clear();

        DSKeyValuePair<String, String>[] fruits = new TestFruitPairGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        insert(ds, fruits);

        DSKeyValuePair<String, String>[] expectedFruits =
            shuffle(removeDuplicateKeys(fruits), new Random(0x00000000feedface));

        checkIterator(ds.createIterator(), expectedFruits);
    }
}
