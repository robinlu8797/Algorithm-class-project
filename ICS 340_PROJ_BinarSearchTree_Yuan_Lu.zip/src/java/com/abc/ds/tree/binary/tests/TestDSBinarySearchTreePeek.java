package com.abc.ds.tree.binary.tests;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreePeek extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreePeek(DSBinarySearchTreeFactory factory) {
        super("peek()", factory);
    }

    @Override
    protected void performTests() {
        testOneKey();
        testPeekRepeatedly();
        testSeveralKeys();
        testKeyDoesNotExist();
        testPeekOnEmpty();
    }

    private void testOneKey() {
        outlnSeparator();
        outln(" - one key -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(5);
        insert(tree, pairs);

        outln("peek(\"" + pairs[0].getKey() +
            "\")", tree.peek(pairs[0].getKey()), pairs[0]);
        checkCount(tree, pairs.length);
    }

    private void testPeekRepeatedly() {
        outlnSeparator();
        outln(" - peek() repeatedly -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(5);
        insert(tree, pairs);

        outln("peek(\"" + pairs[0].getKey() +
            "\")", tree.peek(pairs[0].getKey()), pairs[0]);
        outln("again, should be the same: peek(\"" + pairs[0].getKey() +
            "\")", tree.peek(pairs[0].getKey()), pairs[0]);
        outln("thrid time, should be the same: peek(\"" + pairs[0].getKey() +
            "\")", tree.peek(pairs[0].getKey()), pairs[0]);
    }

    private void testSeveralKeys() {
        outlnSeparator();
        outln(" - several keys -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(15);
        insert(tree, pairs);

        for ( int i = 0; i < pairs.length; i += 3 ) {
            outln("peek(\"" + pairs[i].getKey() +
                "\")", tree.peek(pairs[i].getKey()), pairs[i]);
        }
        checkCount(tree, pairs.length);
    }

    private void testKeyDoesNotExist() {
        outlnSeparator();
        outln(" - key does not exist -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(3);
        insert(tree, pairs);

        String key = "mystery";
        outln("peek(\"" + key + "\")", tree.peek(key), null);
    }

    private void testPeekOnEmpty() {
        outlnSeparator();
        outln(" - peek on empty -");
        DSBinarySearchTree<String, String> tree = createDS();
        checkIsEmpty(tree, true);
        String key = "ocean";
        outln("peek(\"" + key + "\")", tree.peek(key), null);
    }
}
