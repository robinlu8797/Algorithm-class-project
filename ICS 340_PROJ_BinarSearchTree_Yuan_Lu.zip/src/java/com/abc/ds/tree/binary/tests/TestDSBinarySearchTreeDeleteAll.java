package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.keyvalue.tests.*;
import com.abc.ds.tests.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDeleteAll extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDeleteAll(DSBinarySearchTreeFactory factory) {
        super("deleteAll()", factory);
    }

    @Override
    protected void performTests() {
        testDeleteAllOnEmpty();
        testDeleteAllOnOne();
        testDeleteAllOnTwo();
        testDeleteAllOnSeveral();
    }

    private void testDeleteAllOnEmpty() {
        outlnSeparator();
        outln(" - deleteAll() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);
        checkDeleteAllOnEmpty(ds);
        checkIsEmpty(ds, true);
    }

    @SuppressWarnings("unchecked")
    private void testDeleteAllOnOne() {
        outlnSeparator();
        outln(" - deleteAll() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);
        checkDeleteAll(ds, PAIR_VOLCANO);
        checkIsEmpty(ds, true);
    }

    @SuppressWarnings("unchecked")
    private void testDeleteAllOnTwo() {
        outlnSeparator();
        outln(" - deleteAll() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);
        checkDeleteAll(ds, PAIR_GLACIER, PAIR_OCEAN); // unordered
    }

    private void testDeleteAllOnSeveral() {
        outlnSeparator();
        outln(" - deleteAll() on several -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding some junk to be cleared before deleteAll() test...");
        insert(ds, "JUNK A", "trash A");
        insert(ds, "JUNK B", "trash B");
        insert(ds, "JUNK C", "trash C");
        outln("clear()...");
        ds.clear();

        DSKeyValuePair<String, String>[] fruits = new TestFruitPairGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        insert(ds, fruits);

        DSKeyValuePair<String, String>[] expectedFruits =
            shuffle(removeDuplicateKeys(fruits), new Random(0x00000000feedface));

        checkDeleteAll(ds, expectedFruits);
        checkIsEmpty(ds, true);
    }
}
