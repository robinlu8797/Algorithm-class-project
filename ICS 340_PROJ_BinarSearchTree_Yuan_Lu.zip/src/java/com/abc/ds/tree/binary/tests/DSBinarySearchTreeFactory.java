package com.abc.ds.tree.binary.tests;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.tree.binary.*;

public interface DSBinarySearchTreeFactory {
    <K> DSOrdering<K> getOrdering(DSBinarySearchTree<K, ?> tree);

    <K, V> DSBinarySearchTree<K, V> create(Class<K> keyType,
                                           Class<V> valueType,
                                           DSComparator<K> comparator);
}
