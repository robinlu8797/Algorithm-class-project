package com.abc.ds.tree.binary.tests;

import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeClear extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeClear(DSBinarySearchTreeFactory factory) {
        super("clear tests", factory);
    }

    @Override
    protected void performTests() {
        testAddThenClear();
        testAddThenClearThenAdd();
    }

    private void testAddThenClear() {
        outlnSeparator();
        outln(" - add, then clear -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding 5:");
        insert(ds, getFruitPairs(5));
        outln("checking getCount()", ds.getCount(), 5);
        outln("clear()");
        ds.clear();
        outln("checking isEmpty()", ds.isEmpty(), true);
        outln("checking getCount()", ds.getCount(), 0);
    }

    private void testAddThenClearThenAdd() {
        outlnSeparator();
        outln(" - add, then clear, then add -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding 20:");
        insert(ds, getFruitPairs(20));
        outln("checking getCount()", ds.getCount(), 20);

        outln("clear()");
        ds.clear();
        outln("checking getCount()", ds.getCount(), 0);
        outln("checking isEmpty()", ds.isEmpty(), true);

        outln("adding 6:");
        insert(ds, getFruitPairs(20, 6));
        outln("checking getCount()", ds.getCount(), 6);
        outln("checking isEmpty()", ds.isEmpty(), false);
    }
}
