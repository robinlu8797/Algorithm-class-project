package com.abc.ds.tree.binary;

import java.util.*;

import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.keyvalue.*;


public interface DSBinarySearchTree<K, V> {
    /**
     * Returns the comparator used to both sort items in the tree and
     * used to consider them to be equal or not equal to each other.
     * Neither the {@link Object#equals(Object) Object.equals()} method
     * nor the {@link Comparable#compareTo(Object)} [or {@link DSComparable#compareTo(Object)}] methods
     * on K are ever used. Only this {@link DSComparator} is used.
     * Implementations must ensure that this is never null.
     */
    DSComparator<K> getKeyComparator();

    /** Returns the type of the keys in this tree. */
    Class<K> getKeyType();

    /** Returns the type of the values in this tree. */
    Class<V> getValueType();

    /** Returns the number of key-value pairs currently in the tree. */
    int getCount();

    /** Returns true if there are no key-value pairs currently in the tree. */
    boolean isEmpty();

    /** Removes all the key-value pairs from the tree. */
    void clear();

    /**
     * Return the current number of levels in the tree.
     * An empty tree has a zero levels.
     */
    int getLevelCount();

    /**
     * Returns the current root node, never null.
     * @throws NoSuchElementException if empty. Check isEmpty() to avoid this.
     */
    Node<K, V> getRootNode() throws NoSuchElementException;

    /**
     * Inserts the specified key-value pair.
     * If a value was previously stored under this specified key, then the
     * value is updated and that old key-value pair is returned.
     * If nothing was previously stored under this specified key, then null is returned.
     */
    DSKeyValuePair<K, V> insert(K key, V value);

    /**
     * Returns the key-value pair stored by the specified key, or null if nothing is
     * stored under the key.
     */
    DSKeyValuePair<K, V> peek(K key);

    /**
     * Finds the current minimum key and returns the pair, never null.
     * @throws NoSuchElementException if empty. Check isEmpty() to avoid this.
     */
    DSKeyValuePair<K, V> peekMin() throws NoSuchElementException;

    /**
     * Finds the current maximum key and returns the pair, never null.
     * @throws NoSuchElementException if empty. Check isEmpty() to avoid this.
     */
    DSKeyValuePair<K, V> peekMax() throws NoSuchElementException;

    /**
     * Finds and returns the key-value pairs with keys which match the
     * specified filter.
     * If nothing matches, a zero-length array is returned.
     */
    DSKeyValuePair<K, V>[] peekKeyMatches(DSFilter<K> keyFilter);

    /**
     * Returns all the key-value pairs currently stored. If empty, a zero-length array is returned.
     */
    DSKeyValuePair<K, V>[] peekAll();

    /**
     * Finds the key, deletes the node, and returns the pair that was removed.
     * @return deleted pair, or null if the key was not found
     */
    DSKeyValuePair<K, V> delete(K keyToMatch);

    /**
     * Finds the current minimum key, deletes the node, and returns the pair that was removed.
     * @throws NoSuchElementException if empty. Check isEmpty() to avoid this.
     */
    DSKeyValuePair<K, V> deleteMin() throws NoSuchElementException;

    /**
     * Finds the current maximum key, deletes the node, and returns the pair that was removed.
     * @throws NoSuchElementException if empty. Check isEmpty() to avoid this.
     */
    DSKeyValuePair<K, V> deleteMax() throws NoSuchElementException;

    /**
     * Deletes the pairs with keys matching the specified filter returning
     * all the deleted pairs, never null.
     * If the filter is null or nothing matches, a zero-length array is returned.
     */
    DSKeyValuePair<K, V>[] deleteKeyMatches(DSFilter<K> keyFilter);

    /**
     * Deletes the pairs currently stored returning all the deleted pairs, never null.
     * If you want to delete everything, but don't need the pairs, use vastly more efficient {@link #clear()} instead.
     * If empty, a zero-length array is returned.
     */
    DSKeyValuePair<K, V>[] deleteAll();

    /**
     * Creates an iterator which goes is sorted order from min to max.
     */
    DSIterator<DSKeyValuePair<K, V>> createIterator();

    /**
     * Creates an iterator which goes is reverse sorted order from max to min.
     */
    DSIterator<DSKeyValuePair<K, V>> createReverseIterator();

    public static interface Node<K, V> {
        DSKeyValuePair<K, V> getPair();
        K getKey();
        V getValue();

        boolean hasLeftChild();
        boolean hasRightChild();
        Node<K, V> getLeftChildOrNull();
        Node<K, V> getRightChildOrNull();

        Node<K, V> findMin();
        Node<K, V> findMax();
    } // type Node
}
