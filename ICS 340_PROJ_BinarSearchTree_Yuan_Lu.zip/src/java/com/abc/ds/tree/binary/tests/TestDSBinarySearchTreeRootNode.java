package com.abc.ds.tree.binary.tests;

import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeRootNode extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeRootNode(DSBinarySearchTreeFactory factory) {
        super("getRootNode()", factory);
    }

    @Override
    protected void performTests() {
        testOne();
        testTwo();
        testEmpty();
    }

    private void testOne() {
        outlnSeparator();
        outln(" - add one, get root node -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        checkCount(ds, 1);
        outln("getRootNode()...");
        DSBinarySearchTree.Node<String, String> rootNode = ds.getRootNode();
        outln("rootNode != null", rootNode != null, true);
        outln("rootNode.getKey()", rootNode.getKey(), PAIR_OCEAN.getKey());
        outln("rootNode.getValue()", rootNode.getValue(), PAIR_OCEAN.getValue());
    }

    private void testTwo() {
        outlnSeparator();
        outln(" - add two, get root node -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_SCHOOL);
        checkCount(ds, 2);
        outln("getRootNode()...");
        DSBinarySearchTree.Node<String, String> rootNode = ds.getRootNode();
        outln("rootNode != null", rootNode != null, true);
        outln("rootNode.getKey()", rootNode.getKey(), PAIR_OCEAN.getKey());
        outln("rootNode.getValue()", rootNode.getValue(), PAIR_OCEAN.getValue());
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty, get root node -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("not inserting anything, leaving tree empty");

        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "getRootNode()";
            }

            @Override
            public void execute(DSBinarySearchTree<String, ?> t) {
                t.getRootNode();
            }
        });
    }
}
