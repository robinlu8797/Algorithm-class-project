package com.abc.ds.tree.binary.tests;

import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeFactoryCheck extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeFactoryCheck(DSBinarySearchTreeFactory factory) {
        super("factory check", factory);
    }

    @Override
    protected void performTests() {
        testCreate();
    }

    private void testCreate() {
        outln("Creating a new DSBinarySearchTree with " +
            "factory.create(String.class, String.class, 100, 0.7)...");
        DSBinarySearchTree<String, String> tree =
            factory.create(String.class, String.class, TestSuiteDSBinarySearchTree.STANDARD_STRING_COMPARATOR);
        outln("tree != null", tree != null, true);
    }
}
