package com.abc.ds.tree.binary.tests;

import com.abc.ds.filter.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreePeekKeyMatches extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreePeekKeyMatches(DSBinarySearchTreeFactory factory) {
        super("peekKeyMatches()", factory);
    }

    @Override
    protected void performTests() {
        testPeekKeyMatchesOnEmpty();
        testPeekKeyMatchesOnOne();
        testPeekKeyMatchesOnTwo();
        testPeekKeyMatchesOnFive();
    }

    private void testPeekKeyMatchesOnEmpty() {
        outlnSeparator();
        outln(" - peekKeyMatches() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);

        DSFilter<String> filter = createStringLengthFilter(5);
        outln("filtering with: " + filter);
        checkPeekKeyMatches(ds, filter, STRING_KV_ZERO_LEN_ARRAY);
    }

    @SuppressWarnings("unchecked")
    private void testPeekKeyMatchesOnOne() {
        outlnSeparator();
        outln(" - peekKeyMatches() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkPeekKeyMatches(ds, filter, PAIR_VOLCANO);
    }

    @SuppressWarnings("unchecked")
    private void testPeekKeyMatchesOnTwo() {
        outlnSeparator();
        outln(" - peekKeyMatches() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkPeekKeyMatches(ds, filter, PAIR_GLACIER);
    }

    @SuppressWarnings("unchecked")
    private void testPeekKeyMatchesOnFive() {
        outlnSeparator();
        outln(" - peekKeyMatches() on five -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_BEACH, PAIR_GLACIER, PAIR_LAKE, PAIR_OCEAN, PAIR_SCHOOL, PAIR_VOLCANO);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkPeekKeyMatches(ds, filter,
            StringKeyValue.createArray(PAIR_VOLCANO, PAIR_GLACIER));
    }
}
