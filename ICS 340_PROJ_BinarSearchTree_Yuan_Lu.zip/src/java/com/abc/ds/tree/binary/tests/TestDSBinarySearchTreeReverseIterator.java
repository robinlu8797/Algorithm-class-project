package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.keyvalue.tests.*;
import com.abc.ds.tests.*;
import com.abc.ds.tree.binary.*;
import com.programix.collections.*;

/* deliberate package access */
class TestDSBinarySearchTreeReverseIterator extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeReverseIterator(DSBinarySearchTreeFactory factory) {
        super("createReverseIterator()", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testOnOne();
        testOnTwo();
        testOnSeveral();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - createReverseIterator() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);
        outln("createReverseIterator()...");
        checkIterator(ds.createReverseIterator(), STRING_KV_ZERO_LEN_ARRAY);
    }

    @SuppressWarnings("unchecked")
    private void testOnOne() {
        outlnSeparator();
        outln(" - createReverseIterator() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);
        checkIterator(ds.createReverseIterator(), PAIR_VOLCANO);
    }

    @SuppressWarnings("unchecked")
    private void testOnTwo() {
        outlnSeparator();
        outln(" - createReverseIterator() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);
        checkIteratorWithoutSortingExpected(ds.createReverseIterator(),
            PAIR_OCEAN, PAIR_GLACIER);
    }

    private void testOnSeveral() {
        outlnSeparator();
        outln(" - createReverseIterator() on several -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding some junk to be cleared before createReverseIterator() test...");
        insert(ds, "JUNK A", "trash A");
        insert(ds, "JUNK B", "trash B");
        insert(ds, "JUNK C", "trash C");
        outln("clear()...");
        ds.clear();

        DSKeyValuePair<String, String>[] fruits = new TestFruitPairGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        insert(ds, fruits);

        DSKeyValuePair<String, String>[] expectedFruits =
            shuffle(removeDuplicateKeys(fruits), new Random(0x00000000feedface));
        List<DSKeyValuePair<String, String>> list = new ArrayList<>(Arrays.asList(expectedFruits));
        Collections.sort(list, new ReverseComparator<>(pairJavaComparator));
        expectedFruits = list.toArray(STRING_KV_ZERO_LEN_ARRAY);

        checkIteratorWithoutSortingExpected(ds.createReverseIterator(),
            expectedFruits);
    }
}
