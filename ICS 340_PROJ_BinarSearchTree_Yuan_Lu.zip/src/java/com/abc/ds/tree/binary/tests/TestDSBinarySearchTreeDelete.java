package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDelete extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDelete(DSBinarySearchTreeFactory factory) {
        super("delete()", factory);
    }

    @Override
    protected void performTests() {
        testOneKey();
        testDeleteRepeatedly();
        testSeveralKeys();
        testKeyDoesNotExist();
        testDeleteOnEmpty();
    }

    private void testOneKey() {
        outlnSeparator();
        outln(" - one key -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(5);
        insert(tree, pairs);

        outln("delete(\"" + pairs[0].getKey() +
            "\")", tree.delete(pairs[0].getKey()), pairs[0]);
        checkCount(tree, pairs.length - 1);
    }

    private void testDeleteRepeatedly() {
        outlnSeparator();
        outln(" - delete() twice -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(5);
        insert(tree, pairs);

        outln("delete(\"" + pairs[0].getKey() +
            "\")", tree.delete(pairs[0].getKey()), pairs[0]);
        outln("delete(\"" + pairs[1].getKey() +
            "\")", tree.delete(pairs[1].getKey()), pairs[1]);
        checkCount(tree, pairs.length - 2);
    }

    private void testSeveralKeys() {
        outlnSeparator();
        outln(" - several keys -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(15);
        insert(tree, pairs);

        Map<String, DSKeyValuePair<String, String>> map = new LinkedHashMap<>();
        for ( DSKeyValuePair<String, String> pair : pairs ) {
            map.put(pair.getKey(), pair);
        }
        DSKeyValuePair<String, String>[] zeroLenPairArray = DSKeyValueTools.createArray(String.class, String.class, 0);

        for ( int i = 0; i < pairs.length; i += 3 ) {
            outln("delete(\"" + pairs[i].getKey() +
                "\")", tree.delete(pairs[i].getKey()), pairs[i]);
            map.remove(pairs[i].getKey());
        }
        checkPeekAll(tree, map.values().toArray(zeroLenPairArray));
    }

    private void testKeyDoesNotExist() {
        outlnSeparator();
        outln(" - key does not exist -");
        DSBinarySearchTree<String, String> tree = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairsShuffled(3);
        insert(tree, pairs);

        String key = "mystery";
        outln("delete(\"" + key + "\")", tree.delete(key), null);
        checkCount(tree, pairs.length);
    }

    private void testDeleteOnEmpty() {
        outlnSeparator();
        outln(" - delete on empty -");
        DSBinarySearchTree<String, String> tree = createDS();
        checkIsEmpty(tree, true);
        String key = "ocean";
        outln("delete(\"" + key + "\")", tree.delete(key), null);
        checkCount(tree, 0);

    }
}
