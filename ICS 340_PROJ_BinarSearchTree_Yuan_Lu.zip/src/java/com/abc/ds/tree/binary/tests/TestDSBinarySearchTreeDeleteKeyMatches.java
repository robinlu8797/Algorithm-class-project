package com.abc.ds.tree.binary.tests;

import com.abc.ds.filter.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDeleteKeyMatches extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDeleteKeyMatches(DSBinarySearchTreeFactory factory) {
        super("deleteKeyMatches()", factory);
    }

    @Override
    protected void performTests() {
        testDeleteKeyMatchesOnEmpty();
        testDeleteKeyMatchesOnOne();
        testDeleteKeyMatchesOnTwo();
        testDeleteKeyMatchesOnFive();
    }

    private void testDeleteKeyMatchesOnEmpty() {
        outlnSeparator();
        outln(" - deleteKeyMatches() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);

        DSFilter<String> filter = createStringLengthFilter(5);
        outln("filtering with: " + filter);
        checkDeleteKeyMatches(ds, filter, STRING_KV_ZERO_LEN_ARRAY);
    }

    @SuppressWarnings("unchecked")
    private void testDeleteKeyMatchesOnOne() {
        outlnSeparator();
        outln(" - deleteKeyMatches() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkDeleteKeyMatches(ds, filter, PAIR_VOLCANO);
    }

    @SuppressWarnings("unchecked")
    private void testDeleteKeyMatchesOnTwo() {
        outlnSeparator();
        outln(" - deleteKeyMatches() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkDeleteKeyMatches(ds, filter, PAIR_GLACIER);
    }

    @SuppressWarnings("unchecked")
    private void testDeleteKeyMatchesOnFive() {
        outlnSeparator();
        outln(" - deleteKeyMatches() on five -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_BEACH, PAIR_GLACIER, PAIR_LAKE, PAIR_OCEAN, PAIR_SCHOOL, PAIR_VOLCANO);

        DSFilter<String> filter = createStringLengthFilter(7);
        outln("filtering with: " + filter);
        checkDeleteKeyMatches(ds, filter,
            StringKeyValue.createArray(PAIR_VOLCANO, PAIR_GLACIER));
    }
}
