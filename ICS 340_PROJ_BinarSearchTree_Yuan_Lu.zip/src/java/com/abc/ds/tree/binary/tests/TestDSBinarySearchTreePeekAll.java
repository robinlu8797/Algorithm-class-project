package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.keyvalue.tests.*;
import com.abc.ds.tests.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreePeekAll extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreePeekAll(DSBinarySearchTreeFactory factory) {
        super("peekAll()", factory);
    }

    @Override
    protected void performTests() {
        testPeekAllOnEmpty();
        testPeekAllOnOne();
        testPeekAllOnTwo();
        testPeekAllOnSeveral();
    }

    private void testPeekAllOnEmpty() {
        outlnSeparator();
        outln(" - peekAll() on empty -");
        DSBinarySearchTree<String, String> ds = createDS();
        checkIsEmpty(ds, true);
        checkPeekAllOnEmpty(ds);
    }

    @SuppressWarnings("unchecked")
    private void testPeekAllOnOne() {
        outlnSeparator();
        outln(" - peekAll() on one -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_VOLCANO);
        checkPeekAll(ds, PAIR_VOLCANO);
    }

    @SuppressWarnings("unchecked")
    private void testPeekAllOnTwo() {
        outlnSeparator();
        outln(" - peekAll() on two -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN, PAIR_GLACIER);
        checkPeekAll(ds, PAIR_GLACIER, PAIR_OCEAN); // unordered
    }

    private void testPeekAllOnSeveral() {
        outlnSeparator();
        outln(" - peekAll() on several -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("adding some junk to be cleared before peekAll() test...");
        insert(ds, "JUNK A", "trash A");
        insert(ds, "JUNK B", "trash B");
        insert(ds, "JUNK C", "trash C");
        outln("clear()...");
        ds.clear();

        DSKeyValuePair<String, String>[] fruits = new TestFruitPairGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        insert(ds, fruits);

        DSKeyValuePair<String, String>[] expectedFruits =
            shuffle(removeDuplicateKeys(fruits), new Random(0x00000000feedface));

        checkPeekAll(ds, expectedFruits);
    }
}
