package com.abc.ds.tree.binary.tests;

import com.abc.ds.compare.*;
import com.programix.testing.*;
import com.programix.util.*;

public class TestSuiteDSBinarySearchTree {
    public static final DSComparator<String> STANDARD_STRING_COMPARATOR =
        StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC;

    public static final DSComparator<Integer> STANDARD_INTEGER_COMPARATOR =
        new NullDSComparator<>(DSNullOrdering.NULL_FIRST, new DSComparator<Integer>() {
            @Override
            public DSCompareResult compare(Integer a, Integer b) {
                return DSCompareResult.instanceFor(a.compareTo(b));
            }
        });

    // no instances
    private TestSuiteDSBinarySearchTree() {
    }

    public static BaseTest[] createAllTests(DSBinarySearchTreeFactory factory) {
        ObjectTools.paramNullCheck(factory, "factory");

        return new BaseTest[] {
            new TestDSBinarySearchTreeFactoryCheck(factory),
            new TestDSBinarySearchTreeKeyAndValueTypes(factory),
            new TestDSBinarySearchTreeBasicEmptyCount(factory),
            new TestDSBinarySearchTreeClear(factory),
            new TestDSBinarySearchTreePeek(factory),
            new TestDSBinarySearchTreeDuplicateKeyCount(factory),
            new TestDSBinarySearchTreeDuplicateKeyOldValue(factory),
            new TestDSBinarySearchTreePeekAll(factory),
            new TestDSBinarySearchTreePeekKeyMatches(factory),
            new TestDSBinarySearchTreeRootNode(factory),
            new TestDSBinarySearchTreePeekMin(factory),
            new TestDSBinarySearchTreePeekMax(factory),
            new TestDSBinarySearchTreeDelete(factory),
            new TestDSBinarySearchTreeDeleteMin(factory),
            new TestDSBinarySearchTreeDeleteMax(factory),
            new TestDSBinarySearchTreeDeleteKeyMatches(factory),
            new TestDSBinarySearchTreeDeleteAll(factory),
            new TestDSBinarySearchTreeIterator(factory),
            new TestDSBinarySearchTreeReverseIterator(factory),
        };
    }

    public static TestChunk[] createAllTestChunks(DSBinarySearchTreeFactory factory) {
        return StandardTestChunk.createAll(createAllTests(factory));
    }
}
