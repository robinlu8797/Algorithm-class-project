package com.abc.ds.tree.binary.tests;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDuplicateKeyOldValue extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDuplicateKeyOldValue(DSBinarySearchTreeFactory factory) {
        super("insert duplicate - old value return check", factory);
    }

    @Override
    protected void performTests() {
        testNonNull();
        testCorrectOldValueReturned();
    }

    private void testNonNull() {
        outlnSeparator();
        outln(" - non-null returned -");
        DSBinarySearchTree<String, String> ds = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairs(5);
        insert(ds, pairs);
        outln("checking getCount()", ds.getCount(), pairs.length);

        String duplicateKey = pairs[1].getKey();
        String newValue = "new value for dup key";

        outln("attepting to insert duplicate key, should return non-null...");
        outln("insert(\"" + duplicateKey + "\", \"" + newValue + "\") != null",
            ds.insert(duplicateKey, newValue) != null, true);
        outln("checking getCount() [should not have changed]",
            ds.getCount(), pairs.length);
    }

    private void testCorrectOldValueReturned() {
        outlnSeparator();
        outln(" - correct old value returned -");
        DSBinarySearchTree<String, String> ds = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairs(5);
        insert(ds, pairs);
        outln("checking getCount()", ds.getCount(), pairs.length);

        DSKeyValuePair<String, String> dupKeyPair = pairs[1];
        String duplicateKey = dupKeyPair.getKey();
        String newValue = "new value for dup key";
        String expectedOldValue = dupKeyPair.getValue();

        outln("attepting to insert duplicate key...");
        outln("insert(\"" + duplicateKey + "\", \"" + newValue + "\") returned",
            ds.insert(duplicateKey, newValue).getValue(), expectedOldValue);

        outln("checking getCount() [should not have changed]",
            ds.getCount(), pairs.length);
    }
}
