package com.abc.ds.tree.binary.tests;

import java.util.*;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeDuplicateKeyCount extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeDuplicateKeyCount(DSBinarySearchTreeFactory factory) {
        super("insert duplicate - getCount() checks", factory);
    }

    @Override
    protected void performTests() {
        testOneDup();
        testMultipleDup();
    }

    private void testOneDup() {
        outlnSeparator();
        outln(" - one duplicate -");
        DSBinarySearchTree<String, String> ds = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairs(5);
        insert(ds, pairs);
        outln("checking getCount() before dup", ds.getCount(), pairs.length);
        String duplicateKey = pairs[2].getKey();
        String newValue = "new value for dup key";
        insert(ds, duplicateKey, newValue);
        outln("checking getCount() after dup", ds.getCount(), pairs.length);
    }

    private void testMultipleDup() {
        outlnSeparator();
        outln(" - multiple duplicates -");
        DSBinarySearchTree<String, String> ds = createDS();
        DSKeyValuePair<String, String>[] pairs = getFruitPairs(12);
        insert(ds, pairs);
        outln("checking getCount() before duplicates", ds.getCount(), pairs.length);

        List<DSKeyValuePair<String, String>> list =
            new ArrayList<>(Arrays.asList(pairs));
        Collections.shuffle(list, new Random(1234));
        for ( DSKeyValuePair<String, String> pair : list ) {
            insert(ds, pair.getKey(), "NewValue-" + pair.getValue());
        }
        outln("checking getCount() after adding duplicates", ds.getCount(), pairs.length);
    }
}
