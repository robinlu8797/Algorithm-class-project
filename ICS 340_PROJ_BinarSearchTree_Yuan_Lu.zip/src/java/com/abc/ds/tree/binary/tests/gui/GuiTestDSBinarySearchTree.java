package com.abc.ds.tree.binary.tests.gui;

import com.abc.ds.tree.binary.tests.*;
import com.programix.testing.*;

public class GuiTestDSBinarySearchTree {
    public static void runTests(final String title,
                                final DSBinarySearchTreeFactory factory) {

        ParallelTestingPane.createFramedInstance(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSBinarySearchTree.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }
}
