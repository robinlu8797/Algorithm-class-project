package com.abc.ds.tree.binary.tests;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreePeekMax extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreePeekMax(DSBinarySearchTreeFactory factory) {
        super("peekMax()", factory);
    }

    @Override
    protected void performTests() {
        testOne();
        testSeveralInsertOrderA();
        testSeveralInsertOrderB();
        testSeveralInsertOrderC();
        testEmpty();
    }

    private void testOne() {
        outlnSeparator();
        outln(" - insert one, peekMax() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        outln("peekMax()...");
        DSKeyValuePair<String, String> min = ds.peekMax();
        outln("min != null", min != null, true);
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testSeveralInsertOrderA() {
        outlnSeparator();
        outln(" - insert several in order A, peekMax() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        outln("peekMax()...");
        DSKeyValuePair<String, String> min = ds.peekMax();
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testSeveralInsertOrderB() {
        outlnSeparator();
        outln(" - insert several in order B, peekMax() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_BEACH);
        outln("peekMax()...");
        DSKeyValuePair<String, String> min = ds.peekMax();
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testSeveralInsertOrderC() {
        outlnSeparator();
        outln(" - insert several in order C, peekMax() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        outln("peekMax()...");
        DSKeyValuePair<String, String> min = ds.peekMax();
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty, peekMax() -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("not inserting anything, leaving tree empty");

        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekMax()";
            }

            @Override
            public void execute(DSBinarySearchTree<String, ?> t) {
                t.peekMax();
            }
        });
    }
}
