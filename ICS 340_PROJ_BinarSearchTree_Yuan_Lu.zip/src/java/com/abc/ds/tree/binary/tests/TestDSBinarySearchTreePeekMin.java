package com.abc.ds.tree.binary.tests;

import com.abc.ds.keyvalue.*;
import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreePeekMin extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreePeekMin(DSBinarySearchTreeFactory factory) {
        super("peekMin()", factory);
    }

    @Override
    protected void performTests() {
        testOne();
        testSeveralInsertOrderA();
        testSeveralInsertOrderB();
        testSeveralInsertOrderC();
        testRepeatedly();
        testEmpty();
    }

    private void testOne() {
        outlnSeparator();
        outln(" - insert one, peekMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        outln("peekMin()...");
        DSKeyValuePair<String, String> min = ds.peekMin();
        outln("min != null", min != null, true);
        outln("min.getKey()", min.getKey(), PAIR_OCEAN.getKey());
        outln("min.getValue()", min.getValue(), PAIR_OCEAN.getValue());
    }

    private void testSeveralInsertOrderA() {
        outlnSeparator();
        outln(" - insert several in order A, peekMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        outln("peekMin()...");
        DSKeyValuePair<String, String> min = ds.peekMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testSeveralInsertOrderB() {
        outlnSeparator();
        outln(" - insert several in order B, peekMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_GLACIER);
        insert(ds, PAIR_BEACH);
        outln("peekMin()...");
        DSKeyValuePair<String, String> min = ds.peekMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testSeveralInsertOrderC() {
        outlnSeparator();
        outln(" - insert several in order C, peekMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        outln("peekMin()...");
        DSKeyValuePair<String, String> min = ds.peekMin();
        outln("min.getKey()", min.getKey(), PAIR_BEACH.getKey());
        outln("min.getValue()", min.getValue(), PAIR_BEACH.getValue());
    }

    private void testRepeatedly() {
        outlnSeparator();
        outln(" - insert several, peekMin() should keep returning same value -");
        DSBinarySearchTree<String, String> ds = createDS();
        insert(ds, PAIR_LAKE);
        insert(ds, PAIR_OCEAN);
        insert(ds, PAIR_BEACH);
        insert(ds, PAIR_GLACIER);
        outln("peekMin()", ds.peekMin(), PAIR_BEACH);
        outln("peekMin()", ds.peekMin(), PAIR_BEACH);
        outln("peekMin()", ds.peekMin(), PAIR_BEACH);
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty, peekMin() -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("not inserting anything, leaving tree empty");

        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekMin()";
            }

            @Override
            public void execute(DSBinarySearchTree<String, ?> t) {
                t.peekMin();
            }
        });
    }
}
