package com.abc.ds.tree.binary;

public class TreePrinter<N> {
    private static final String INDENT_TEXT = "    ";
    private static final String ROOT_PREFIX = "root: ";
    private static final String LEFT_PREFIX =  "left : ";
    private static final String RIGHT_PREFIX = "right: ";

    private final NodeAccess<N> nodeAccess;
    private final Output output;

    public TreePrinter(NodeAccess<N> nodeAccess, Output output) {
        this.nodeAccess = nodeAccess;
        this.output = output;
    }

    public TreePrinter(NodeAccess<N> nodeAccess) {
        this(nodeAccess, Output.CONSOLE);
    }

    public void printTree(N nodeToStartFrom) {
        printTree(0, nodeToStartFrom, ROOT_PREFIX);
    }

    private void printTree(int indentLevel, N currNode, String currPrefix) {
        StringBuilder sb = new StringBuilder();
        for ( int i = 0; i < indentLevel; i++ ) {
            sb.append(INDENT_TEXT);
        }
        sb.append(currPrefix);
        sb.append(currNode != null ? nodeAccess.formatForDisplay(currNode) : "<null>");
        output.outln(sb.toString());

        if (currNode != null) {
            N leftChild = nodeAccess.getLeftChild(currNode);
            N rightChild = nodeAccess.getRightChild(currNode);
            if (leftChild != null || rightChild != null) {
                printTree(indentLevel + 1, leftChild, LEFT_PREFIX);
                printTree(indentLevel + 1, rightChild, RIGHT_PREFIX);
            }
        }
    }

    public static interface Output {
        public static final Output CONSOLE = new Output() {
            @Override
            public void outln(String msg) {
                System.out.println(msg);
            }

            @Override
            public void out(String msg) {
                System.out.print(msg);
            }
        };

        void outln(String msg);
        void out(String msg);
    } // type Output

    public static interface NodeAccess<N> {
        N getLeftChild(N node);
        N getRightChild(N node);
        String formatForDisplay(N node);
    } // type NodeAccess
}
