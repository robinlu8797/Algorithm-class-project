package com.abc.ds.tree.binary.tests;

import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeBasicEmptyCount extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeBasicEmptyCount(DSBinarySearchTreeFactory factory) {
        super("empty and count tests", factory);
    }

    @Override
    protected void performTests() {
        testInitialState();
        testAddJustOne();
        testAddTwo();
        testAddFive();
    }

    private void testInitialState() {
        outlnSeparator();
        DSBinarySearchTree<String, String> ht = createDS();
        outln("initial state: ");
        outln("checking isEmpty()", ht.isEmpty(), true);
        outln("checking getCount()", ht.getCount(), 0);
    }

    private void testAddJustOne() {
        outlnSeparator();
        outln(" - add just one -");
        DSBinarySearchTree<String, String> ht = createDS();
        insert(ht, getFruitPairs(1));
        outln("checking isEmpty()", ht.isEmpty(), false);
        outln("checking getCount()", ht.getCount(), 1);
    }

    private void testAddTwo() {
        outlnSeparator();
        outln(" - add two -");
        DSBinarySearchTree<String, String> ht = createDS();
        insert(ht, getFruitPairs(2));
        outln("checking isEmpty()", ht.isEmpty(), false);
        outln("checking getCount()", ht.getCount(), 2);
    }

    private void testAddFive() {
        outlnSeparator();
        outln(" - add five -");
        DSBinarySearchTree<String, String> ht = createDS();
        insert(ht, getFruitPairs(5));
        outln("checking isEmpty()", ht.isEmpty(), false);
        outln("checking getCount()", ht.getCount(), 5);
    }
}
