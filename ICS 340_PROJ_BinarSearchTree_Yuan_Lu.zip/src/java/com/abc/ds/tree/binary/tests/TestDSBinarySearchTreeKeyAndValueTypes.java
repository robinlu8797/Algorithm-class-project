package com.abc.ds.tree.binary.tests;

import java.math.*;

import com.abc.ds.tree.binary.*;

/* deliberate package access */
class TestDSBinarySearchTreeKeyAndValueTypes extends TestDSBinarySearchTreeBase {
    public TestDSBinarySearchTreeKeyAndValueTypes(DSBinarySearchTreeFactory factory) {
        super("key type and value type", factory);
    }

    @Override
    protected void performTests() {
        testItemTypeStandard();
        testItemTypeDifferentKeyAndValueTypes();
    }

    private void testItemTypeStandard() {
        outlnSeparator();
        outln(" - types: <String, String> -");
        DSBinarySearchTree<String, String> ds = createDS();
        outln("getKeyType()", ds.getKeyType(), String.class);
        outln("getValueType()", ds.getValueType(), String.class);
    }

    private void testItemTypeDifferentKeyAndValueTypes() {
        outlnSeparator();
        outln(" - types: <Integer, BigDecimal> -");
        DSBinarySearchTree<Integer, BigDecimal> ds =
            factory.create(Integer.class, BigDecimal.class, TestSuiteDSBinarySearchTree.STANDARD_INTEGER_COMPARATOR);
        outln("getKeyType()", ds.getKeyType(), Integer.class);
        outln("getValueType()", ds.getValueType(), BigDecimal.class);
    }
}
