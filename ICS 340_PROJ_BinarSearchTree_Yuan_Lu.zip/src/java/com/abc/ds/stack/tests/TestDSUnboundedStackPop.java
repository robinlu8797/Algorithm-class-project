package com.abc.ds.stack.tests;

import java.util.*;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackPop extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackPop(DSUnboundedStackFactory factory) {
        super("pop()", factory);
    }

    @Override
    protected void performTests() {
        testOneItem();
        testTwoItems();
        testSeveralItems();
        testEmpty();
    }

    private void testOneItem() {
        outlnSeparator();
        outln(" - one item -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        outln("pop()", stack.pop(), "apple");
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testTwoItems() {
        outlnSeparator();
        outln(" - two items -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        push(stack, "banana");
        outln("pop()", stack.pop(), "banana");
        outln("pop()", stack.pop(), "apple");
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testSeveralItems() {
        outlnSeparator();
        outln(" - several items -");
        DSUnboundedStack<String> stack = createDS();
        String[] fruits = getFruits(15);
        for ( String fruit : fruits ) {
            push(stack, fruit);
        }
        reverseArray(fruits);
        for ( String fruit : fruits ) {
            outln("pop()", stack.pop(), fruit);
        }
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty (NoSuchElementException) -");
        DSUnboundedStack<String> stack = createDS();

        outln("confirming isEmpty()", stack.isEmpty(), true);
        if ( !stack.isEmpty() ) {
            outlnErrorText("Cannot proceed with peek on empty tests: " +
                "newly created should be empty but is not");
            return;
        }

        testEmptyHelper(stack);

        push(stack, getFruits(5));
        outln("clear()");
        stack.clear();

        testEmptyHelper(stack);
    }

    private void testEmptyHelper(DSUnboundedStack<?> stack) {
        if ( !stack.isEmpty() ) {
            outln("can't attempt - isEmpty() is not returning true", false);
            return;
        }

        boolean success = false;
        try {
            outln("empty, trying pop()...");
            stack.pop();
        } catch ( NoSuchElementException x ) {
            outln("expected this exception: " + x.toString());
            success = true;
        } catch ( Exception x ) {
            failureExceptionWithStackTrace(x);
        }

        if ( success ) {
            outln("pop() on an empty stack " +
                "threw NoSuchElementException", true);
        } else {
            outln("pop() on an empty list " +
                "did NOT throw NoSuchElementException", false);
        }
    }
}
