package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackBasicEmptyCount extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackBasicEmptyCount(DSUnboundedStackFactory factory) {
        super("empty and count tests", factory);
    }

    @Override
    protected void performTests() {
        testInitialState();
        testAddJustOne();
        testAddTwo();
        testAddFive();
    }

    private void testInitialState() {
        outlnSeparator();
        DSUnboundedStack<String> stack = createDS();
        outln("initial state: ");
        outln("checking isEmpty()", stack.isEmpty(), true);
        outln("checking count()", stack.count(), 0);
    }

    private void testAddJustOne() {
        outlnSeparator();
        outln(" - push just one -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, getFruits(1));
        outln("checking isEmpty()", stack.isEmpty(), false);
        outln("checking count()", stack.count(), 1);
    }

    private void testAddTwo() {
        outlnSeparator();
        outln(" - push two -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, getFruits(2));
        outln("checking isEmpty()", stack.isEmpty(), false);
        outln("checking count()", stack.count(), 2);
    }

    private void testAddFive() {
        outlnSeparator();
        outln(" - push five -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, getFruits(5));
        outln("checking isEmpty()", stack.isEmpty(), false);
        outln("checking count()", stack.count(), 5);
    }
}
