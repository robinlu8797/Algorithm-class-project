package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackFactoryCheck extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackFactoryCheck(DSUnboundedStackFactory factory) {
        super("factory check", factory);
    }

    @Override
    protected void performTests() {
        testCreate();
    }

    private void testCreate() {
        outlnSeparator();
        outln("Creating a new DSUnboundedStack with " +
            "factory.create(String.class)...");
        DSUnboundedStack<String> stack = factory.create(String.class);
        outln("stack != null", stack != null, true);
    }
}
