package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;
import com.abc.ds.tests.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSUnboundedStackMixedBag extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackMixedBag(DSUnboundedStackFactory factory) {
        super("mixed bag", factory);
    }

    @Override
    protected void performTests() {
        testA();
    }

    private void testA() {
        outlnSeparator();
        outln(" - Test A -");
        DSUnboundedStack<String> stack = createDS();

        TestFruitGenerator fruitGen =
            new TestFruitGenerator(TestFruitGenerator.RANDOM_SEED_15);

        String[] fruitsA = fruitGen.next(2);
        push(stack, fruitsA);
        outln("checking count()", stack.count(), 2);
        reverseArray(fruitsA);
        for ( String fruit : fruitsA ) {
            outln("pop()", stack.pop(), fruit);
        }
        outln("checking count()", stack.count(), 0);

        String[] fruitsB = fruitGen.next(3);
        push(stack, fruitsB);
        reverseArray(fruitsB);
        for ( String fruit : fruitsB ) {
            outln("pop()", stack.pop(), fruit);
        }
        outln("checking count()", stack.count(), 0);

        String[] fruitsC = fruitGen.next(40);
        outln("pushAll(" + StringTools.formatCommaDelimited(fruitsC) + ")...");
        stack.pushAll(fruitsC);
        reverseArray(fruitsC);
        outln("popAll()", stack.popAll(), fruitsC);

        String[] colorA = new String[] { "red", null, "green", "red", null };
        outln("pushAll(" + StringTools.formatCommaDelimited(colorA) + ")...");
        stack.pushAll(colorA);
        outln("checking count()", stack.count(), 5);
        outln("pop()", stack.pop(), colorA[4]);
        outln("pop()", stack.pop(), colorA[3]);
        outln("checking count()", stack.count(), 3);
        String[] colorB = new String[] { "blue", "white", null, "orange" };
        for ( String color : colorB ) {
            push(stack, color);
        }
        outln("checking count()", stack.count(), 7);
        outln("pop()", stack.pop(), colorB[3]);
        outln("pop()", stack.pop(), colorB[2]);
        outln("pop()", stack.pop(), colorB[1]);
        outln("pop()", stack.pop(), colorB[0]);
        outln("pop()", stack.pop(), colorA[2]);
        outln("checking count()", stack.count(), 2);

        outln("clear()...");
        stack.clear();
        outln("checking count()", stack.count(), 0);

        String[] colorC = new String[] { "yellow", "green", "pink" };
        push(stack, colorC);
        outln("checking count()", stack.count(), 3);
        outln("pop()", stack.pop(), colorC[2]);
        outln("pop()", stack.pop(), colorC[1]);
        outln("pop()", stack.pop(), colorC[0]);
    }
}
