package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;
import com.abc.ds.tests.*;

/* deliberate package access */
class TestDSUnboundedStackPeekAll extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackPeekAll(DSUnboundedStackFactory factory) {
        super("peekAll()", factory);
    }

    @Override
    protected void performTests() {
        testPeekAllOnEmpty();
        testPeekAllOnOne();
        testPeekAllOnTwo();
        testPeekAllOnSeveral();
    }

    private void testPeekAllOnEmpty() {
        outlnSeparator();
        outln(" - peekAll() on empty -");
        DSUnboundedStack<String> ds = createDS();
        outln("isEmpty()", ds.isEmpty(), true);

        checkPeekAllOnEmpty(ds);
    }

    private void testPeekAllOnOne() {
        outlnSeparator();
        outln(" - peekAll() on one -");
        DSUnboundedStack<String> ds = createDS();
        push(ds, "apple");
        checkPeekAll(ds, "apple");
    }

    private void testPeekAllOnTwo() {
        outlnSeparator();
        outln(" - peekAll() on two -");
        DSUnboundedStack<String> ds = createDS();
        push(ds, "apple");
        push(ds, "banana");
        checkPeekAll(ds, "banana", "apple");
        outln("isEmpty()", ds.isEmpty(), false);
    }

    private void testPeekAllOnSeveral() {
        outlnSeparator();
        outln(" - peekAll() on several -");
        DSUnboundedStack<String> ds = createDS();
        outln("pushing some junk to be cleared before peekAll() test...");
        push(ds, "JUNK A");
        push(ds, "JUNK B");
        push(ds, "JUNK C");
        outln("clear()...");
        ds.clear();

        String[] fruits = new TestFruitGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        push(ds, fruits);
        reverseArray(fruits);
        checkPeekAll(ds, fruits);
        outln("Checking that calling peekAll() didn't alter anything... should give same results...");
        checkPeekAll(ds, fruits);
    }
}
