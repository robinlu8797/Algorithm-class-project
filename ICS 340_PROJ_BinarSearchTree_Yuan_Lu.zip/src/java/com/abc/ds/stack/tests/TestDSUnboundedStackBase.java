package com.abc.ds.stack.tests;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.stack.*;
import com.abc.ds.tests.*;
import com.programix.util.*;

/* deliberate package access */
abstract class TestDSUnboundedStackBase extends TestDSBase {
    protected final DSUnboundedStackFactory factory;
    protected final TestDSHelper<String> testHelper;

    protected TestDSUnboundedStackBase(String titleSuffix,
                                       DSUnboundedStackFactory factory) {
        super("DSUnboundedStack - " + titleSuffix);
        this.factory = factory;
        testHelper = new TestDSHelper.Builder<String>()
            .setItemType(String.class)
            .setTestAccess(testAccess)
            .setAllowDuplicates(true)
            .setOrdering(DSOrdering.createOrderedByInsertion(String.class))
            .setWrapItemsInQuotes(true)
            .create();
    }

    protected DSUnboundedStack<String> createDS() {
        outln("Creating a new DSUnboundedStack<String> instance...");
        DSUnboundedStack<String> stack = factory.create(String.class);
        outln("   ...created: " + stack.getClass().getCanonicalName());
        return stack;
    }

    protected void push(DSUnboundedStack<String> stack, String... items) {
        for ( String item : items ) {
            stack.push(item);
            outln("push(" + StringTools.quoteWrap(item) + ")");
        }
    }

    protected void checkPeekAll(DSUnboundedStack<String> ds,
                                String... expectedItems) {

        testHelper.check("peekAll()", ds.peekAll(), expectedItems);
    }

    protected void checkPeekAllOnEmpty(DSUnboundedStack<String> ds) {
        checkPeekAll(ds, StringTools.ZERO_LEN_ARRAY);
    }

    protected void checkPopAll(DSUnboundedStack<String> ds,
                               String... expectedItems) {

        testHelper.check("popAll()", ds.popAll(), expectedItems);
    }

    protected void reverseArray(String[] strings) {
        Collections.reverse(Arrays.asList(strings));
    }
}
