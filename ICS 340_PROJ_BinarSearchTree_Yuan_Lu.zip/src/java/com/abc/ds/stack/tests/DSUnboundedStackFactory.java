package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;

public interface DSUnboundedStackFactory {
    <T> DSUnboundedStack<T> create(Class<T> itemType,
                                   int initialCapacity,
                                   int percentToGrowCapacity);

    <T> DSUnboundedStack<T> create(Class<T> itemType);
}
