package com.abc.ds.stack.tests.gui;

import com.abc.ds.stack.tests.*;
import com.programix.testing.*;

public class GuiTestDSUnboundedStack {
    public static void runTests(final String title,
                                final DSUnboundedStackFactory factory) {

        ParallelTestingPane.createFramedInstance(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSUnboundedStack.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }
}
