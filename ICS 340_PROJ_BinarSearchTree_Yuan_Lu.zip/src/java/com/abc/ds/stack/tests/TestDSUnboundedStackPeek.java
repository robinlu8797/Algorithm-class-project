package com.abc.ds.stack.tests;

import java.util.*;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackPeek extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackPeek(DSUnboundedStackFactory factory) {
        super("peek()", factory);
    }

    @Override
    protected void performTests() {
        testOneItem();
        testTwoItems();
        testSeveralItems();
        testEmpty();
    }

    private void testOneItem() {
        outlnSeparator();
        outln(" - one item -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        outln("peek()", stack.peek(), "apple");
    }

    private void testTwoItems() {
        outlnSeparator();
        outln(" - two items -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        push(stack, "banana");
        outln("peek()", stack.peek(), "banana");
        outln("Test that calling peek() didn't change anything, peeking again....");
        outln("peek()", stack.peek(), "banana");
    }

    private void testSeveralItems() {
        outlnSeparator();
        outln(" - several items -");
        DSUnboundedStack<String> stack = createDS();
        String[] fruits = getFruits(15);
        for ( String fruit : fruits ) {
            push(stack, fruit);
        }
        outln("peek()", stack.peek(), fruits[fruits.length -1]);
    }

    private void testEmpty() {
        outlnSeparator();
        outln(" - empty (NoSuchElementException) -");
        DSUnboundedStack<String> stack = createDS();

        outln("confirming isEmpty()", stack.isEmpty(), true);
        if ( !stack.isEmpty() ) {
            outlnErrorText("Cannot proceed with peek on empty tests: " +
                "newly created should be empty but is not");
            return;
        }

        testEmptyHelper(stack);

        push(stack, getFruits(5));
        outln("clear()");
        stack.clear();

        testEmptyHelper(stack);
    }

    private void testEmptyHelper(DSUnboundedStack<?> stack) {
        if ( !stack.isEmpty() ) {
            outln("can't attempt - isEmpty() is not returning true", false);
            return;
        }

        boolean success = false;
        try {
            outln("empty, trying peek()...");
            stack.peek();
        } catch ( NoSuchElementException x ) {
            outln("expected this exception: " + x.toString());
            success = true;
        } catch ( Exception x ) {
            failureExceptionWithStackTrace(x);
        }

        if ( success ) {
            outln("peek() on an empty stack " +
                "threw NoSuchElementException", true);
        } else {
            outln("peek() on an empty list " +
                "did NOT throw NoSuchElementException", false);
        }
    }
}
