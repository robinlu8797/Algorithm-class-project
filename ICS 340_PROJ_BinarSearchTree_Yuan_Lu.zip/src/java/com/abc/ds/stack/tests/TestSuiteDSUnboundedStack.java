package com.abc.ds.stack.tests;

import com.programix.testing.*;
import com.programix.util.*;

public class TestSuiteDSUnboundedStack {
    // no instances
    private TestSuiteDSUnboundedStack() {
    }

    public static BaseTest[] createAllTests(DSUnboundedStackFactory factory) {
        ObjectTools.paramNullCheck(factory, "factory");

        return new BaseTest[] {
            new TestDSUnboundedStackFactoryCheck(factory),
            new TestDSUnboundedStackItemType(factory),
            new TestDSUnboundedStackBasicEmptyCount(factory),
            new TestDSUnboundedStackClear(factory),
            new TestDSUnboundedStackPeek(factory),
            new TestDSUnboundedStackPeekAll(factory),
            new TestDSUnboundedStackPop(factory),
            new TestDSUnboundedStackPopAll(factory),
            new TestDSUnboundedStackPeekThenPop(factory),
            new TestDSUnboundedStackMixedBag(factory),
        };
    }

    public static TestChunk[] createAllTestChunks(DSUnboundedStackFactory factory) {
        return StandardTestChunk.createAll(createAllTests(factory));
    }
}
