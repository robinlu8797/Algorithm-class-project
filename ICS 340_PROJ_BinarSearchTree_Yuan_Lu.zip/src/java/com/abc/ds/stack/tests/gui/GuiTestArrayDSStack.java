package com.abc.ds.stack.tests.gui;

import com.abc.ds.stack.*;
import com.abc.ds.stack.tests.*;

public class GuiTestArrayDSStack {
    public static void main(String[] args) {
        GuiTestDSUnboundedStack.runTests("ArrayDSUnboundedStack", new DSUnboundedStackFactory() {

            @Override
            public <T> DSUnboundedStack<T> create(Class<T> itemType,
                                        int initialCapacity,
                                        int percentToGrowCapacity) {
                return new ArrayDSUnboundedStack<>(itemType, initialCapacity, percentToGrowCapacity);
            }

            @Override
            public <T> DSUnboundedStack<T> create(Class<T> itemType) {
                return new ArrayDSUnboundedStack<>(itemType);
            }
        });
    }
}
