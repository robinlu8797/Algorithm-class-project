package com.abc.ds.stack.tests;

import com.abc.ds.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackItemType extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackItemType(DSUnboundedStackFactory factory) {
        super("item type", factory);
    }

    @Override
    protected void performTests() {
        testItemTypeStandard();
        testItemTypeOthers();
    }

    private void testItemTypeStandard() {
        outlnSeparator();
        outln(" - item type - String -");
        DSUnboundedStack<String> stack = createDS();
        outln("stack.getItemType()", stack.getItemType(), String.class);
    }

    private void testItemTypeOthers() {
        outlnSeparator();
        outln(" - item type - others -");
        DSUnboundedStack<Integer> stackInteger = factory.create(Integer.class);
        outln("stack.getItemType()", stackInteger.getItemType(), Integer.class);

        IntegerStringKeyValuePair pairA = new IntegerStringKeyValuePair(1234, "fun, fun, fun");

        @SuppressWarnings("unchecked")
        Class<DSKeyValuePair<Integer, String>> fooArrayCompType =
            (Class<DSKeyValuePair<Integer, String>>) DSTools.coerceClassType(
                DSKeyValuePair.class);

        DSUnboundedStack<DSKeyValuePair<Integer, String>> stack =
            factory.create(fooArrayCompType);

        stack.push(pairA);
        outln("stack.getItemType()",
            stack.getItemType(), DSKeyValuePair.class);

        DSKeyValuePair<Integer, String> removedPair = stack.peek();
        outln("removedPair.getKey()", removedPair.getKey(), pairA.getKey());
        outln("removedPair.getValue()", removedPair.getValue(), pairA.getValue());
    }

    private static class IntegerStringKeyValuePair
            extends AbstractDSKeyValuePair<Integer, String> {

        private final Integer key;
        private final String value;

        public IntegerStringKeyValuePair(Integer key, String value) {
            this.key = key;
            this.value = value;
        }

        @Override
        public Integer getKey() {
            return key;
        }

        @Override
        public String getValue() {
            return value;
        }
    } // type IntegerStringKeyValuePair
}
