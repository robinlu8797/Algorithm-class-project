package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackClear extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackClear(DSUnboundedStackFactory factory) {
        super("clear tests", factory);
    }

    @Override
    protected void performTests() {
        testAddThenClear();
        testAddThenClearThenAdd();
    }

    private void testAddThenClear() {
        outlnSeparator();
        outln(" - push, then clear -");
        DSUnboundedStack<String> stack = createDS();
        outln("pushing 5:");
        push(stack, getFruits(0, 5));
        outln("checking count()", stack.count(), 5);
        outln("clear()");
        stack.clear();
        outln("checking isEmpty()", stack.isEmpty(), true);
        outln("checking count()", stack.count(), 0);
    }

    private void testAddThenClearThenAdd() {
        outlnSeparator();
        outln(" - push, then clear, then push -");
        DSUnboundedStack<String> stack = createDS();
        outln("pushing 20:");
        push(stack, getFruits(0, 20));
        outln("checking count()", stack.count(), 20);

        outln("clear()");
        stack.clear();
        outln("checking count()", stack.count(), 0);
        outln("checking isEmpty()", stack.isEmpty(), true);

        outln("pushing 6:");
        push(stack, getFruits(20, 6));
        outln("checking count()", stack.count(), 6);
        outln("checking isEmpty()", stack.isEmpty(), false);
    }
}
