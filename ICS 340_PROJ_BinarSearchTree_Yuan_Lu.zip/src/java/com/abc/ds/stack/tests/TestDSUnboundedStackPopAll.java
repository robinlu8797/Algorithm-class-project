package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;
import com.abc.ds.tests.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSUnboundedStackPopAll extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackPopAll(DSUnboundedStackFactory factory) {
        super("popAll()", factory);
    }

    @Override
    protected void performTests() {
        testOnEmpty();
        testOnOne();
        testOnTwo();
        testOnSeveral();
    }

    private void testOnEmpty() {
        outlnSeparator();
        outln(" - popAll() on empty -");
        DSUnboundedStack<String> stack = createDS();
        outln("isEmpty()", stack.isEmpty(), true);

        checkPopAll(stack, StringTools.ZERO_LEN_ARRAY);
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testOnOne() {
        outlnSeparator();
        outln(" - popAll() on one -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        checkPopAll(stack, "apple");
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testOnTwo() {
        outlnSeparator();
        outln(" - popAll() on two -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        push(stack, "banana");
        checkPopAll(stack, "banana", "apple");
        outln("isEmpty()", stack.isEmpty(), true);
    }

    private void testOnSeveral() {
        outlnSeparator();
        outln(" - popAll() on several -");
        DSUnboundedStack<String> stack = createDS();
        outln("pushing some junk to be cleared before popAll() test...");
        push(stack, "JUNK A");
        push(stack, "JUNK B");
        push(stack, "JUNK C");
        outln("clear()...");
        stack.clear();

        String[] fruits = new TestFruitGenerator(
            TestFruitGenerator.RANDOM_SEED_5).nextRandom(20);

        push(stack, fruits);
        reverseArray(fruits);
        checkPopAll(stack, fruits);
        outln("isEmpty()", stack.isEmpty(), true);
    }
}
