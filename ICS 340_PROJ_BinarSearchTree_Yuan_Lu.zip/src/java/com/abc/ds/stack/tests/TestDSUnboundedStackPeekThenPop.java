package com.abc.ds.stack.tests;

import com.abc.ds.stack.*;

/* deliberate package access */
class TestDSUnboundedStackPeekThenPop extends TestDSUnboundedStackBase {
    public TestDSUnboundedStackPeekThenPop(DSUnboundedStackFactory factory) {
        super("peek() then pop()", factory);
    }

    @Override
    protected void performTests() {
        testOneItem();
        testThreeItems();
    }

    private void testOneItem() {
        outlnSeparator();
        outln(" - one item -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        outln("peek()", stack.peek(), "apple");
        outln("pop()", stack.pop(), "apple");
    }

    private void testThreeItems() {
        outlnSeparator();
        outln(" - two items -");
        DSUnboundedStack<String> stack = createDS();
        push(stack, "apple");
        push(stack, "banana");
        push(stack, "cherry");
        outln("peek()", stack.peek(), "cherry");
        outln("pop()", stack.pop(), "cherry");
        outln("peek()", stack.peek(), "banana");
        outln("pop()", stack.pop(), "banana");
        outln("peek()", stack.peek(), "apple");
        outln("pop()", stack.pop(), "apple");
    }
}
