package com.abc.ds.stack;

import java.util.*;

/**
 * A stack or Last-In-First-Out (LIFO) which has unlimited capacity.
 * See <a href="https://en.wikipedia.org/wiki/Stack_(abstract_data_type)">Stack</a> at Wikipedia.
 */
public interface DSUnboundedStack<T> {
    Class<T> getItemType();

    int count();
    boolean isEmpty();
    void clear();

    /**
     * Pushes (adds) an item onto the top of the stack.
     */
    void push(T item);

    /**
     * Pushes each of the items onto the stop of the stack in the order
     * they are specified. pushAll("A", "B", "C") results in "C" being at
     * the top of the stack.
     */
    @SuppressWarnings("unchecked")
    void pushAll(T... items);

    /**
     * Pops (removes) an item from the top of the stack
     * or throws {@link NoSuchElementException} if currently empty.
     * Use {@link #isEmpty()} to avoid this exception.
     */
    T pop() throws NoSuchElementException;

    /**
     * Pops and returns all of the items currently in the stack in the order
     * they would be returns from repeated calls to {@link #pop()}.
     * For example, push("A"); push("B"); push(C); then popAll() returns
     * the array ["C", "B", "A"].
     * If empty, a zero-length array is returned, never null.
     * After this method is called, the stack is empty.
     */
    T[] popAll();

    /**
     * Returns the item on the top of the stack without modifying the stack
     * or throws {@link NoSuchElementException} if currently empty.
     * Use {@link #isEmpty()} to avoid this exception.
     */
    T peek() throws NoSuchElementException;

    /**
     * Returns all the items currently in the stack without modifying the stack
     * in the order they would be returned from repeated calls to {@link #pop()} [yes, pop() not peek()].
     * For example, push("A"); push("B"); push("C"); then peekAll() returns
     * the array ["C", "B", "A"].
     * If empty, a zero-length array is returned, never null.
     * After this method is called, the FIFO remains unaltered.
     */
    T[] peekAll();
}
