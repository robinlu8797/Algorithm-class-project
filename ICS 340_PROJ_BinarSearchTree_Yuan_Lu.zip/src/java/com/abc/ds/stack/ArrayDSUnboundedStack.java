package com.abc.ds.stack;

import java.util.*;

import com.abc.ds.list.*;

public class ArrayDSUnboundedStack<T> implements DSUnboundedStack<T> {
    private final DSList<T> list;

    public ArrayDSUnboundedStack(Class<T> itemType,
                                 int initialCapacity,
                                 int percentToGrowCapacity) {

        list = new ArrayDSList<>(itemType, initialCapacity, percentToGrowCapacity);
    }

    public ArrayDSUnboundedStack(Class<T> itemType) {
        this(itemType, 100, 10);
    }

    @Override
    public Class<T> getItemType() {
        return list.getItemType();
    }

    @Override
    public int count() {
        return list.getCount();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public void clear() {
        list.clear();
    }

    @Override
    public void push(T item) {
        list.add(item);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void pushAll(T... items) {
        list.addAll(items);
    }

    @Override
    public T pop() throws NoSuchElementException {
        return list.removeLast();
    }

    private void reverseOrder(T[] items) {
        if (items == null || items.length == 0 || items.length == 1) {
            // nothing to do, just return
            return;
        }

        int numberOfSwaps = items.length / 2; // int division
        for ( int i = 0; i < numberOfSwaps; i++ ) {
            T hold = items[i];
            int indexToSwapWith = items.length - 1 - i;
            items[i] = items[indexToSwapWith];
            items[indexToSwapWith] = hold;
        }
    }

    @Override
    public T[] popAll() {
        T[] items = list.removeAll();
        reverseOrder(items);
        return items;
    }

    @Override
    public T peek() throws NoSuchElementException {
        return list.peekLast();
    }

    @Override
    public T[] peekAll() {
        T[] items = list.peekAll();
        reverseOrder(items);
        return items;
    }
}
