package com.abc.ds;

import com.abc.ds.compare.*;
import com.programix.util.*;

/**
 * Provides information about how the data structure may or may not be
 * ordered.
 * Instances are immutable.
 */
public final class DSOrdering<T> {
    private static final DSOrdering<?> SHARED_UNORDERED = new DSOrdering<>(Type.UNORDERED, null);
    private static final DSOrdering<?> SHARED_ORDERED_BY_INSERTION = new DSOrdering<>(Type.ORDERED_BY_INSERTION, null);

    private final Type type;
    private final ComparatorSource<T> comparatorSource;

    /**
     * Creates a new instance for the required type and optional comparator.
     * If the type's hasComparator() method returns true, then the comparator
     * is required.
     * @throws IllegalArgumentException if a comparatorSource is required but not
     * supplied, OR if a comparator is supplied but not allowed.
     */
    public DSOrdering(Type type, ComparatorSource<T> comparatorSource) throws IllegalArgumentException {
        ObjectTools.paramNullCheck(type, "type");
        if (type.hasComparator()) {
            if (comparatorSource == null) {
                throw new IllegalArgumentException("comparatorSource required for this type of ordering");
            }
        } else {
            if (comparatorSource != null) {
                throw new IllegalArgumentException("comparatorSource cannot be specified for this type of ordering");
            }
        }
        this.type = type;
        this.comparatorSource = comparatorSource;
    }

    @SuppressWarnings("unchecked")
    public static <T> DSOrdering<T> createUnordered() {
        return (DSOrdering<T>) SHARED_UNORDERED;
    }

    @SuppressWarnings("unchecked")
    public static <T> DSOrdering<T> createUnordered(Class<T> type) {
        return (DSOrdering<T>) SHARED_UNORDERED;
    }

    @SuppressWarnings("unchecked")
    public static <T> DSOrdering<T> createOrderedByInsertion() {
        return (DSOrdering<T>) SHARED_ORDERED_BY_INSERTION;
    }

    @SuppressWarnings("unchecked")
    public static <T> DSOrdering<T> createOrderedByInsertion(Class<T> type) {
        return (DSOrdering<T>) SHARED_ORDERED_BY_INSERTION;
    }

    /** comparatorSource is required */
    public static <T> DSOrdering<T> createOrderedByComparator(ComparatorSource<T> comparatorSource) {
        return new DSOrdering<>(Type.ORDERED_BY_COMPARATOR, comparatorSource);
    }

    /** comparator is required */
    public static <T> DSOrdering<T> createOrderedByComparator(final DSComparator<T> comparator) {
        ObjectTools.paramNullCheck(comparator, "comparator");
        return createOrderedByComparator(new ComparatorSource<T>() {
            @Override
            public DSComparator<T> getComparator() {
                return comparator;
            }

        });
    }

    /** Returns the type of ordering, never null */
    public Type getType() {
        return type;
    }

    public boolean isOrdered() {
        return type.isOrdered();
    }

    public boolean hasComparator() {
        return type.hasComparator();
    }

    /**
     * Returns the comparator, never null. Or if no comparator is allowed for
     * this type, then an {@link IllegalStateException} is thrown.
     * Avoid this exception by calling {@link #hasComparator()} first.
     */
    public DSComparator<T> getComparator() throws IllegalStateException {
        if (!hasComparator()) {
            throw new IllegalStateException(
                "getComparator can only be called for types which return true from hasComparator()");
        }
        DSComparator<T> comparator = comparatorSource.getComparator();
        if (comparator == null) throw new IllegalStateException("ComparatorSource returned null for the DSComparator");
        return comparator;
    }

    public static enum Type {
        UNORDERED,
        ORDERED_BY_INSERTION,
        ORDERED_BY_COMPARATOR;

        public boolean isOrdered() {
            return this == ORDERED_BY_INSERTION || this == ORDERED_BY_COMPARATOR;
        }

        public boolean hasComparator() {
            return this == ORDERED_BY_COMPARATOR;
        }
    } // type Type

    public static interface ComparatorSource<T> {
        DSComparator<T> getComparator();
    } // type ComparatorSource
}
