package com.abc.ds.fifo;

import java.util.*;

import com.abc.ds.list.*;
import com.programix.util.*;

public class LinkedDSUnboundedFifo<T> implements DSUnboundedFifo<T> {
    private final DSList<T> list;

    public LinkedDSUnboundedFifo(Class<T> itemType) {
        ObjectTools.paramNullCheck(itemType, "itemType");
        list = new LinkedDSList<>(itemType);
    }

    private void confirmNotEmpty() throws NoSuchElementException {
        if (isEmpty()) {
            throw new NoSuchElementException("FIFO is empty");
        }
    }

    @Override
    public Class<T> getItemType() {
        return list.getItemType();
    }

    @Override
    public int count() {
        return list.getCount();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public void clear() {
        list.clear();
    }

    @Override
    public void add(T item) {
        list.add(item);
    }

    @Override
    public void addAll(@SuppressWarnings("unchecked") T... items) {
        list.addAll(items);
    }

    @Override
    public T remove() throws NoSuchElementException {
        confirmNotEmpty();
        return list.removeFirst();
    }

    @Override
    public T[] removeAll() {
        return list.removeAll();
    }

    @Override
    public T peek() throws NoSuchElementException {
        confirmNotEmpty();
        return list.peekFirst();
    }

    @Override
    public T[] peekAll() {
        return list.peekAll();
    }
}
