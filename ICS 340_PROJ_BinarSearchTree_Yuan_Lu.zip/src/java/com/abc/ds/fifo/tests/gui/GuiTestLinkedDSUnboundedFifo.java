package com.abc.ds.fifo.tests.gui;

import com.abc.ds.fifo.*;
import com.abc.ds.fifo.tests.*;

public class GuiTestLinkedDSUnboundedFifo {
    public static void main(String[] args) {
        GuiTestDSUnboundedFifo.runTests("LinkedDSUnboundedFifo", new DSUnboundedFifoFactory() {
            @Override
            public <T> DSUnboundedFifo<T> create(Class<T> itemType) {
                return new LinkedDSUnboundedFifo<>(itemType);
            }

            @Override
            public <T> DSUnboundedFifo<T> create(Class<T> itemType,
                                                 int initialCapacity,
                                                 int percentToGrowCapacity) {
                return create(itemType); // no special handling of capacity for this implementation
            }
        });
    }
}
