package com.abc.ds.sortedset.tests;

import com.abc.ds.sortedset.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSSortedSetPeekFirstLast extends TestDSSortedSetBase {
    public TestDSSortedSetPeekFirstLast(DSSortedSetFactory factory) {
        super("peekFirst, peekLast", factory);
    }

    @Override
    protected void performTests() {
        testPeekFirstJustOneWithPlenty();
        testPeekLastJustOneWithPlenty();
        testPeekFirstOnlyOne();
        testPeekLastOnlyOne();
        testPeekFirstSeveralTimes();
        testPeekLastSeveralTimes();
        testPeekFirstOnEmpty();
        testPeekLastOnEmpty();
    }

    private void testPeekFirstJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing peekFirst(), just one with plenty -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));
        int countBefore = ds.getCount();
        outln("peekFirst()", ds.peekFirst(), fp.getFirstSortedFruit());
        outln("count()", ds.getCount(), countBefore);
    }

    private void testPeekLastJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing peekLast(), just one with plenty -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));
        int countBefore = ds.getCount();
        outln("peekLast()", ds.peekLast(), fp.getLastSortedFruit());
        outln("count()", ds.getCount(), countBefore);
    }

    private void testPeekFirstOnlyOne() {
        outlnSeparator();
        outln(" - testing peekFirst(), only one available to peek -");
        DSSortedSet<String> ds = createDS();
        add(ds, "apple");
        outln("peekFirst()", ds.peekFirst(), "apple");
        checkCount(ds, 1);
    }

    private void testPeekLastOnlyOne() {
        outlnSeparator();
        outln(" - testing peekLast(), only one available to peek -");
        DSSortedSet<String> ds = createDS();
        add(ds, "apple");
        outln("peekLast()", ds.peekLast(), "apple");
        checkCount(ds, 1);
    }

    private void testPeekFirstSeveralTimes() {
        outlnSeparator();
        outln(" - testing peekFirst(), called several times -");
        DSSortedSet<String> ds = createDS();

        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));

        outln("peekFirst()", ds.peekFirst(), fp.getFirstSortedFruit());
        outln("peekFirst()", ds.peekFirst(), fp.getFirstSortedFruit());
        outln("peekFirst()", ds.peekFirst(), fp.getFirstSortedFruit());
    }

    private void testPeekLastSeveralTimes() {
        outlnSeparator();
        outln(" - testing peekLast(), called several times -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));

        outln("peekLast()", ds.peekLast(), fp.getLastSortedFruit());
        outln("peekLast()", ds.peekLast(), fp.getLastSortedFruit());
        outln("peekLast()", ds.peekLast(), fp.getLastSortedFruit());
    }

    private void testPeekFirstOnEmpty() {
        outlnSeparator();
        outln(" - testing peekFirst() on empty, expect exception -");
        DSSortedSet<String> ds = createDS();
        peekFirstExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekLast()", ds.peekLast(), "banana");
    }

    private void testPeekLastOnEmpty() {
        outlnSeparator();
        outln(" - testing peekLast() on empty, expect exception -");
        DSSortedSet<String> ds = createDS();
        peekLastExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("peekFirst()", ds.peekFirst(), "apple");
        outln("peekLast()", ds.peekLast(), "banana");
    }

    private void peekFirstExpectException(DSSortedSet<String> ds) {
        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekFirst()";
            }

            @Override
            public void execute(DSSortedSet<String> ds2) {
                ds2.peekFirst();
            }
        });
    }

    private void peekLastExpectException(DSSortedSet<String> ds) {
        checkNoSuchElementException(ds, new MethodAccess() {
            @Override
            public String formattedMethod() {
                return "peekLast()";
            }

            @Override
            public void execute(DSSortedSet<String> ds2) {
                ds2.peekLast();
            }
        });
    }
}
