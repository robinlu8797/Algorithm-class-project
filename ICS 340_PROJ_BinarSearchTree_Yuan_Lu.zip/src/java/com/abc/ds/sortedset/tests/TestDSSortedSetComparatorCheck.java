package com.abc.ds.sortedset.tests;

import com.abc.ds.compare.*;
import com.abc.ds.sortedset.*;

/* deliberate package access */
class TestDSSortedSetComparatorCheck extends TestDSSortedSetBase {
    public TestDSSortedSetComparatorCheck(DSSortedSetFactory factory) {
        super("comparator check", factory);
    }

    @Override
    protected void performTests() {
        testCreate();
        testComparator();
    }

    private void testCreate() {
        outln("Creating a new DSSortedSet with " +
            "factory.create(String.class, StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC)...");
        DSSortedSet<String> set = factory.create(String.class, StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC);
        outln("set != null", set != null, true);
    }

    private void testComparator() {
        outln("Creating a new DSSortedSet with " +
            "factory.create(String.class, StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC)...");
        DSComparator<String> comparatorToUse = StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC;
        DSSortedSet<String> set = factory.create(String.class, comparatorToUse);
        outln("set.getComparator() returns the original DSComparator", set.getComparator(), comparatorToUse);
    }
}
