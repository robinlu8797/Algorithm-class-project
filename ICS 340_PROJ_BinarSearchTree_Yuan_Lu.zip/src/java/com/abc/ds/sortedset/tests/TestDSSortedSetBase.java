package com.abc.ds.sortedset.tests;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.list.*;
import com.abc.ds.set.*;
import com.abc.ds.sortedset.*;
import com.abc.ds.tests.*;
import com.programix.math.*;
import com.programix.util.*;

/* deliberate package access */
abstract class TestDSSortedSetBase extends TestDSBase {
    protected final DSSortedSetFactory factory;
    protected final boolean allowDuplicates;
    protected TestDSHelper<String> testHelper;

    protected TestDSSortedSetBase(String subTitle,
                                  final DSSortedSetFactory rawFactory) {

        super("DSSortedSet - " + subTitle);
        this.factory = new DSSortedSetFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSortedSet<T> sortedSet) {
                return rawFactory.getOrdering(sortedSet);
            }

            @Override
            public <T> DSSortedSet<T> create(Class<T> itemType,
                                             DSComparator<T> comparator) {
                DSSortedSet<T> ds = rawFactory.create(itemType, comparator);
                updateTestHelper(ds);
                return ds;
            }
        };

        allowDuplicates = false;
        testHelper = new TestDSHelper.Builder<String>()
            .setItemType(String.class)
            .setTestAccess(testAccess)
            .setAllowDuplicates(allowDuplicates)
            .setOrdering(DSOrdering.createUnordered(String.class))
            .setWrapItemsInQuotes(true)
            .create();
    }

    private void updateTestHelper(DSSortedSet<?> s) {
        if (!String.class.equals(s.getItemType())) {
            // can't to anything without String-based testHelper
            return;
        }

        @SuppressWarnings("unchecked")
        DSSortedSet<String> sortedSet = (DSSortedSet<String>) s;

        testHelper = new TestDSHelper.Builder<String>()
            .setItemType(String.class)
            .setTestAccess(testAccess)
            .setAllowDuplicates(allowDuplicates)
            .setOrdering(factory.getOrdering(sortedSet))
            .setWrapItemsInQuotes(true)
            .create();
    }

    protected DSSortedSet<String> createDS(DSComparator<String> comparator) {
        outln("Creating a new DSSortedSet<String> instance...");
        DSSortedSet<String> ds = factory.create(String.class, TestSuiteDSSortedSet.STANDARD_STRING_COMPARATOR);
        outln("   ...created (comparator: " +
            (comparator instanceof DescriptiveDSComparator ? comparator.toString() : "<no description>") +
            "): " + ds.getClass().getCanonicalName());
        return ds;
    }

    protected DSSortedSet<String> createDS() {
        return createDS(TestSuiteDSSortedSet.STANDARD_STRING_COMPARATOR);
    }

    protected void add(DSSortedSet<String> ds, String... items) {
        for ( String item : items ) {
            outln("add(" + StringTools.quoteWrap(item) + ")");
            ds.add(item);
        }
    }

    protected void addExpectGood(DSSortedSet<String> ds, String... items) {
        for ( String item : items ) {
            boolean result = ds.add(item);
            outln("add(" + StringTools.quoteWrap(item) + "), returned",
                result, true);
        }
    }

    protected void addExpectDuplicate(DSSortedSet<String> ds, String... items) {
        for ( String item : items ) {
            boolean result = ds.add(item);
            outln("add(" + StringTools.quoteWrap(item) +
                ") [duplicate], returned", result, allowDuplicates);
        }
    }

    protected void outlnPeekAll(String prefix, DSSortedSet<String> ds) {
        String[] items = ds.peekAll();
        if (items == null) {
            outln(String.format("%s peekAll() returned null - " +
                "which should never happen (zero length array for empty)", prefix), false);
        }
        outln(String.format("%s peekAll() returned %d items: {%s}",
            prefix, items.length, StringTools.formatCommaDelimited(items)));
    }

    protected void checkPeekAll(DSSortedSet<String> ds,
                                String... expectedItems) {

        testHelper.check("peekAll()", ds.peekAll(), expectedItems);
    }

    protected void checkPeekAllOnEmpty(DSSortedSet<String> ds) {
        checkPeekAll(ds, StringTools.ZERO_LEN_ARRAY);
    }

    protected void checkPeekMatches(DSSortedSet<String> ds,
                                    DSFilter<String> filter,
                                    String... expectedItems) {

        testHelper.check("peekMatches(filter)", ds.peekMatches(filter), expectedItems);
    }

    protected void checkRemoveAll(DSSortedSet<String> ds,
                                String... expectedItems) {

        testHelper.check("removeAll()", ds.removeAll(), expectedItems);
    }

    protected void checkIterator(DSSortedSet<String> ds, String... expectedItems) {
        testHelper.check("createIterator()", ds.createIterator(), expectedItems);
    }

    protected void checkIterator(DSIterator<String> iterator, String... expectedItems) {
        testHelper.check("iteration results", DSTools.iteratorToArray(String.class, iterator), expectedItems);
    }

    protected void checkIteratorWithoutSortingExpected(DSIterator<String> iterator, String... expectedItems) {
        testHelper.checkWithoutSortingExpected("iteration results", iterator, expectedItems);
    }

    protected void checkContains(DSSortedSet<String> ds,
                                 String item,
                                 boolean expectedResult) {

        outln("contains(" + StringTools.quoteWrap(item) + ")",
            ds.contains(item), expectedResult);
    }

    protected void checkCount(DSSortedSet<String> ds, int expectedResult) {
        outln("count()", ds.getCount(), expectedResult);
    }

    protected void checkIsEmpty(DSSortedSet<String> ds, boolean expectedResult) {
        outln("isEmpty()", ds.isEmpty(), expectedResult);
    }


    protected DSSortedSet<String> createAltStringSet() {
        return new QuickAndDirtyDSSortedSet(StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC);
    }

    protected void checkNoSuchElementException(DSSortedSet<String> ds,
                                               MethodAccess methodAccess) {
        boolean success = false;
        String methodText = methodAccess.formattedMethod();
        try {
            outln("count() is " + ds.getCount() +
                ", trying " + methodText + "...");
            methodAccess.execute(ds);
        } catch ( NoSuchElementException x ) {
            outln("expected this exception: " + x.toString());
            success = true;
        } catch ( Exception x ) {
            failureExceptionWithStackTrace(x);
        }

        if ( success ) {
            outln(methodText + " threw NoSuchElementException", true);
        } else {
            outln(methodText + " did NOT throw NoSuchElementException", false);
        }
    }

    protected static interface MethodAccess {
        String formattedMethod();
        void execute(DSSortedSet<String> ds);
    } // type MethodAccess

    protected class FruitPack {
        private final String[] shuffledFruits;
        private final String[] sortedFruits;

        /** count must in range 1..26 (or is silently coerced into that range. */
        public FruitPack(int count, DSComparator<String> comparator) {
            count = NumberTools.rangeBound(1, count, 26);
            shuffledFruits = new TestFruitGenerator(
                TestFruitGenerator.RANDOM_SEED_15).nextRandomWithoutDuplicates(count);
            System.out.println("req count=" + count + ", StringTools.formatCommaDelimited(shuffledFruits)=" + StringTools.formatCommaDelimited(shuffledFruits));

            sortedFruits = shuffledFruits.clone();
            Arrays.sort(sortedFruits, DSTools.asJavaComparator(comparator));
        }

        public String[] getShuffledFruits() {
            return shuffledFruits;
        }

        public String[] getSortedFruits() {
            return sortedFruits;
        }

        public String getFirstSortedFruit() {
            return sortedFruits[0];
        }

        public String getLastSortedFruit() {
            return sortedFruits[sortedFruits.length - 1];
        }
    } // type FruitPack

    private static class QuickAndDirtyDSSortedSet implements DSSortedSet<String> {
        private final SortedSet<String> set;
        private final DSComparator<String> comparator;

        public QuickAndDirtyDSSortedSet(DSComparator<String> comparator) {
            set = new TreeSet<>(DSTools.asJavaComparator(comparator));
            this.comparator = comparator;
        }

        @Override
        public Class<String> getItemType() {
            return String.class;
        }

        @Override
        public int getCount() {
            return set.size();
        }

        @Override
        public boolean isEmpty() {
            return set.isEmpty();
        }

        @Override
        public void clear() {
            set.clear();
        }

        @Override
        public boolean add(String item) {
            return set.add(item);
        }

        @Override
        public int addAll(String... items) {
            if ( ObjectTools.isEmpty(items) ) {
                return 0;
            }

            int addCount = 0;
            for ( String item : items ) {
                if ( add(item) ) {
                    addCount++;
                }
            }
            return addCount;
        }

        @Override
        public int addAll(DSIterable<String> items) {
            if (items == null) return 0; // nothing to add

            if (items instanceof DSCountable) {
                DSCountable countable = (DSCountable) items;
                if (countable.isEmpty()) return 0; // nothing to add
            }

            int addCount = 0;
            for ( String item : DSTools.asJavaIterable(items) ) {
                if (add(item)) addCount++;
            }
            return addCount;
        }

        @Override
        public boolean remove(String item) {
            return set.remove(item);
        }

        @Override
        public int removeAndCountMatches(DSFilter<String> filter) {
            int removeCount = 0;
            for ( String item : peekMatches(filter) ) {
                if ( set.remove(item) ) {
                    removeCount++;
                }
            }
            return removeCount;
        }

        @Override
        public String[] removeAndReturnMatches(DSFilter<String> filter) {
            String[] matches = peekMatches(filter);
            for ( String item : matches ) {
                remove(item);
            }
            return matches;
        }

        @Override
        public String[] removeAll() {
            String[] results = peekAll();
            clear();
            return results;
        }

        @Override
        public boolean contains(String item) {
            return set.contains(item);
        }

        @Override
        public int countMatches(DSFilter<String> filter) {
            return peekMatches(filter).length;
        }

        @Override
        public String[] peekMatches(DSFilter<String> filter) {
            List<String> resultList = new ArrayList<>();
            for ( String item : set ) {
                if ( filter.matches(item) ) {
                    resultList.add(item);
                }
            }
            return StringTools.toArray(resultList);
        }

        @Override
        public String[] peekAll() {
            return StringTools.toArray(set);
        }

        @Override
        public void performOnAll(DSAction<String> action) {
            performOnMatches(new MatchEverythingDSFilter<String>(), action);
        }

        @Override
        public int performOnMatches(DSFilter<String> filter,
                                    DSAction<String> action) {

            String[] matches = peekMatches(filter);
            for ( String item : matches ) {
                action.perform(item);
            }
            return matches.length;
        }

        @Override
        public DSIterator<String> createIterator() {
            return new DSIterator<String>() {
                private final Iterator<String> iterator = set.iterator();

                @Override
                public boolean hasNext() {
                    return iterator.hasNext();
                }

                @Override
                public String next() throws NoSuchElementException {
                    return iterator.next();
                }
            };
        }

        @Override
        public int union(DSSet<String> otherSet) {
            int countBefore = set.size();
            set.addAll(new HashSet<>(Arrays.asList(otherSet.peekAll())));
            return set.size() - countBefore;
        }

        @Override
        public void intersection(DSSet<String> otherSet) {
            set.retainAll(new HashSet<>(Arrays.asList(otherSet.peekAll())));
        }

        @Override
        public void subtract(DSSet<String> otherSet) {
            set.removeAll(new HashSet<>(Arrays.asList(otherSet.peekAll())));
        }

        @Override
        public DSComparator<String> getComparator() {
            return comparator;
        }

        @Override
        public String removeFirst() throws NoSuchElementException {
            if (set.isEmpty()) throw new NoSuchElementException("currently empty, can't remove anything");
            String item = set.first();
            set.remove(item);
            return item;
        }

        @Override
        public String removeLast() throws NoSuchElementException {
            if (set.isEmpty()) throw new NoSuchElementException("currently empty, can't remove anything");
            String item = set.last();
            set.remove(item);
            return item;
        }

        @Override
        public String peekFirst() throws NoSuchElementException {
            if (set.isEmpty()) throw new NoSuchElementException("currently empty, can't peek at anything");
            return set.first();
        }

        @Override
        public String peekLast() throws NoSuchElementException {
            if (set.isEmpty()) throw new NoSuchElementException("currently empty, can't peek at anything");
            return set.last();
        }

        @Override
        public DSIterator<String> createReverseIterator() {
            List<String> javaList = new ArrayList<>(Arrays.asList(peekAll()));
            Collections.reverse(javaList);

            DSList<String> list = new ArrayDSList<>(String.class);
            list.addAll(javaList.toArray(new String[0]));
            return list.createIterator();
        }
    } // type QuickAndDirtyDSSortedSet
}
