package com.abc.ds.sortedset.tests.gui;

import com.abc.ds.sortedset.tests.*;
import com.programix.testing.*;

public class GuiTestDSSortedSet {
    public static void runTests(final String title,
                                final DSSortedSetFactory factory) {

        ParallelTestingPane.createFramedInstance(new ParallelTestingPane.Control() {
            @Override
            public String getTitle() {
                return title;
            }

            @Override
            public TestChunk[] createNewTestChunks(TestThreadFactory threadFactory) {
                return TestSuiteDSSortedSet.createAllTestChunks(factory);
            }

            @Override
            public boolean shouldShowPoints() {
                return false;
            }
        });
    }
}
