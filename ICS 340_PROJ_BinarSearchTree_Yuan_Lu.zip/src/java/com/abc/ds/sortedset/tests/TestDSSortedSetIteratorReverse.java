package com.abc.ds.sortedset.tests;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.sortedset.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSSortedSetIteratorReverse extends TestDSSortedSetBase {
    public TestDSSortedSetIteratorReverse(DSSortedSetFactory factory) {
        super("createReverseIterator", factory);
    }

    @Override
    protected void performTests() {
        testIteratorOnOne();
        testIteratorOnTwo();
        testIteratorOnSeveral();
        testIteratorOnEmpty();
    }

    private void testIteratorOnEmpty() {
        outlnSeparator();
        outln(" - createReverseIterator() on empty -");
        DSSortedSet<String> ds = createDS();
        checkIsEmpty(ds, true);
        outln("createReverseIterator()...");
        checkIterator(ds.createReverseIterator(), StringTools.ZERO_LEN_ARRAY);
    }

    private void testIteratorOnOne() {
        outlnSeparator();
        outln(" - createReverseIterator() on one -");
        DSSortedSet<String> ds = createDS();
        add(ds, "apple");
        outln("createReverseIterator()...");
        checkIterator(ds.createReverseIterator(), "apple");
    }

    private void testIteratorOnTwo() {
        outlnSeparator();
        outln(" - createReverseIterator() on two -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(2, ds.getComparator());
        String[] items = fp.getShuffledFruits();
        add(ds, items);

        outln("createReverseIterator()...");
        DSComparator<String> comparator = ds.getComparator();
        Arrays.sort(items, DSTools.asJavaComparator(
            new ReverseDSComparator<>(comparator)));
        checkIteratorWithoutSortingExpected(ds.createReverseIterator(), items);
    }

    private void testIteratorOnSeveral() {
        outlnSeparator();
        outln(" - createReverseIterator() on several -");
        DSSortedSet<String> ds = createDS();
        outln("adding some junk to be cleared before rest of test...");
        add(ds, "JUNK A");
        add(ds, "JUNK B");
        add(ds, "JUNK C");
        outln("clear()...");
        ds.clear();

        FruitPack fp = new FruitPack(20, ds.getComparator());
        String[] items = fp.getShuffledFruits();
        add(ds, items);

        outln("createReverseIterator()...");
        DSComparator<String> comparator = ds.getComparator();
        Arrays.sort(items, DSTools.asJavaComparator(
            new ReverseDSComparator<>(comparator)));
        checkIteratorWithoutSortingExpected(ds.createReverseIterator(), items);
    }
}
