package com.abc.ds.sortedset.tests;

import com.abc.ds.list.*;
import com.abc.ds.sortedset.*;
import com.programix.util.*;

/* deliberate package access */
class TestDSSortedSetRemoveFirstLast extends TestDSSortedSetBase {
    public TestDSSortedSetRemoveFirstLast(DSSortedSetFactory factory) {
        super("removeFirst, removeLast", factory);
    }

    @Override
    protected void performTests() {
        testRemoveFirstJustOneWithPlenty();
        testRemoveLastJustOneWithPlenty();
        testRemoveFirstOnlyOne();
        testRemoveLastOnlyOne();
        testRemoveFirstSeveralTimes();
        testRemoveLastSeveralTimes();
        testRemoveFirstOnEmpty();
        testRemoveLastOnEmpty();
    }

    private void testRemoveFirstJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing removeFirst(), just one with plenty -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));
        int countBefore = ds.getCount();
        outln("removeFirst()", ds.removeFirst(), fp.getFirstSortedFruit());
        outln("count()", ds.getCount(), countBefore - 1);
    }

    private void testRemoveLastJustOneWithPlenty() {
        outlnSeparator();
        outln(" - testing removeLast(), just one with plenty -");
        DSSortedSet<String> ds = createDS();
        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));
        int countBefore = ds.getCount();
        outln("removeLast()", ds.removeLast(), fp.getLastSortedFruit());
        outln("count()", ds.getCount(), countBefore - 1);
    }

    private void testRemoveFirstOnlyOne() {
        outlnSeparator();
        outln(" - testing removeFirst(), only one available to remove -");
        DSSortedSet<String> ds = createDS();
        add(ds, "apple");
        outln("removeFirst()", ds.removeFirst(), "apple");
        outln("isEmpty()", ds.isEmpty(), true);
    }

    private void testRemoveLastOnlyOne() {
        outlnSeparator();
        outln(" - testing removeLast(), only one available to remove -");
        DSSortedSet<String> ds = createDS();
        add(ds, "apple");
        outln("removeLast()", ds.removeLast(), "apple");
        outln("isEmpty()", ds.isEmpty(), true);
    }

    private void testRemoveFirstSeveralTimes() {
        outlnSeparator();
        outln(" - testing removeFirst(), called several times -");
        DSSortedSet<String> ds = createDS();

        FruitPack fp = new FruitPack(7, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));

        DSList<String> list = new ArrayDSList<>(String.class);
        list.addAll(fp.getSortedFruits());
        outln("removeFirst()", ds.removeFirst(), list.removeFirst());
        outln("removeFirst()", ds.removeFirst(), list.removeFirst());
        outln("removeFirst()", ds.removeFirst(), list.removeFirst());
        outln("removeFirst()", ds.removeFirst(), list.removeFirst());

        checkPeekAll(ds, list.peekAll());
    }

    private void testRemoveLastSeveralTimes() {
        outlnSeparator();
        outln(" - testing removeLast(), called several times -");
        DSSortedSet<String> ds = createDS();

        FruitPack fp = new FruitPack(9, ds.getComparator());
        add(ds, fp.getShuffledFruits());
        outln("peekAll():" + StringTools.formatCommaDelimited(ds.peekAll()));

        DSList<String> list = new ArrayDSList<>(String.class);
        list.addAll(fp.getSortedFruits());
        outln("removeLast()", ds.removeLast(), list.removeLast());
        outln("removeLast()", ds.removeLast(), list.removeLast());
        outln("removeLast()", ds.removeLast(), list.removeLast());
        outln("removeLast()", ds.removeLast(), list.removeLast());
        outln("removeLast()", ds.removeLast(), list.removeLast());

        checkPeekAll(ds, list.peekAll());
    }

    private void testRemoveFirstOnEmpty() {
        outlnSeparator();
        outln(" - testing removeFirst() on empty, expect exception -");
        DSSortedSet<String> ds = createDS();
        removeFirstExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("removeFirst()", ds.removeFirst(), "apple");
        outln("removeFirst()", ds.removeFirst(), "banana");
        removeFirstExpectException(ds);
    }

    private void testRemoveLastOnEmpty() {
        outlnSeparator();
        outln(" - testing removeLast() on empty, expect exception -");
        DSSortedSet<String> ds = createDS();
        removeLastExpectException(ds);
        outln("confirming data structure still sane after exception...");
        add(ds, "apple", "banana");
        outln("removeLast()", ds.removeLast(), "banana");
        outln("removeLast()", ds.removeLast(), "apple");
        removeLastExpectException(ds);
    }

    private void removeFirstExpectException(DSSortedSet<String> ds) {
        checkNoSuchElementException(ds, new TestDSSortedSetBase.MethodAccess() {
            @Override
            public String formattedMethod() {
                return "removeFirst()";
            }

            @Override
            public void execute(DSSortedSet<String> ds2) {
                ds2.removeFirst();
            }
        });
    }

    private void removeLastExpectException(DSSortedSet<String> ds) {
        checkNoSuchElementException(ds, new TestDSSortedSetBase.MethodAccess() {
            @Override
            public String formattedMethod() {
                return "removeLast()";
            }

            @Override
            public void execute(DSSortedSet<String> ds2) {
                ds2.removeLast();
            }
        });
    }
}
