package com.abc.ds.sortedset.tests;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.keyvalue.*;
import com.abc.ds.sack.*;
import com.abc.ds.sack.tests.*;
import com.abc.ds.set.*;
import com.abc.ds.set.tests.*;
import com.abc.ds.sortedset.*;
import com.programix.testing.*;
import com.programix.util.*;

public class TestSuiteDSSortedSet {
    public static final DSComparator<String> STANDARD_STRING_COMPARATOR =
        StringDSComparator.NULL_FIRST_CASE_INSENSITIVE_ASC;

    public static final DSComparator<Integer> STANDARD_INTEGER_COMPARATOR =
        new NullDSComparator<>(DSNullOrdering.NULL_FIRST, new DSComparator<Integer>() {
            @Override
            public DSCompareResult compare(Integer a, Integer b) {
                return DSCompareResult.instanceFor(a.compareTo(b));
            }
        });

    public static final DSComparator<DSKeyValuePair<Integer, ?>> STANDARD_INTEGER_KEY_VALUE_COMPARATOR =
        new NullDSComparator<>(DSNullOrdering.NULL_FIRST, new DSComparator<DSKeyValuePair<Integer, ?>>() {
            @Override
            public DSCompareResult compare(DSKeyValuePair<Integer,?> a, DSKeyValuePair<Integer,?> b) {
                return DSCompareResult.instanceFor(a.getKey().compareTo(b.getKey()));
            }
        });

    // no instances
    private TestSuiteDSSortedSet() {
    }

    private static class ComparatorLookup {
        private final Map<Class<?>, DSComparator<?>> map;

        public ComparatorLookup() {
            map = new LinkedHashMap<>();
            map.put(String.class, STANDARD_STRING_COMPARATOR);
            map.put(Integer.class, STANDARD_INTEGER_COMPARATOR);
            map.put(DSKeyValuePair.class, STANDARD_INTEGER_COMPARATOR);
        }

        @SuppressWarnings("unchecked")
        public <T> DSComparator<T> lookupStandardComparatorFor(Class<T> itemType) {
            DSComparator<?> comparator = map.get(itemType);
            if (comparator == null) {
                throw new IllegalArgumentException("no standard DSComparator available for itemType=" + itemType);
            }
            return (DSComparator<T>) comparator;
        }

        @SuppressWarnings("unused") // keep this for potential future use (was used by commented out code below)
        public boolean hasStandardComparatorFor(Class<?> itemType) {
            return map.containsKey(itemType);
        }
    } // type ComparatorLookup

    public static BaseTest[] createAllTests(final DSSortedSetFactory sortedSetFactory) {
        ObjectTools.paramNullCheck(sortedSetFactory, "sortedSetFactory");

        final ComparatorLookup comparatorLookup = new ComparatorLookup();

        DSSackFactory sackFactory = new DSSackFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSack<T> sack) {
                return sortedSetFactory.getOrdering((DSSortedSet<T>) sack);
//                if (comparatorLookup.hasStandardComparatorFor(sack.getItemType())) {
//                    return DSOrdering.createOrderedByComparator(comparatorLookup.lookupStandardComparatorFor(sack.getItemType()));
//                } else {
//                    return DSOrdering.createUnordered();
//                }
            }

            @Override
            public boolean allowDuplicates() {
                return false;
            }

            @Override
            public <T> DSSack<T> create(Class<T> itemType) {
                return sortedSetFactory.create(itemType, comparatorLookup.lookupStandardComparatorFor(itemType));
            }

            @Override
            public <T> DSSack<T> create(Class<T> itemType,
                                        int initialCapacity,
                                        int percentToGrowCapacity) {
                return create(itemType);
            }
        };

        DSSetFactory setFactory = new DSSetFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSet<T> set) {
                return sortedSetFactory.getOrdering((DSSortedSet<T>) set);
            }

            @Override
            public <T> DSSet<T> create(Class<T> itemType) {
                return sortedSetFactory.create(itemType, comparatorLookup.lookupStandardComparatorFor(itemType));
            }

            @Override
            public <T> DSSet<T> create(Class<T> itemType,
                                       int initialCapacity,
                                       int percentToGrowCapacity) {
                return create(itemType);
            }
        };

        BaseTest[] sackTests = TestSuiteDSSack.createAllTests(sackFactory);
        BaseTest[] setOnlyTests = TestSuiteDSSet.createAllTests(setFactory);
        BaseTest[] sortedSetOnlyTests = new BaseTest[] {
            new TestDSSortedSetFactoryCheck(sortedSetFactory),
            new TestDSSortedSetPeekFirstLast(sortedSetFactory),
            new TestDSSortedSetRemoveFirstLast(sortedSetFactory),
            new TestDSSortedSetIteratorReverse(sortedSetFactory),
        };

        List<BaseTest> allTestList = new ArrayList<>();
        allTestList.addAll(Arrays.asList(sackTests));
        allTestList.addAll(Arrays.asList(setOnlyTests));
        allTestList.addAll(Arrays.asList(sortedSetOnlyTests));
        return allTestList.toArray(new BaseTest[0]);
    }

    public static TestChunk[] createAllTestChunks(DSSortedSetFactory factory) {
        return StandardTestChunk.createAll(createAllTests(factory));
    }
}
