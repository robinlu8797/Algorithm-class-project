package com.abc.ds.sortedset.tests.gui;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.sortedset.*;
import com.abc.ds.sortedset.tests.*;

public class GuiTestArrayDSSortedSet {
    public static void main(String[] args) {
        GuiTestDSSortedSet.runTests("ArrayDSSortedSet", new DSSortedSetFactory() {
            @Override
            public <T> DSOrdering<T> getOrdering(DSSortedSet<T> sortedSet) {
                return DSOrdering.createOrderedByComparator(sortedSet.getComparator());
            }

            @Override
            public <T> DSSortedSet<T> create(Class<T> itemType,
                                             DSComparator<T> comparator) {
                return new ArrayDSSortedSet<>(itemType, comparator);
            }
        });
    }
}
