package com.abc.ds.sortedset.tests;

import com.abc.ds.*;
import com.abc.ds.compare.*;
import com.abc.ds.sortedset.*;

public interface DSSortedSetFactory {
    <T> DSOrdering<T> getOrdering(DSSortedSet<T> sortedSet);

    <T> DSSortedSet<T> create(Class<T> itemType, DSComparator<T> comparator);
}
