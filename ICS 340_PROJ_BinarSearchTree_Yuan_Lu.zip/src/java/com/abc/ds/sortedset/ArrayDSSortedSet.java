package com.abc.ds.sortedset;

import java.util.*;

import com.abc.ds.*;
import com.abc.ds.action.*;
import com.abc.ds.compare.*;
import com.abc.ds.filter.*;
import com.abc.ds.iterator.*;
import com.abc.ds.list.*;
import com.abc.ds.set.*;
import com.programix.util.*;

public class ArrayDSSortedSet<T> implements DSSortedSet<T> {
    private final DSList<T> list;
    private final DSComparator<T> comparator;

    public ArrayDSSortedSet(Class<T> itemType, DSComparator<T> comparator) {
        ObjectTools.paramNullCheck(itemType, "itemType");
        ObjectTools.paramNullCheck(comparator, "comparator");
        this.comparator = comparator;
        list = new ArrayDSList<>(itemType);
    }

    @Override
    public Class<T> getItemType() {
        return list.getItemType();
    }

    @Override
    public int getCount() {
        return list.getCount();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public void clear() {
        list.clear();
    }

    @Override
    public boolean add(T item) {
        int oldCount = list.getCount();
        for ( int i = 0; i < oldCount; i++ ) {
            T existingItem = list.peekAtIndex(i);
            switch (comparator.compare(item, existingItem)) {
                case EQUAL_TO: return false;
                case GREATER_THAN: continue;
                case LESS_THAN:
                    list.insertBefore(i, item);
                    return true;
            }
        }

        // greater than everything, new last item
        list.add(item);
        return true;
    }

    @SuppressWarnings("unchecked")
    @Override
    public int addAll(T... items) {
        if (ObjectTools.isEmpty(items)) return 0;

        int addCount = 0;
        for ( T item : items ) {
            if (add(item)) addCount++;
        }
        return addCount;
    }

    @Override
    public int addAll(DSIterable<T> iterableItems) {
        if (iterableItems == null) return 0;

        int addCount = 0;
        for ( T item : DSTools.asJavaIterable(iterableItems)) {
            if (add(item)) addCount++;
        }
        return addCount;
    }

    @Override
    public boolean remove(T item) {
        return list.remove(item);
    }

    @Override
    public T[] removeAndReturnMatches(DSFilter<T> filter) {
        return list.removeAndReturnMatches(filter);
    }

    @Override
    public int removeAndCountMatches(DSFilter<T> filter) {
        return list.removeAndCountMatches(filter);
    }

    @Override
    public T[] removeAll() {
        return list.removeAll();
    }

    @Override
    public boolean contains(T item) {
        return list.contains(item);
    }

    @Override
    public T[] peekMatches(DSFilter<T> filter) {
        return list.peekMatches(filter);
    }

    @Override
    public int countMatches(DSFilter<T> filter) {
        return list.countMatches(filter);
    }

    @Override
    public T[] peekAll() {
        return list.peekAll();
    }

    @Override
    public void performOnAll(DSAction<T> action) {
        list.performOnAll(action);
    }

    @Override
    public int performOnMatches(DSFilter<T> filter, DSAction<T> action) {
        return list.performOnMatches(filter, action);
    }

    @Override
    public int union(DSSet<T> otherSet) {
        return addAll(otherSet);
    }

    @Override
    public void intersection(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.isEmpty()) {
            // nothing to find in both, so clear us out
            clear();
        }

        removeAndCountMatches(new DSFilter<T>() {
            @Override
            public boolean matches(T item) {
                return !otherSet.contains(item);
            }
        });
    }

    @Override
    public void subtract(final DSSet<T> otherSet) {
        if (otherSet == null || otherSet.isEmpty()) return; // nothing to subtract

        removeAndCountMatches(new DSFilter<T>() {
            @Override
            public boolean matches(T item) {
                return otherSet.contains(item);
            }
        });
    }

    @Override
    public DSComparator<T> getComparator() {
        return comparator;
    }

    @Override
    public T removeFirst() throws NoSuchElementException {
        return list.removeFirst();
    }

    @Override
    public T removeLast() throws NoSuchElementException {
        return list.removeLast();
    }

    @Override
    public T peekFirst() throws NoSuchElementException {
        return list.peekFirst();
    }

    @Override
    public T peekLast() throws NoSuchElementException {
        return list.peekLast();
    }

    @Override
    public DSIterator<T> createIterator() {
        return list.createIterator();
    }

    @Override
    public DSIterator<T> createReverseIterator() {
        return list.createReverseIterator();
    }
}
