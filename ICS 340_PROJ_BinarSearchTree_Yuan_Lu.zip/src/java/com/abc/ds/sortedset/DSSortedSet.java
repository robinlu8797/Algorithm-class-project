package com.abc.ds.sortedset;

import java.util.*;

import com.abc.ds.compare.*;
import com.abc.ds.iterator.*;
import com.abc.ds.set.*;

/**
 * A sorted set of references to objects of type T.
 * Sorted in the order specified by the {@link DSComparator} and
 * does <em>NOT</em> allow duplicates.
 */
public interface DSSortedSet<T> extends DSSet<T> {
    /**
     * Returns the comparator used to both sort items in the set and
     * used to consider them to be equal or not equal to each other.
     * Neither the {@link Object#equals(Object) Object.equals()} method
     * nor the {@link Comparable#compareTo(Object)} [or {@link DSComparable#compareTo(Object)}] methods
     * on T are used. Only this {@link DSComparator} is used.
     * Implementations must ensure that this is never null.
     */
    DSComparator<T> getComparator();

    /**
     * Removes the first item in the sorted set and returns the item.
     * @throws NoSuchElementException if currently empty, check
     * {@link #isEmpty()} first to avoid this exception.
     */
    T removeFirst() throws NoSuchElementException;

    /**
     * Removes the last item in the sorted set and returns the item.
     * @throws NoSuchElementException if currently empty, check
     * {@link #isEmpty()} first to avoid this exception.
     */
    T removeLast() throws NoSuchElementException;

    /**
     * Returns the first item in the sorted set.
     * @throws NoSuchElementException if currently empty, check
     * {@link #isEmpty()} first to avoid this exception.
     */
    T peekFirst() throws NoSuchElementException;

    /**
     * Returns the last item in the sorted set.
     * @throws NoSuchElementException if currently empty, check
     * {@link #isEmpty()} first to avoid this exception.
     */
    T peekLast() throws NoSuchElementException;

    /**
     * Create a new instance of {@link DSIterator} for traversing
     * the items in order starting with the first item in the sorted set.
     * Each call returns a new, independent iterator.
     * In general, any alterations to the data structure while iterating
     * render the iterator invalid.
     */
    @Override
    DSIterator<T> createIterator();

    /**
     * Create a new instance of {@link DSIterator} for traversing
     * the items in reverse-order starting the last item in the sorted set.
     * Each call returns a new, independent iterator.
     * In general, any alterations to the data structure while iterating
     * render the iterator invalid.
     */
    DSIterator<T> createReverseIterator();
}
