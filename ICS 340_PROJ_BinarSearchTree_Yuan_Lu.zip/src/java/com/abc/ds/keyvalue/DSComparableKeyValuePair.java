package com.abc.ds.keyvalue;

import com.abc.ds.compare.*;

public interface DSComparableKeyValuePair<K, V> extends DSKeyValuePair<K, V> {
    /** Returns result of comparing this key to the specified pair's key */
    DSCompareResult compareKeyTo(DSComparableKeyValuePair<K, ?> otherPair);

    /**
     * Implementations must be totally consistent with {@link #compareKeyTo(DSComparableKeyValuePair)}.
     * If that method returns {@link DSCompareResult#EQUAL_TO} then this method <em>must</em> return true.
     * If that method does NOT return {@link DSCompareResult#EQUAL_TO} then this method <em>must</em> return false.
     * Most implementations of this method will want to simple return:
     * <pre>
     *     return compareKeyTo(
     * </pre>
     *
     */
    boolean isSameKey(DSComparableKeyValuePair<K, ?> otherPair);


//    @Override
//    boolean equals(Object obj);
}
